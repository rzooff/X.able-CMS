<?php
	// compatibile: php4 or higher

    $ini_file = "xable.ini";
    require "script/functions.php";
    require "script/xml.php";

    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $pass_path = $ini_pathes['password'];

    // ====== Variables ======
    $popup = false; // Show info popup
    $redirect = false; // Redirect to other page

    // ======= Get htpasswd data ======
    $pass_file = array_map("trim", file($pass_path));
    foreach($pass_file as $txt) {
        if(strlen($txt) > 3 && count(split(":", $txt)) == 2) {
            $txt = split(":", $txt);
            $login = $txt[0];
            $pass = $txt[1];
        };
    };
    
    // ======= Check for POST input ======
    if(is_array($_POST) && is_string($_POST['current_password']) && is_string($_POST['new_password']) && is_string($_POST['confirm_password'])) {
        $current_pass = $_POST['current_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];
        if($pass != crypt($current_pass, substr($pass, 0, 2))) {
            $popup = "Błędne aktualne hasło|error";
        }
        elseif($new_pass != $confirm_pass) {
            $popup = "Podane hasła różnią się|error";
        }
        elseif($new_pass != $confirm_pass) {
            $popup = "Nie podano hasła|error";
        }
        else {
            $pass_file = $login.":".crypt($new_pass, substr($pass, 0, 2));
            safeSave($pass_path, $pass_file);
            $popup = "Hasło zostało zmienione|done";
            $redirect = "index.php";
        };
    };

?>

<!doctype html>
<html>
	<head>
        <!-- Loader Style -->
        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }
        </style>
        <!-- Loader Style / end -->
		<meta charset="UTF-8">
		<title>X.able CMS / Password</title>
        
		<link rel="stylesheet" type="text/css" href="style/index.css" />
		<link rel="stylesheet" type="text/css" href="style/cms.css" />
        <link rel="stylesheet" type="text/css" href="style/skin.css" />
        <link rel="stylesheet" type="text/css" href="style/password.css" />
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		
        <script src='../script/jquery-1.11.2.min.js'></script>
        <script src='script/functions.js'></script>
        <script src='script/footer.js'></script>

	</head>
    
	<body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        
        <form id="password" method='post' action='password.php'>
            <div id="page_fader"></div>
            <div id="popup_container">
                <div id="popup_box">
                    <h6><span class="fi-torso-business"></span></h6>
                    <h3>Zmiana hasła administratora</h3>
                    <div class='inputs'>
                        <p class='label'>Login</p>
                        <input type='text' class='string' value='<?php echo $login; ?>' disabled>
                        <div class='text'>
                            <p class='label'>Aktualne hasło</p>
                            <input type='password' id='current_password' name='current_password' value=''>
                        </div>
                        <div class='text'>
                            <p class='label'>Nowe hasło</p>
                            <p class='description'>Minimum 6 znaków, bez odstępów</p>
                            <input class='text' type='password' id='new_password' name='new_password' value=''>
                            <p class='label'>Potwierdź nowe hasło</p>
                            <input type='password' id='confirm_password' name='confirm_password' value=''>
                        </div>
                    </div>
                    <div class='buttons'>
                        <button class='confirm'>OK</button>
                        <button class='cancel'>Anuluj</button>
                    </div>
                </div>
            </div>
        </form>
        
        <?php if(is_string($popup)) { echo "<input id='popup' value='$popup'>\n"; }; ?>
        <?php if(is_string($redirect)) { echo "<input id='redirect' value='$redirect'>\n"; }; ?>
        
        <script src='script/password.js'></script>
        
	</body>
</html>

