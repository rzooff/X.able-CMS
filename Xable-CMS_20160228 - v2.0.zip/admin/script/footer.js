$(document).ready(function() {

    // ==========================================
    //            Footer & copyrights
    // ==========================================
    
    xml_path = $("input#path").val();
	
	footer = [
		"<b>X.able CMS</b> v.2.0 &copy;2016 <a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</a>&nbsp;<span>|</span>",
		"<a href='mailto:maciej@maciejnowak.com?Subject=X.able CMS / Editor'><span class='fi-mail help' help='Zgłoś problem'></span></a>",
		"<a href='password.php' class='unsaved'><span class='fi-torso-business help' help='Zmień hasło administratora'></span></a>",
		"<span id='update_output' class='fi-eye help' help='Podgląd kodu'></span>",
		"<a href='creator.php?open=" + encodeURIComponent(xml_path) + "' class='unsaved'><span class='fi-wrench help' help='Kreator XML'></span></a>",
	];

	$("form").append("<footer><p>" + footer.join(" ") + "</p></footer>");
    //$("footer .fi-wrench").click(function() { alert("Funkcja niedostępna"); return false }); // Disable creator

});