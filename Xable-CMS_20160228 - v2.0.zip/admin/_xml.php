<?php
    echo "\n";

    // ======================================
    //         put XML data functions
    // ======================================

    function putHidden($att_name, $att) {
    // --------------------------------
    // $att = <array> xml ATTribute part
    // --------------------------------
    // Put hidden xml string data to HTML
    // --------------------------------
        $string = $att[0];
        echo "\t\t\t\t\t<input type='hidden' class='$att_name' value='".$string."'>\n";
    };

    function putLabel($att, $att_name) {
    // --------------------------------
    // $att = <array> xml ATTribute part
    // $att_name = <string> ATTribute NAME
    // --------------------------------
    // Put xml label or description data to HTML
    // --------------------------------
        // no languages version
        echo "\t\t\t\t\t<p class='$att_name'>".$att[0]."</p>\n";
        /*
        // languages version
        echo "\t\t\t\t\t<div class='$att_name'>\n";
        foreach(array_keys($att[0]) as $text_lang) {
            $text = $att[0][$text_lang][0];
            echo "\t\t\t\t\t\t<p class='$text_lang'>$text</p>\n";
        };
        echo "\t\t\t\t\t</div>\n";
        */
    };

    function putMedia($id, $section, $att, $root) {
    // --------------------------------
    // $id = <string> section unique ID
    // $section = <array> xml SECTION part
    // $att = <array> xml ATTribute part
    // $root = <string> root folder path
    // --------------------------------
    // Put xml media data to HTML
    // --------------------------------
        // Set
        $set = $section['set'][0];
		$valid_media = array_keys($section['media'][0]);
		if(!is_string($set) || $set == "" || !in_array($set, $valid_media)) { $set = array_shift(array_keys($section['media'][0])); };
		//if($set == "")
        $set_id = "$id-set-0";
        echo "\t\t\t\t\t<div class='set'>\n";
        foreach(array_keys($section['media'][0]) as $media_type) {
            if($media_type == $set) { $checked = "checked"; } else { $checked = ""; };
            echo "\t\t\t\t\t\t<label><input name='$set_id' type='radio' value='$media_type' $checked><span>$media_type</span></label>\n";
        };
        echo "\t\t\t\t\t</div>\n"; // .set
        // Media thumbs
        echo "\t\t\t\t\t<div class='media'>\n";
        foreach(array_keys($att[0]) as $media_type) {
            $media = $att[0][$media_type][0];
            // ====== FILE ======
            if($media_type == "file") {                
                $file_id = "$id-media-0-file-0";
                if(file_exists("$root/$media") && path("$root/$media", "extension") != "") { // Existing file path
                    echo "\t\t\t\t\t\t<div class='file' value='$media'>\n";
                    $icon = path("$root/$media", "extension");
                    if(in_array($icon, array("csv", "doc", "pdf"))) { $icon = "fi-page-".$icon; }
                    else { $icon = "fi-page"; };
                    echo
                        "\t\t\t\t\t\t\t<div class='thumb'><span class='file_icon $icon'></span>".
                        "<p>".path($media, "basename")."</p>".
                        "<button class='delete' help='Usuń obrazek'><span>x</span></button></div>\n";
                }
                else { // No file or not found
                    if(path("$root/$media", "extension") != "") { $media = path($media, "dirname"); };
                    echo "\t\t\t\t\t\t<div class='file' value='$media'>\n";
                };
                // ====== File upload ======
                if(path($media, "extension") == "") { $folder = "$root/$media"; }
                else { $folder = path("$root/$media", "dirname"); };
                $taken = join(";", listDir( $folder, "." ) ); // taken filenames in destination folder
                echo
                    "\t\t\t\t\t\t\t<div class='upload'>".
                    "<label for='$file_id' class='upload_file fi-upload' help='Dodaj obrazek'><p>Dodaj plik</p></label>".
                    "<input name='$file_id' id='$file_id' type='file' class='upload_file $file_id' accept='*'>".
                    "<input name='upload|$file_id' class='upload_filenames' type='hidden' value=''>".
                    "<input class='taken_filenames' type='hidden' value='$taken'>".
                    
                    "</div>\n";
            }
            // ====== IMAGE ======
            elseif($media_type == "image") {
                $image_id = "$id-media-0-image-0";
                echo "\t\t\t\t\t\t<div class='image' value='$media'>\n";
                if(file_exists("$root/$media") && path("$root/$media", "extension") != "") { // Existing image path
                    if(path("$root/$media", "extension") == "png") { $ext = " png"; } else { $ext = ""; };
                    echo
                        "\t\t\t\t\t\t\t<div class='thumb$ext' style='background-image:url(\"$root/$media\")'>".
                        "<button class='delete' help='Usuń obrazek'><span>x</span></button></div>\n";
                }
                elseif(!file_exists("$root/$media") && path("$root/$media", "extension") != "") { // Image not found
                    echo
                        "\t\t\t\t\t\t\t<div class='thumb not_found'><label class='fi-prohibited'><p>Brak pliku!</p></label>".
                        "<button class='delete' help='Usuń obrazek'><span>x</span></button></div>\n";
                }
                elseif(!file_exists("$root/$media")) { // path not exists
                    //echo "<script> alert('ERROR! Invalid path: $image_id');</script>";
                };
                // ====== File upload ======
                if(path($media, "extension") == "") { $folder = "$root/$media"; }
                else { $folder = path("$root/$media", "dirname"); };
                $taken = join(";", listDir( $folder, "jpg,jpeg,gif,png,ico" ) ); // taken filenames in destination folder
                echo
                    "\t\t\t\t\t\t\t<div class='upload'>".
                    "<label for='$image_id' class='upload_file fi-upload' help='Dodaj obrazek'><p>Dodaj plik</p></label>".
                    "<input name='$image_id' id='$image_id' type='file' class='upload_file $image_id' accept='image/*'>".
                    "<input name='upload|$image_id' class='upload_filenames' type='hidden' value=''>".
                    "<input class='taken_filenames' type='hidden' value='$taken'>".
                    
                    "</div>\n";
                // =========================
                echo "\t\t\t\t\t\t</div>\n"; // .image
            }
            // ====== GALLERY ======
            elseif($media_type == "gallery") {
                echo "\t\t\t\t\t\t<div class='gallery' value='$media'>\n";
                foreach(listDir("$root/$media", "jpg,jpeg,gif,png,?") as $image) {
                    //echo "\t\t\t\t\t\t\t<img src='$image'>\n";
                    echo
                        "<div class='thumb' style='background-image:url(\"$image\")'>".
                        "<button class='delete' help='Usuń obrazek'><span>x</span></button>".
                        "</div>\n";
                };
                // ====== Files upload ======
                $gallery_id = "$id-media-0-gallery-0";
                echo
                    "\t\t\t\t\t\t\t<div class='upload'>".
                    "<label for='$gallery_id' class='upload_file fi-upload' help='Dodaj obrazki'><p>Dodaj pliki</p></label>".
                    "<input name='".$gallery_id."[]' id='$gallery_id' type='file' class='upload_file $gallery_id' accept='image/*' multiple>".
                    "<input name='upload|$gallery_id' class='upload_filenames' type='hidden' value=''>".
                    "</div>\n";
                // =========================
                echo "\t\t\t\t\t\t</div>\n"; // .gallery
            }
            elseif ($media_type == "none") {
                echo "\t\t\t\t\t\t<div class='none' value=''><div class='thumb'></div></div>\n";
            };
        };
        echo "\t\t\t\t\t</div>\n"; // .media
    };

    function putOption($id, $section, $att, $att_name) {
    // --------------------------------
    // $id = <string> section unique ID
    // $section = <array> xml SECTION part
    // $att = <array> xml ATTribute part
    // $att_name = <string> ATTribute NAME
    // --------------------------------
    // Put xml option (checkbox/radio) data to HTML
    // --------------------------------
        $selected = split(";", $section['selected'][0]);
		// radio & no valid selected fix needed!
		echo "\t\t\t\t\t<ul class='$att_name'>\n";
        foreach($att[0]['option'] as $option) {
            if(in_array($option, $selected)) { $checked = "checked"; } else { $checked = ""; };
            if(strlen($option) < 3) { $label = strtoupper($option); } else { $label = ucfirst($option); };
            echo "\t\t\t\t\t\t<li><label class='option' value='$option' ><input name='$id' type='$att_name' value='$option' $checked><span>$label</span></label></li>\n";

        };
        echo "\t\t\t\t\t</ul>\n"; //.att_name
    };

    function putSlide($att, $att_name, $root) { // CUSTOM -> tutek.pl
    // --------------------------------
    // $att = <array> xml ATTribute part
    // $att_name = <string> ATTribute NAME
    // $root = <string> root folder path
    // --------------------------------
    // Put xml slide data to HTML
    // --------------------------------
        if($att_name == "text") {
            echo "\t\t\t\t\t<div class='text'>\n";
            foreach(array_keys($att[0]) as $text_lang) {
                $text = $att[0][$text_lang][0];
                echo "\t\t\t\t\t\t<input type='text' class='$text_lang' value='$text'>\n";
            };
            echo "\t\t\t\t\t</div>\n"; // .text
        };
        if($att_name == "slide") {
            foreach($att as $slide) {
                echo "\t\t\t\t\t<div class='slide'>\n";
                foreach(array_keys($slide) as $text_lang) {
                    $text = $slide[$text_lang][0];
                    if($text_lang == "image") {
                        echo "\t\t\t\t\t\t<img src='".showImage("$root/$text")."' class='image' value='$text'>\n";
                    }
                    else {
                        echo "\t\t\t\t\t\t<input type='text' class='$text_lang' value='$text'>\n";
                    };
                };
                echo "\t\t\t\t\t</div>\n"; // .slide
            };
        };
    };

    function putDisabled($att) {
    // --------------------------------
    // $att = <array> xml ATTribute part
    // --------------------------------
    // Put xml string data to HTML
    // --------------------------------
        $string = $att[0];
        echo "\t\t\t\t\t<input type='hidden' class='disabled' value='".$string."'>\n";
    };

    function putString($att) {
    // --------------------------------
    // $att = <array> xml ATTribute part
    // --------------------------------
    // Put xml string data to HTML
    // --------------------------------
        $string = $att[0];
        echo "\t\t\t\t\t<input type='text' class='string' value='".$string."'>\n";
    };

    function putText($type, $att) {
    // --------------------------------
    // $type = <string> section data TYPE
    // $att = <array> xml ATTribute part
    // --------------------------------
    // Put xml text/textarea data to HTML
    // --------------------------------
        echo "\t\t\t\t\t<div class='text'>\n";
        foreach(array_keys($att[0]) as $text_lang) {
            $text = $att[0][$text_lang][0];
            if($type == "textarea") {
                $text = str_replace("[br] ", "\n", $text); // fix for now
                $text = str_replace("[br]", "\n", $text);
                echo "\t\t\t\t\t\t<textarea class='$text_lang'>$text</textarea>\n";
            }
            else {
                echo "\t\t\t\t\t\t<input type='text' class='$text_lang' value='$text'>\n";
            };
        };
        echo "\t\t\t\t\t</div>\n";
    };

    // ======================================
    //           Image exits check
    // ======================================

    function showImage($path) {
    // --------------------------------
    // $path = <string> image file PATH
    // --------------------------------
    // RETURNS: <string> image file path or "no image" picture path if image file not exists.
    // --------------------------------
        $no_image = "images/noimage.jpg";
        if(file_exists($path) && in_array(path($path, "extension"), array("jpg", "jpeg", "gif", "png"))) { return $path;}
        else{ return $no_image; }
    };

    // ======================================
    // ======================================
    // ======================================
    //               Build HTML
    // ======================================
    // ======================================
    // ======================================

    echo "\n\t\t<form id='cms' class='xml' method='post' action='publish.php' enctype='multipart/form-data'>\n";

    echo "\t\t\t<header>\n";
    // ====== Languages ======
    echo "\t\t\t\t<div id='lang' ><span class='fi-web'></span><p>Język:</p><ul>\n";
    foreach($languages as $language) { echo "\t\t\t\t\t<li value='$language'>".strtoupper($language)."</li>\n"; };
    echo "\t\t\t\t</ul></div>\n";

    // XML
    $xml = loadXml($path);
    // ====== Edit Buttons ======
    echo "\t\t\t\t<div class='buttons'>\n";
    echo "\t\t\t\t\t<button class='cancel' help='Anuluj zmiany'>Anuluj</button>\n";
    echo "\t\t\t\t\t<button class='save' type='submit' help='Publikuj zmiany'>Publikuj</button>\n";
    echo "\t\t\t\t</div>\n";
    echo "\t\t\t</header>\n";
    // Main title
    if($path != $saveas) {
        $group = $_GET['group'];
        if(!is_string($group) || $group == "") { $group = ucfirst( array_pop( split("/", path($saveas, "dirname")) ) ); };
        echo "\t\t\t<h2>".ucfirst(path($saveas, "filename"))." <span>/ nowa strona w: $group</span></h2>\n";
    }
    else {
        echo "\t\t\t<h2>Nowa strona: ".path($saveas, "basename")."</h2>\n";
    };
    // Articles
    foreach(array_keys($xml) as $article_name) {
        $article_group = $xml[$article_name];
        foreach(array_keys($article_group) as $article_num) {
            $article = $article_group[$article_num];
            echo "\t\t\t<article class='$article_name'>\n";
            echo "\t\t\t\t<h3 class='xml'>$article_name</h3>\n";
            // Fold / unfold
            echo "\t\t\t\t<div class='fold_expand'><span class='fi-minus help fold' help='Zwiń wpis'></span><span class='fi-list help expand' help='Rozwiń wpis'></span></div>\n";
            // ====== POST type Article Buttons ======
            if($creator_mode == true) {
                echo
                    "\t\t\t\t<div class='creator_buttons'>\n".
                    "\t\t\t\t\t<button class='delete' help='Usuń wpis'><span class='fi-x'></span></button>\n".
                    "\t\t\t\t\t<button class='down' help='Przesun w dół'><span class='fi-arrow-down'></span></button>\n".
                    "\t\t\t\t\t<button class='up' help='Przesuń w górę'><span class='fi-arrow-up'></span></button>\n".
                    "\t\t\t\t</div>\n";
            }
            elseif(substr($article_name, 0, 6) == "multi_") {
                echo
                    "\t\t\t\t<div class='buttons'>\n".
                    "\t\t\t\t\t<button class='delete' help='Usuń wpis'><span class='fi-x'></span></button>\n".
                    "\t\t\t\t\t<button class='down' help='Przesun w dół'><span class='fi-arrow-down'></span></button>\n".
                    "\t\t\t\t\t<button class='up' help='Przesuń w górę'><span class='fi-arrow-up'></span></button>\n".
                    "\t\t\t\t\t<button class='new $article_name' help='Nowy wpis'><span class='fi-plus'></span></button>\n".
                    "\t\t\t\t</div>\n";
            };
            // ====== Section HTML form ======
            foreach(array_keys($article) as $section_name) {
                $section_group = $article[$section_name];
                foreach(array_keys($section_group) as $section_num) {
                    $section = $section_group[$section_num];
                    $id = "$article_name-$article_num-$section_name-$section_num";
                    echo "\t\t\t\t<section class='$section_name'>\n";
                    echo "\t\t\t\t\t<h5>$section_name</h5>\n"; // if no label/description
                    // Type
                    //arrayList($section);
                    $type = $section['type'][0];
                    echo "\t\t\t\t\t<input type='hidden' class='type' value='".$type."'>\n";
                    // Attributes
                    foreach(array_keys($section) as $att_name) {
                        $att = $section[$att_name];
                        if($att_name == "type") {} // type already added to xml
                        elseif ($att_name == "label" || $att_name == "description") { putLabel($att, $att_name); }
                        // ====== CUSTOM ======
                        elseif($type == "slides") { putSlide($att, $att_name, $root); } // CUSTOM -> tutek.pl
                        // ====================
                        elseif($att_name == "disabled") { putDisabled($att); }
                        elseif($att_name == "string") { putString($att); }
                        elseif($att_name == "checkbox" || $att_name == "radio") { putOption($id, $section, $att, $att_name); }
                        elseif($att_name == "text") { putText($type, $att); }
                        elseif($att_name == "format") { putHidden($att_name, $att); }
                        elseif($att_name == "media") { putMedia($id, $section, $att, $root); }
                        else {};
                    };
                    echo "\t\t\t\t</section>\n";
                };
            };
            if($creator_mode == true) {
                echo
                    "\t\t\t\t<div class='creator_buttons'>\n".
                    "\t\t\t\t\t<button class='new_section' help='Nowa sekcja'><span class='fi-plus'></span></button>\n".
                    "\t\t\t\t</div>\n";
            }
            echo "\t\t\t</article>\n";
        }; 
    };

    // Outupt data fields
    echo "\t\t\t<div id='outputs'>\n";
    echo "\t\t\t\t<input type='text' name='edit_path' id='edit_path' value='$path'>\n";
    echo "\t\t\t\t<input type='text' name='save_path' id='save_path' value='$saveas'>\n";
    echo "\t\t\t\t<input type='text' name='delete_files' id='delete_files' placeholder='Files to delete' value=''>\n";
    echo "\t\t\t\t<input type='text' name='delete_folders' id='delete_folders' placeholder='Folders to delete' value=''>\n";
    echo "\t\t\t\t<textarea name='output|xml' id='output'></textarea>\n";
    echo "\t\t\t</div>\n";

    echo "\t\t</form>\n"; // #cms
?>