$(document).ready(function () {

    function pathInfo(path, flag) { // odpowiednik pathinfo z php
        path_dat = path.split("/");
        name = path_dat.splice( path_dat.length - 1 );
        dir = path_dat.join("/");
        file_dat = name.split(".");
        ext = file_dat.splice( file_dat.length - 1 );
        base = file_dat.join(".");
        info = { "basename": base, "dirname": dir, "extension": ext, "filename": name };
        if(typeof flag == 'string') {
            return info[flag];
        }
        else {
            return info;
        };       
    };

});