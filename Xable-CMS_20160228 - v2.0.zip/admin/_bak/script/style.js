$(document).ready(function () {
	
    // ===============================
	//  Extended Styles - size+color
	// ===============================
    
    $("#color li.option").each(function() {
        style = $(this).find("input").val();
        $(this).addClass("color_" + style);
    });    
    $("#size li.option").each(function() {
        style = $(this).find("input").val();
        $(this).addClass("size_" + style);
    });
    
    $("#color #accept").click(function() {
        color = $('input[name=color]:checked', '#color').val();
        $textarea.val(text.substr(0, beg) + "[color=" + color + "]" + selected + "[/color]" + text.substr(end));
        $("form.popup").fadeOut(200);
        return false;
    });
    
    $("#size #accept").click(function() {
        size = $('input[name=size]:checked', '#size').val();
        $textarea.val(text.substr(0, beg) + "[size=" + size + "]" + selected + "[/size]" + text.substr(end));
        $("form.popup").fadeOut(200);
        return false;
    });
    
    // ===============================
	//       Styled HTML preview
	// ===============================
    
    function BBCode(text) {
        text = text.replace( /\[url=\#(.*?)\](.*?)\[\/url\]/ig, "<a href='$1' class='dynamic' target='_blank'>$2</a>"); // internal links
        text = text.replace( /\[url=(.*?)\](.*?)\[\/url\]/ig, "<a href='$1' target='_blank'>$2</a>"); // external links
        text = text.replace( /\[email=(.*?)\](.*?)\[\/email\]/ig, "<a href=\"mailto:$1\">$2</a>"); // mailto
        text = text.replace( /\[color=(.*?)\](.*?)\[\/color\]/ig, "<span class='color_$1'>$2</span>"); // color
        text = text.replace( /\[size=(.*?)\](.*?)\[\/size\]/ig, "<span class='size_$1'>$2</span>"); // size
        text = text.replace( /\[\*\]/ig, "&bull;"); // bullet character
		text = text.replace( /\[center\]/ig, "<p class='text_center'>"); // center open
		text = text.replace( /\[\/center\]/ig, "</p>"); // center close
        text = text.replace( /\[(.?)\]/ig, "<$1>"); // simple tag open
        text = text.replace( /\[\/(.?)\]/ig, "</$1>"); // simple tag closes
        text = text.replace( /\n/ig, "<br>"); // line break
        return text;
    };
	
    function noBBCode(text) {
		text = text.replace( /\[\*\]/ig, "*"); // change bullets to star
        text = text.replace( /\[(.*?)\]/ig, ""); // hard kill all BBCode
        return text;
    };
    
    $(".test").click(function() {
        text = $(this).closest("form").find("textarea").val();
        $("#test").find("p").html("<p>" + BBCode(text) + "</p>");
        $("#test").fadeIn(300);
    });

    $(".close_popup, #cancel").click(function() {
        $("form.popup").fadeOut(200);
        return false;
    });

    // ===============================
	//        Text style buttons
	// ===============================
	
	$("button.style").click(function() {
        $("#hyper input").val("");
        $("#baloon").stop().fadeOut(200);
        letter = ["bold", "italic", "underline"];
        basic = ["center"];
        hyper = ["external", "mailto"];
        style = $(this).val();
		$textarea = $(this).closest("table").find("textarea");
		text = $textarea.val();
		beg = $textarea[0].selectionStart;
		end = $textarea[0].selectionEnd;
        selected = text.substr(beg, (end - beg));
		if(style == "bullet") {
			$textarea.val(text.substr(0, beg) + "[*]" + text.substr(beg));
		}
        else if(selected == "") { // later conditions needs some text selected
            alert("Zaznacz najpierw tekst, który chcesz sformatować!");
        }
        else if(letter.indexOf(style) > -1) {
            tag = style.substr(0, 1);
            $textarea.val(text.substr(0, beg) + "[" + tag + "]" + selected + "[/" + tag + "]" + text.substr(end));
        }
        else if(basic.indexOf(style) > -1) {
            $textarea.val(text.substr(0, beg) + "[" + style + "]" + selected + "[/" + style + "]" + text.substr(end));
        }
        else if(hyper.indexOf(style) > -1) {
            if(style == "external") {
                $("#hyper .info").text("Adres URL (link):");
                tag = "url";
            }
            else if(style == "mailto") {
                $("#hyper .info").text("Adres email:");
                tag = "email";
            };
            $("#hyper .title h2").text( $(this).attr("help") );
            $("#hyper").fadeIn(300);
        }
        else if(style == "internal") {
            tag = "url";
            $("#internal").fadeIn(300);
        }
        else if(style == "color") {
            $("#color").fadeIn(300);
        }
        else if(style == "size") {
            $("#size").fadeIn(300);
		}
		else if(style == "noBBCode") {
			//if(confirm("Czy na pewno usunąć style BBCode?")) { };
			$textarea.val(text.substr(0, beg) + noBBCode(selected) + text.substr(end));
        };
		return false;
	});
       
    $("#hyper #accept").click(function() {
        link = $("#hyper input").val();
        if(link == "") {
            alert("Pole adresu nie może być puste!");
        }
        else {
            $textarea.val(text.substr(0, beg) + "[" + tag + "=" + link + "]" + selected + "[/" + tag + "]" + text.substr(end));
            $("form.popup").fadeOut(200);
        };
        return false;
    });
    
    $("#internal #accept").click(function() {
        link = $("#internal select").val();
        $textarea.val(text.substr(0, beg) + "[" + tag + "=#" + link + "]" + selected + "[/" + tag + "]" + text.substr(end));
        $("form.popup").fadeOut(200);
        return false;
    });
    
});