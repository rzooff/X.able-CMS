$(document).ready(function () {
    
    function pathInfo(path, flag) { // odpowiednik path(info) z php
        path_dat = path.split("/");
        name = path_dat.splice( path_dat.length - 1 );
        dir = path_dat.join("/");
        file_dat = name.split(".");
        ext = file_dat.splice( file_dat.length - 1 );
        base = file_dat.join(".");
        info = { "basename": base, "dirname": dir, "extension": ext, "filename": name };
        if(typeof flag == 'string') {
            return info[flag];
        }
        else {
            return info;
        };       
    };
    
	// ===============================
	//        Media type change
	// ===============================
    
    $("input.media_type").each(function() {
        post_id = $(this).closest("form").attr("id");
        flag = $(this).prop("checked");
        id = $(this).attr("name").split("-");
        val = $(this).val();
        content_id = id[0] + "-0-" + val + "-0";
        if(flag != true) { $("form#" + post_id + " div.media#" + id[0] + "-0" + " li.media_content#" + content_id).fadeOut(0); };
    });   
        
    $("input.media_type").click(function() {
        post_id = $(this).closest("form").attr("id");
        id = $(this).attr("name").split("-");
        val = $(this).val();
        content_id = id[0] + "-0-" + val + "-0";
        $("form#" + post_id + " div.media#" + id[0] + "-0 li.media_type div").removeClass('selected');
        $(this).parent("div").addClass("selected");
        $("form#" + post_id + " div.media#" + id[0] + "-0" + " li.media_content").fadeOut(0);
        $("form#" + post_id + " div.media#" + id[0] + "-0" + " li.media_content#" + content_id).fadeIn(0);
    });
    
	// ===============================
	//           Popup close
	// ===============================

    $(".popup #cancel").click(function() {
        $(".popup").fadeOut(200);
        return false;
    });

	// ===============================
	//            Clipart
	// ===============================
    
    $(".clipart_select").click(function() {
        $("#baloon").stop().fadeOut(200);
        $li = $(this).closest("li.media_content");
        title = $(this).attr("help");
        action = $(this).attr("class").split(" ");
        action = action[action.length - 1];
        id = $li.attr("id");
        src = $li.find("img").attr("src");
        files = $li.find("input.files").val().split(";");
        // inject variables
        $("#clipart .title h2").text(title);
        $("#clipart input#name").val(id);
        $("#clipart input#value").val(src);
        // build gallery
        html = "";
        for(n = 0; n < files.length; n++) {
            file = files[n];
            if(file == src) {
                div = "<div class='thumb'><img src='" + file + "'><input class='radio' type='radio' name='clipart' value='" + file + "' checked></div>";
            }
            else {
                div = "<div class='thumb'><img src='" + file + "'><input class='radio' type='radio' name='clipart' value='" + file + "'></div>";
            };
            html = html + div; 
        };
        $("#clipart li.media_content").html(html);
        // show popup
        $("#clipart").fadeIn(300);
        // change clipart
        $("button#select").click(function() {
            selected = false;
            $("#clipart li.media_content input.radio").each(function() { if($(this).prop("checked") == true) { selected = $(this).val(); }; });
            if(selected != false) {
                $li.find("img").attr("src", selected);
                $li.find("input.clipart").val(selected);
                $li.find(".hidden").removeClass("hidden");
            };
            $(".popup").fadeOut(200);
            return false;
        });
    });
    
    $(".clipart_delete").click(function() {
        $("#baloon").stop().fadeOut(200);
        $li = $(this).closest("li.media_content");
        val = pathInfo($li.find("input.clipart").val(), "dirname");
        $li.find("input.clipart").val(val);
        $li.find("img").attr("src", val);
        $li.find("img").parent().addClass("hidden");
        $(this).addClass("hidden");
    });

	// ===============================
	//          Image/gallery
	// ===============================
    
    $("input.image_add, input.images_add").fadeOut(0);
    
    $("span.images_add").click(function() {
        $buttons = $(this).parent("div");
        $input = $buttons.find("input.images_add");
        $input.attr("name", $input.attr("add")).addClass('required');
        $input.fadeIn(0);
        $buttons.find("span").fadeOut(0);
        // hide checkbox
        $li = $buttons.parent("li");
        $li.find("input.checkbox").hide();
    });
    
    $("span.image_add").click(function() {
        $buttons = $(this).parent("div");
        $input = $buttons.find("input.image_add");
        $input.attr("name", $input.attr("add"));
        $input.fadeIn(0);
        $buttons.find("input.action").attr("name", "_action");
        $buttons.find("span").fadeOut(0);
        // img fade
        $li = $buttons.parent("li");
        $li.find("img").css({ "opacity": "0.25" });
    });
    
    $("span.images_delete").click(function() {
        // imgs fade
        flag = false;
        $buttons = $(this).parent("div");
        $li = $buttons.parent("li");
        $li.find("img").each(function() {
            $box = $(this).next("input");
            if($box.prop("checked") != false) {
                $(this).css({ "opacity": "0.25" });
                flag = true;
            }
            else {
                $(this).css({ "opacity": "1.0" });
            };
        });
        // hide add button
        if(flag == true) {
            $(this).css({ "opacity": "0.5" }).attr('help', '');
            $input = $buttons.find("input.images_delete");
            $input.attr("name", $input.attr("delete"));
            $buttons.find(".images_add").fadeOut(0);
            // fade update
            $("li.media_content input.checkbox").click(function() {
                if($(this).prop("checked") == true) {
                    $(this).prev("img").css({ "opacity": "0.25" });
                }
                else {
                    $(this).prev("img").css({ "opacity": "1.0" });
                };
            });
        };
    });

    $("span.image_delete").click(function() {
        $(this).css({ "opacity": "0.5" }).attr('help', '');
        $buttons = $(this).parent("div");
        $input = $buttons.find("input.image_delete");
        $input.attr("name", $input.attr("delete"));
        $buttons.find(".image_add").fadeOut(0);
        // rename for xml_id & path data
        $buttons.find("input.rename").each(function() { $(this).attr("name", $(this).attr("rename")); });
        // img fade
        $li = $buttons.parent("li");
        $li.find("img").css({ "opacity": "0.25" });
        // file icons fade
        $li.find(".file_icon").each(function() {
            $(this).css({ "opacity": "0.25" });
        });
    });
    
    $("span.select_all").click(function() {
        $(this).closest("li.media_content").find("input.checkbox").prop("checked", true);
    });
    
});