<?php

// ===================================================
//                    Edit inputs
// ===================================================

	// ====== edit String / begin =======
    function editString($id, $data) {
	// ----------------------------------------
	// $id = <string> item name/id
	// $data = <array> item xml data array
	// ----------------------------------------
	// Create HTML gallery input
	// ----------------------------------------
        echo "\t\t<!-- STRING -->\n";
        if(is_string($string = $data['text'][0])) {
			echo "\t\t<li><input class='string' type='text' name='$id-text-0' value='$string'></li>\n";
		}
		elseif(is_string($string = $data['textarea'][0])) {
			echo "\t\t<li><textarea class='string' type='text' name='$id-text-0'>$string</textarea></li>\n";
		};
    }; // ====== edit String / end =======

	// ====== edit Text / begin =======
    function editText($id, $data, $lang, $type) {
	// ----------------------------------------
	// $id = <string> item name
	// $data = <array> item xml data array
	// $lang = <string> language code e.g. "pl", "en"...
    // $type = <string> input type name: "text" or "textarea"
	// ----------------------------------------
	// Create HTML text/textarea input
	// ----------------------------------------
        echo "\t\t<!-- TEXT / TEXTAREA -->\n";
        $style = $data['style'][0];
		$all_styles = [ "bold", "italic", "underline", "center", "bullet", "internal", "external", "mailto", "color", "size" ];
		$buttons_count = 0;
        if($style == "*") {
            $formatting = $all_styles;
        }
        elseif(is_string($style) && $style != "") {
            $formatting = split(",", $data['style'][0]);
        };
        echo "\t\t<li><table>\n";
        unset($langs);
        foreach(array_keys($data['text'][0]) as $l) { $langs[] = $l; };
        //echo "<!-- language: ".$langs[0]." -->\n";
        if(count($langs) > 1) {
            echo "\t\t\t<tr>\n";
            foreach($langs as $l) {
                echo "\t\t\t\t<td><span class='small'>".strtoupper($l)."</span></td>\n";
            };
            echo "\t\t\t</tr>\n";
        };
        if(count($formatting) > 0) { // style buttons for textarea field only!
            echo "\t\t\t<tr>\n";
            foreach($langs as $l) {
                echo "\t\t\t\t<td>\n";
                foreach($formatting as $style) {
                    if($style == "bullet") {
                        $tag = "&bull;";
                        $help = "wstaw kółko (bullet)";
                    }
                    elseif($style == "center") {
                        $tag = "<span class='fi-align-center'></span>";
                        $help = "wyśrodkowanie tekstu";
                    }
                    elseif($style == "external") {
                        $tag = "<span class='fi-link'></span>";
                        $help = "link zewnętrzny";
                    }
                    elseif($style == "internal") {
                        $tag = "<span class='fi-arrow-right'></span>";
                        $help = "link wewnętrzny";
                    }
                    elseif($style == "mailto") {
                        $tag = "<span class='fi-mail'></span>";
                        $help = "email";
                    }
                    elseif($style == "color") {
                        $tag = "<span class='fi-paint-bucket'></span>";
                        $help = "kolor";
                    }
                    elseif($style == "size") {
                        $tag = "<span class='fi-background-color'></span>";
                        $help = "wielkość liter";
                    }
                    elseif(in_array($style, $all_styles)) {
                        $tag = substr($style, 0, 1);
                        $tag = "<$tag>".strtoupper($tag)."</$tag>";
                        //$help = $style;
                    }
					else { $tag = false; };
					if(is_string($tag)) {
						echo "\t\t\t\t\t<button class='style help' id='$id-$l-0' help='$help' value='$style'>$tag</button>\n";
						$buttons_count++;
					};
                };
				if($buttons_count > 0) {
                    echo "\t\t\t\t\t<button class='style help' help='Usuń BBCode' value='noBBCode'><span class='fi-prohibited'></span></button>\n";
                    //echo "\t\t\t\t\t&nbsp;<span class='test small'>Podgląd</span>\n";
                };
                echo "\t\t\t\t</td>\n";
            };
            echo "\t\t\t</tr>\n";
        };
        echo "\t\t\t<tr>\n";
        foreach($langs as $l) {
            $text = str_replace("[br]", "\n", $data['text'][0][$l][0]);
            $text = str_replace("'", "&#39;", $text);
            //echo "text: $text";
            if($type == "textarea") { echo "\t\t\t\t<td><textarea name='$id-$l-0' id='$id-$l-0'>$text</textarea></td>\n"; }
            else { echo "\t\t\t\t<td><input class='text' type='text' name='$id-$l-0' id='$id-$l-0' value='$text'></td>\n"; };
        };
        echo "\t\t\t</tr>\n\t\t</table></li>\n";
    };  // ====== edit Text / end =======
	
	// ====== edit Media / begin =======
    function editMedia($id, $data, $root) {
	// ----------------------------------------
	// $id = <string> item name
	// $data = <array> item xml data array
	// $root = <string> path to website root folder
	// ----------------------------------------
	// Create HTML media input
	// ----------------------------------------
        echo "\t\t<!-- MEDIA -->\n";
		$media_types = [ "none" => "Brak", "document" => "PDF", "gallery" => "Galeria", "clipart" => "Grafika", "image" => "Obrazek", "video" => "Film" ];
        $set = $data['set'][0]; // set media type
        if($set == "") { $set = current(array_keys($media_types)); }; // set default type if needed
        //echo "id: $id, set: $set<br>\n";
        echo "\t\t<div class='media margin' id='$id'>\n";
		//media_type(s) bar
		echo "\t\t\t<li class='media_type'>\n";
		foreach(array_keys($data['media'][0]) as $type) {
            //echo "type: $type<br>";
			if($type == $set) {
                echo "\t\t\t\t<div class='selected'><input type='radio' class='media_type' name='$id-set-0' value='$type' checked>".$media_types[$type]."</div>\n";
            }
            else {
                echo "\t\t\t\t<div><input type='radio' class='media_type' name='$id-set-0' value='$type'>".$media_types[$type]."</div>\n";
            };
		};
		echo "\t\t\t</li>\n";
		//media_content(s) field
        echo "\t\t\t<div class='media_content'>\n";
        foreach(array_keys($data['media'][0]) as $type) {
            echo "\t\t\t\t<!-- $type -->\n";
            echo "\t\t\t\t<li class='media_content' id='$id-$type-0'>\n"; // $id-$type = radio([name]-[value]-0)
            // ====== NONE ======
            if($type == "none") {
                //echo "\t\t\t\t\t<input type='hidden' name='$id-media-0-none-0' value=''>\n";
            }
            // ====== GALLERY ======
            elseif($type == "gallery") {
                $val = $data['media'][0]['gallery'][0];
                $gallery = "$root/$val";
                if(!is_array ($images = listDir($gallery, "gif,jpg,png,?"))) { $images = []; };
                //echo "folder: $gallery<br>count: ".count($images)."<br>images: '".join("', '", $images)."'<br>";
                if(count($images) > 0) {
                    echo "\t\t\t\t\t<input type='hidden' name='$id-media-0-gallery-0' value='$gallery'>";
                    foreach($images as $src) {
                        echo "\t\t\t\t\t<div class='thumb'>\n";
                        echo "\t\t\t\t\t\t<img src='$src'>\n";
                        echo "\t\t\t\t\t\t<input type='checkbox' class='checkbox' name='_images[]' value='$src'>\n";
                        echo "\t\t\t\t\t</div>\n";
                    };
                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help images_add' help='Dodaj obrazy'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file images_add' add='$id-media-0-gallery-0[]' multiple>\n"; // add -> name
                    echo "\t\t\t\t\t\t<span class='fi-trash medium help images_delete' help='Usuń zanaczone'></span>\n"; // delete / disabled if add selected!
                    echo "\t\t\t\t\t\t<input type='hidden' class='images_delete' delete='_images_delete' value='$id-media-0-gallery-0'>\n"; // delete -> name
                    echo "\t\t\t\t\t\t<span class='fi-check medium help select_all' help='Zaznacz wszystko'></span>\n"; // select_all
                    echo "\t\t\t\t\t</div>\n";
                }
                else {
                    echo "\t\t\t\t\t<input type='hidden' name='$id-media-0-gallery-0' value='$val'>\n";
                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help images_add' help='Utwórz galerię'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file images_add' add='$id-media-0-gallery-0[]' multiple>\n"; // add -> name
                    echo "\t\t\t\t\t</div>\n";
                };
            }
            // ====== PDF DOCUMENT ======
            elseif($type == "document") {
                $val = $data['media'][0]['document'][0];
                if(($ext = path("$root/$val", "extension")) == "pdf" && file_exists("$root/$val")) {

                        echo "\t\t\t\t\t<div class='file_icon center'><a href='$root/$val' target='_blank'><span class='fi-page-pdf file_icon'></span></a><br>".path($val, "basename")."</div>\n";

                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help image_add' help='Zamień dokument'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file image_add' add='$id-media-0-document-0'>\n"; // add -> name
                    echo "\t\t\t\t\t\t<span class='fi-trash medium help image_delete' help='Usuń dokument'></span>\n"; // delete / disabled if add selected!
                    echo "\t\t\t\t\t\t<input type='hidden' class='rename' rename='_images_delete' value='$id-media-0-document-0'>\n"; // rename -> name / xml id
                    echo "\t\t\t\t\t\t<input type='hidden' class='rename' rename='_images[]' value='$root/$val'>\n"; // rename -> name / file path
                    echo "\t\t\t\t\t</div>\n";
                }
                else {
                    echo "\t\t\t\t\t<input type='hidden' class='folder' value='$val'>\n";
                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help image_add' help='Dodaj dokument PDF'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file image_add' add='$id-media-0-document-0'>\n"; // add -> name
                    echo "\t\t\t\t\t</div>\n";
                };
            }
            // ====== IMAGE ======
            elseif($type == "image") {
                $val = $data['media'][0]['image'][0];
                if(path("$root/$val", "extension") != "" && file_exists("$root/$val")) {
                    echo "\t\t\t\t\t<div class='thumb'><img src='$root/$val'></div>\n";
                    echo "\t\t\t\t\t<p class='file_name' style='clear:left;margin-left:15px'>".path($val, "basename")."</p>\n";
                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help image_add' help='Zamień obraz'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file image_add' add='$id-media-0-image-0'>\n"; // add -> name
                    echo "\t\t\t\t\t\t<span class='fi-trash medium help image_delete' help='Usuń obraz'></span>\n"; // delete / disabled if add selected!
                    echo "\t\t\t\t\t\t<input type='hidden' class='rename' rename='_images_delete' value='$id-media-0-image-0'>\n"; // rename -> name / xml id
                    echo "\t\t\t\t\t\t<input type='hidden' class='rename' rename='_images[]' value='$root/$val'>\n"; // rename -> name / file path
                    echo "\t\t\t\t\t</div>\n";
                }
                else {
                    echo "\t\t\t\t\t<input type='hidden' class='folder' value='$val'>\n";
                    echo "\t\t\t\t\t<div class='buttons'>\n";
                    echo "\t\t\t\t\t\t<span class='fi-plus medium help image_add' help='Dodaj obraz'></span>\n"; // add
                    echo "\t\t\t\t\t\t<input type='file' class='file image_add' add='$id-media-0-image-0'>\n"; // add -> name
                    
                    
                    echo "\t\t\t\t\t</div>\n";
                };
            }
            // ====== CLIPART ======
            elseif($type == "clipart") {
                $val = $data['media'][0]['clipart'][0];
                if(path("$root/$val", "extension") != "") {
                    $folder = path($val, "dirname"); // get folder path
                    $files = listDir("$root/$folder", 'jpg,png,gif,?');
                    $files = join(";", $files);
                }
                else {
                    $folder = $val; // get folder path
                    $files = listDir("$root/$folder", 'jpg,png,gif,?');
                    $val = substr(current($files), strlen($root) + 1); // autoselect first clipart
                    $files = join(";", $files);
                };
                echo "\t\t\t\t\t<input type='hidden' class='clipart' name='$id-media-0-clipart-0' value='$root/$val'>\n";
                echo "\t\t\t\t\t<input type='hidden' class='files' value='$files'>\n"; // clipart file pathes list
                echo "\t\t\t\t\t<div class='thumb'><img src='$root/$val'></div>\n";
                echo "\t\t\t\t\t<div class='buttons'>\n";
                echo "\t\t\t\t\t\t<span class='fi-thumbnails medium help clipart_select' help='Wybierz inną grafikę'></span>\n";
                echo "\t\t\t\t\t</div>\n";
            }
            /*
            elseif($type == "document") {
                echo "\t\t\t\t\t<input type='hidden' class='folder' value='$val'>\n";
                echo "\t\t\t\t\t<div class='buttons'>\n";
                echo "\t\t\t\t\t\t<span class='fi-plus medium help document_add' help='Dodaj obraz'></span>\n"; // add
                echo "\t\t\t\t\t\t<input type='file' class='file document_add' add='$id-media-0-document-0'>\n"; // add -> name
                echo "\t\t\t\t\t</div>\n";
            }
            */
            elseif($type == "video") {
                if(($val = $data['media'][0]['video'][0]) != "") {
                    echo "\t\t\t\t\t<iframe src='".embedLink($val)."' allowfullscreen></iframe>\n";
                }
                echo "\t\t\t\t\t<div class='margin'>Link do video (YouTube/Vimeo):</div>\n";
                echo "\t\t\t\t\t<div><input class='text video' type='text' name='$id-media-0-video-0' value='$val'></div>\n";
            }
            else { echo "\t\t\t\t\t<p>".$type."</p>\n"; };
            echo "\t\t\t\t</li>\n";
            
        };
        echo "\t\t\t</div>\n";
        echo "\t\t</div>\n";
	}; // ====== edit Media / end =======
	
    // ====== edit Option(s) / begin =======
    function editOption($id, $data) { // checkbox / radio
	// ----------------------------------------
	// $id = <string> item name
	// $data = <array> item xml data array
	// ----------------------------------------
	// Create HTML checkbox or radio list input
	// ----------------------------------------
		echo "\t\t<input type='hidden' name='_options[]' value='$id'>\n";
        $selected = split(",", $data['selected'][0]);
        foreach(array_keys($data['checkbox'][0]['option']) as $num) {
            $option = $data['checkbox'][0]['option'][$num];
            if(in_array($option, $selected)) { $checked = "checked"; } else { $checked = ""; };
            echo "\t\t<li><input type='checkbox' class='checkbox option' name='$id-selected-0[]' value='$option' $checked>&nbsp;<span class='option'>$option</span></li>\n";
        };
        foreach(array_keys($data['radio'][0]['option']) as $num) {
            $option = $data['radio'][0]['option'][$num];
            if(in_array($option, $selected)) { $checked = "checked"; } else { $checked = ""; };
            echo "\t\t<li><input type='radio' class='checkbox option' name='$id-selected-0[]' value='$option' $checked>&nbsp;$option</li>\n";
        };
    }; // ====== edit Option(s) / end =======

// ===================================================
//                     Site Map
// ===================================================

    // ====== load & show site Map / begin =======
    function siteList($sitemap, $lang, $path, $depth) {
    // ----------------------------------------
    // $sitemap = <array> site map in xml compatibile array
    // $path = <string> contents folder path
    // $depth = <integer> array/folder tree level depth, positive=active item, negative for inactive item; or <string> site name; or <false> for no master title
	// $map = <array> path site map ((<path> => <other xml data>)...)
    // ----------------------------------------
    // Display sitemap as HTML list
    // ----------------------------------------
		if(!is_array($map)) { $map = array(); }; // initialize array
		// Depth or site name on begin
		if(is_numeric($depth)) { $flag = false;}
		elseif(is_string($depth)) { $flag = $depth; $depth = 0; }
		elseif(!is_numeric($depth)) { $depth = 0; };
		// tab for clear source view
		$tab = ""; $n = 0; while($n++ <= $depth) { $tab .= "\t"; };
		//echo "<br>path: $path, depth: $depth<br>";
		//arrayList($sitemap);
		if(is_string($flag)) {
			echo "<details open><summary class='depth_$depth' onfocus='blur()'>$flag</summary><ul>\n";
		}
		else {
			echo "<ul>\n";
		};
        foreach($sitemap['page'] as $page) {
            $folder = $page['folder'][0];
			$id = $page['title'][0][$lang][0];
			$map["$path/$folder"] = $page;
            if(file_exists("$path/$folder")) {
                if(is_array($sub = $page['sub'][0])) { // page subfolder
					echo "$tab<details open><summary class='depth_".($depth + 1)."' onfocus='blur()'>";
                    if($page['type'][0] != "none") {
						echo "<a href='imdex.php?url=$path/$folder'>$id</a></summary>\n";
                        $sub_map = siteList($sub, $lang, "$path/$folder", ($depth + 1));
                    }
                    else {
						echo "$id</summary>\n";
                        $sub_map = siteList($sub, $lang, "$path/$folder", ($depth + 1));
                    };
					echo "</details>\n";
					$map = array_merge($map, $sub_map);
                }
                else { // standard page
					echo "$tab<li>";
                    if($page['type'][0] != "none") {
						echo "<a href='index.php?url=$path/$folder'>$id</a>";
					}
					else {
						echo "$id";
					};
					echo "</li>\n";
                };
            }
            else { echo "<b>ERROR! Folder not found: '$path/$folder'!</b><br>"; };
        };
		if($flag != false) { echo "</ul></details>\n"; } else { echo "</ul>\n"; };
		return $map;
    }; // ====== load & show site Map / end =======
	
?>