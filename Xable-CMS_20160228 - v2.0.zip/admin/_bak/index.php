<?php
    echo getcwd();

    $root = "..";
    $pages = "$root/pages";
    $blogs = "$root/blogs";
	$options = "settings.xml";
	$lang = "pl";
    require "../script/functions.php";
    require "../script/xml.php";
    require "script/panel.php";
    require "script/admin.php";

    $settings = loadXml("$root/$options");
    $domain = $settings['strona'][0]['domain'][0]['text'][0];
	//echo "DOMENA: $domain\n";

    if(!is_string($url = $_GET['url'])) { $url = "../settings.xml"; };
    $xml = loadXml($url);
?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>MyCMS 1.12: <?php echo $domain; ?></title>
        <link rel="stylesheet" type="text/css" href="style/admin.css" />
        <link rel="stylesheet" type="text/css" href="../style/style.css" />
        <link rel="stylesheet" href="style/foundation-icons.css" />
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900' rel='stylesheet' type='text/css'>
        <script src="../script/jquery-1.11.2.min.js"></script>
        <script src="script/admin.js"></script>
        <script src="script/media.js"></script>
        <script src="script/style.js"></script>
    </head>
    <body>
        
        <!-- CMS functions -->
        <aside>
			<ul>
				<?php
                    echo "\n<li><div class='arrow'></div><a href='../index.php' class='help new_window' help='Podgląd strony' target='_blank' id='preview'><span class='fi-eye big'></span></a></li>\n";
                    $pages_files = listDir($pages, "xml,?");
                    $blogs_files = listDir($blogs, "xml,?");
                    if(in_array($url, $pages_files)) { $current_page = $url; } else { $current_page = current($pages_files); };
                    if(in_array($url, $blogs_files)) { $current_blog = $url; } else { $current_blog = current($blogs_files); };
					$functions = [
						"$root/$options" => ["fi-widget", "Opcje"],
						//"$root/sitemap.xml" => ["fi-list-bullet", "Nawigacja"],
						//"$current_blog" => ["fi-calendar", "Blogi"],
						"$current_page" => ["fi-pencil", "Edycja"]
					];
					foreach(array_keys($functions) as $key) {
						if($key == $url) { $class = " class='selected'"; } else { $class = ""; };
						$icon = $functions[$key][0];
						$help = $functions[$key][1];
						echo "<li$class><div class='arrow'></div><a href='index.php?url=$key' class='help' help='$help'><span class='$icon big'></span></a></li>\n";
					};
				?>
			</ul>
        </aside>
        
        <!-- Pages list -->
        <nav>
            <?php
                echo "\n";
                if($url == "$root/$options") { echo "<h2>Opcje</h2>\n<ul><li class='selected'><span class='fi-page mini'></span>Ustawienia</li><ul>\n"; }
                elseif($url == "$root/sitemap.xml") { echo "<h2>Nawigacja</h2>\n<ul><li class='selected'><span class='fi-page mini'></span>Sitemap</li><ul>\n"; }
                //elseif($url == "$blogs/wydarzenia.xml") { echo "<h2>Blogi</h2>\n<ul><li class='selected'><span class='fi-page mini'></span>Wydarzenia</li><ul>\n"; }
                else {
                    if(path($url, "dirname") == $pages) {
                        $title = "Edycja";
                        $folder = $pages;
                    }
                    elseif(path($url, "dirname") == $blogs) {
                        $title = "Blogi";
                        $folder = $blogs; 
                    };
                    echo "<h2>$title</h2>\n<ul>\n";
                    foreach(listDir($folder, "xml") as $file) {
                        $page = str_replace("_", " ", ucfirst(path($file, 'filename')));
                        $link = "$folder/$file";
                        if($link == $url) { $class = " class='selected'"; } else { $class = ""; };
                        echo "\t<li$class><a href='index.php?url=$link'><span class='fi-page mini'></span>$page</a></li>\n";
                    };
                    echo "</ul>\n";
                };
            ?>                
        </nav>
        
        <!-- Main window -->
        <article>
		
            <!-- Header -->
            <header>
                <?php
                    echo "\n<div class='buttons'>\n";
                    if(in_array("post", array_keys($xml))) {
                        echo "\t<button class='white' id='new_post'><b>+</b> Nowy post</button>\n";
                        // add new post XML
                        $new['new'] = newPost($xml['post'][0], $root);
                        $xml['post'] = $new + $xml['post'];
                    };
                    echo "</div>\n";
                    if($url == "$root/$options") {
                        echo "<h1>Ustawienia</h1>";
                    }
                    else {
                        echo "<h1>".str_replace("_", " ", ucfirst(path($url, 'filename')))."</h1>";
                    };
                ?>
            </header>

            <!-- Forms -->
			<?php
                echo "\n";
                echo "<input type='hidden' id='url' value='$url'>\n";
                echo "<input type='hidden' id='root' value='$root'>\n\n";				
				foreach(array_keys($xml) as $tag) { // kolejne grupy wpisów / akapitów itp.            
					foreach(array_keys($xml[$tag]) as $num) { // kolejne wpisy z danej grupy
                        if(is_numeric($num)) { echo "<section>"; } else { echo "<section class='".$num."_".$tag."'>"; }; // new_post
                        echo "<form id='$tag-$num' action='modify.php?url=$url&root=$root' method='post' enctype='multipart/form-data'>\n";
                        echo "\t<input type='hidden' name='_id' value='$tag-$num'>\n"; // _id = "post-0"
						// ====== NAGŁÓWEK ======
                        if(is_numeric($num) && count($xml[$tag]) > 1) { // jeśli jest kilka wpisów tego samego typu (dodane guziczki do przesuwania w górę i w dół i możliwość usunięcia posta)
							echo "\t<div class='buttons'>\n";
							echo "\t\t<button name='_button' value='delete' class='post_delete'>Usuń</button>\n";
							echo "\t\t<button type='submit'>Zapisz</button>\n";
							echo "\t\t<button name='_button' value='move_down' class='button help' help='Przesuń w dół'>\/</button>\n";
							echo "\t\t<button name='_button' value='move_up' class='button help' help='Przesuń w górę'>/\</button>\n";
							echo "\t</div>\n";
                            echo "\t<ul>\n";
							echo "\t\t<li><h2>".ucfirst($tag)." (".($num + 1).")</h2></li>\n"; // do nazwy dodajemy numerek
                        }
                        else { // dla pojedyńczego wpisu
							echo "\t<div class='buttons'>\n";
							echo "\t\t<button type='submit'>Zapisz zmiany</button>\n";
							echo "\t</div>\n";
							echo "\t<ul>\n";
                            if(is_numeric($num)) {
                                echo "\t\t<li><h2>".ucfirst($tag)."</h2></li>\n";
                            }
                            else { // New post
                                echo "\t\t<li><h2>Nowy $tag</h2></li>\n";
                            };
                        };
                        // ====== POLA EDYCJI ======
                        $post = $xml[$tag][$num];
						foreach(array_keys($post) as $name) { // kolejne dane danego posta
							$data = $post[$name][0];
							$type = $data['type'][0];
							//arrayList($data);
							// LABEL + margin
							if(is_string($label = $data['label'][0][$lang][0])) {
								echo "\t\t<li class='margin'>$label</li>\n";
							}
							else {
								echo "\t\t<li class='margin'></li>\n";
							};
							// description
							if(is_string($desc = $data['description'][0][$lang][0]) && $desc != "") {
								echo "\t\t<li><span class='small'>$desc</span></li>\n";
							};
							// by TYPE
                            if(in_array($type, ["string", "date"])) {
				                editString("$name-0", $data);
                            }
                            elseif($type == "text" || $type == "textarea") {
                                editText("$name-0-text-0", $data, $lang, $type);
                            }
                            elseif($type == "media") {
								editMedia("$name-0", $data, $root);
							}
                            elseif($type == "option") {
								editOption("$name-0", $data);
							}
                            else {
                                echo "type: $type<br>";
                            };
						};
						echo "\t</ul>\n";
                        echo "</form></section>\n\n";
					};
				};
			?>
        </article>

        <!-- Popup(s) -->

        <form class='popup' id='internal'><!-- add internal hyperink BBCode style -->
            <ul>
                <li class='title'><h2>Tytuł</h2></li>
                <li class='info'>Info</li>
                <li class='select'>
                    <select>
                        <?php
                            foreach(listDir($pages, "xml") as $file) {
                                //echo path($file, "filename")."<BR>";
                                $id = str_replace(" ", "_", path($file, "filename"));
                                echo "<option value='$id'>$id</option>";
                            };
                        ?>
                    </select>
                </li>
                <li class='buttons'><button type='submit' id='accept'>OK</button><button type='submit' id='cancel'>Anuluj</button></li>
            </ul>
        </form>
        
        <form class='popup' id='hyper'><!-- add external hyperink & email BBCode style -->
            <ul>
                <li class='title'><h2>Tytuł</h2></li>
                <li class='info'>Info</li>
                <li class='input'><input type='text' class='verify'></li>
                <li class='buttons'><button type='submit' id='accept'>OK</button><button type='submit' id='cancel'>Anuluj</button></li>
            </ul>
        </form>
        
        <form class='popup' id='color'>
            <ul>
                <li class='title'><h2>Kolor czcionki</h2></li>
                <li class='option'><input type="radio" name="color" value="red" checked>&nbsp;&nbsp;Czerwony</li>
                <li class='option'><input type="radio" name="color" value="blue">&nbsp;&nbsp;Niebieski</li>
                <li class='option'><input type="radio" name="color" value="violet">&nbsp;&nbsp;Fioletowy</li>
                <li class='buttons'><button type='submit' id='accept'>OK</button><button type='submit' id='cancel'>Anuluj</button></li>
            </ul>
        </form>  
        
        <form class='popup' id='size'>
            <ul>
                <li class='title'><h2>Wielkość czcionki</h2></li>
                <li class='option'><input type="radio" name="size" value="small" checked>&nbsp;&nbsp;Mała</li>
                <li class='option'><input type="radio" name="size" value="big">&nbsp;&nbsp;Duża</li>
                <li class='option'><input type="radio" name="size" value="huge">&nbsp;&nbsp;Ogromna</li>
                <li class='buttons'><button type='submit' id='accept'>OK</button><button type='submit' id='cancel'>Anuluj</button></li>
            </ul>
        </form>  
        
        <form class='popup' id='test'>
            <ul>
                <li><span class='fi-x close_popup'></span></li>
                <li class='title'><h2>Podgląd</h2></li>
                <li class='title'><p class='preview'>Test</p></li>
            </ul>
        </form>
    
        <form class='popup' id='clipart'><!-- select clipart from a thumbnails gallery -->
            <ul>
                <input type='hidden' name='name' id='name' value=''>
                <input type='hidden' name='value' id='value' value=''>
                <li class='title'><h2>Tytuł</h2></li>
                <li class='media_content'>
                    <div class='thumb'></div>
                </li>
                <li class='buttons'><button id='select'>OK</button><button type='submit' id='cancel'>Anuluj</button></li>
            </ul>
        </form>

        <footer><p><b>MyCMS</b> (C)2015 by  <a href="http://maciejnowak.com" target="_blank">maciejnowak.com</a></p></footer>
    </body>
</html>