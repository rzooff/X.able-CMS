<?
	require "../script/functions.php";
	require "../script/xml.php";
	$bak = "_backup/getthere.pl-admin_".date("Y-m-d_H-i").".zip"; // getthere.pl_2015-06-21.zip
	$tree = listTree("", ".", ["_backup", "_trash"]);
	arrayList($tree);
	
	echo "ZIP: ".archiveFiles($bak, $tree)."<br>";

	// ====== archive files into zip / begin ======
	function archiveFiles($zippath, $files) {
		// -----------------------------------------------
		// $zippath = <string> Zip file path
		// $files = <array> files to zip pathes or <string> for single file zip
		// -----------------------------------------------
		// SAVES specified files into zip archive
		// -----------------------------------------------
		if(is_string($files)) { $files = [ $files ]; };
		if(is_array($files)) {
			if(file_exists($zippath)) { unlink($zippath); }; // Overwrite existing!
			$zip = new ZipArchive;
			if ($zip->open($zippath,  ZipArchive::CREATE)) {
				foreach($files as $file) { $zip->addFile($file, $file); };
				$zip->close();
				return $zippath;
			}
			else {
				echo "Zip saving error!<br>";
			};
		}
		else {
			echo "zipFiles() input variable(s) error!<br>";
		};
	}; // ====== archive files into zip / end ======


//�r�d�o: http://nostatic.pl/tworzenie-archiwum-zip-w-php,445.html


?>