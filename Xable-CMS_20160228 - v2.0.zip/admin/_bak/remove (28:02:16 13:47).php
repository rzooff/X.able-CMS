<?php

    $ini_file = "xable.ini";
    require "script/functions.php";
    require "script/xml.php";

    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $settings = loadXml($ini_pathes['settings']);

    //echo "<hr><h3>GET</h3><hr>";
    //arrayList($_GET);
    //echo "<hr><h3>POST</h3><hr>";
    //arrayList($_POST);
    //echo "<hr>\n";

    $protected = array("$root/settings.xml", "$root/navigation.xml");

    $errors = 0;
?>

<html>
    <head>
		<meta charset='utf-8'>
        <title>X.able CMS / Remove page</title>
        <link href='http://fonts.googleapis.com/css?family=Inconsolata:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
<!-- Loader Style -->
        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }

            /* ================================== */
            /*              Console               */
            /* ================================== */
            
            body {
                width: 100%;
                height: 100%;
                padding: 0 20px;
                font-family: 'Inconsolata';
                font-size: 14px;
                font-weight: normal;
            }

            article{ display: none; }
            * { margin: 0; padding: 0; }
            h2 { padding-top: 20px; font-size: 18px; font-weight: bold; }
            p { padding-top: 1px; }
            p span { margin-right: 10px; }
            .info { font-size: 11px; }
            .done { color: #22aa22; }
            .log { color: #999999; }
            .error { color: #ff0000; font-weight: bold; }
            .error:before { content: "ERROR! "; }
            textarea { width: 700px; height: 500px; }
            button { margin-top: 20px; padding: 10px; }
            
        </style>
    </head>
    <body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        <article>
            <?php

                // ======================================
                //            Main variables
                // ======================================

                $delete_path = $_GET['path'];

                // No path data
				if(!is_string($delete_path) || $delete_path == "") {
                    echo "<p class='error'>No page path send!</p>\n";
                    $errors++;
                }
                // No file
                elseif(!file_exists($delete_path)) {
                    echo "<p class='error'>Page not found: <a href='$delete_path'>$delete_path</a></p>\n";
                    $errors++;
                }
                // File is on protecded files list
                elseif(in_array($delete_path, $protected)) {
                    echo "<p class='error'>The file is protected: <a href='$delete_path'>$delete_path</a></p>\n";
                    $errors++;
                }
                // Check for xml attached files
                elseif(path($delete_path, "extension") == "xml") {
                    // ======================================
                    // Delete attached files / gallery folders
                    // ======================================
                    echo "<h2>DELETE ATTACHED FILES & FOLDERS</h2>\n";
                    $folders = array();
					$xml = loadXml($delete_path);
                    //arrayList($xml);
					foreach(array_keys($xml) as $article_name) {
                        $article_group = $xml[$article_name];
                        foreach(array_keys($article_group) as $article_num) {
                            $article = $article_group[$article_num];
                            foreach(array_keys($article) as $section_name) {
                                $section_group = $article[$section_name];
                                foreach(array_keys($section_group) as $section_num) {
                                    $item = $section_group[$section_num];
                                    if($item['type'][0] == "media") {
                                        foreach(array_keys($item['media'][0]) as $type) {
                                            $media = $item['media'][0][$type][0];
                                            $media = "$root/$media";
                                            //echo "type: $type, media: $media<br>";
                                            $folder = path($media, "dirname");
                                            if(!in_array($folder, $folders)) { $folders[] = $folder; }; // Memorize folders to delete empty ones
                                            // Delete
                                            if($type == "gallery" && file_exists($media)) {
                                                if(removeDir($media)) {
                                                    echo "<p class='done'>Delete gallery folder & it's content: <a href='$media'>$media</a></p>\n";
                                                }
                                                else {
                                                    echo "<p class='error'>Failed to delete folder: <a href='$media'>$media</a></p>\n";
                                                    $errors++;
                                                };
                                            }
                                            elseif(file_exists($media) && path($media, "extension") != "") {
                                                unlink($media);
                                                if(!file_exists($media)) {
                                                    echo "<p class='done'>Delete media file: <a href='$media'>$media</a></p>\n";
                                                }
                                                else {
                                                    echo "<p class='error'>Failed to delete file: <a href='$media'>$media</a></p>\n";
                                                    $errors++;
                                                };
                                            }
                                            else {
                                                echo "<p class='log'>Path already not exists: <a href='$media'>$media</a></p>\n";
                                                $folder = $media;
                                                if(!in_array($folder, $folders)) { $folders[] = $folder; }; // Memorize folders to delete empty ones
                                            };
                                        };
                                    }; 
                                };
                            };
                        };
                    };
                    echo "<h2>DELETE EMPTY FOLDERS</h2>\n";
                    foreach($folders as $folder) {
                        if(count(listDir($folder)) == 0) {
                            if(!file_exists($folder)) {
                                echo "<p class='log'>Folder already not exists: <a href='$folder'>$folder</a></p>\n";
                            }
                            elseif(removeDir($folder)) {
                                echo "<p class='done'>Delete empty folder: <a href='$folder'>$folder</a></p>\n";
                            }
                            else {
                                echo "<p class='error'>Failed to delete folder: <a href='$folder'>$folder</a></p>\n";
                                $errors++;
                            };
                        }
                        else {
                            echo "<p class='log'>Folder is not empty: <a href='$folder'>$folder</a></p>\n";
                        }
                    };
				};
            
                // ======================================
                //           Delete from .order
                // ======================================
                
                $delete_item = path($delete_path, "filename");
                $path = path($delete_path, "dirname");
                $folder = array_pop(split("/", $path));
                $order_path = "$path/$folder.order";
                if(file_exists($order_path)) {
                    echo "<h2>REMOVE FROM ORDER LIST</h2>\n";
                    $file_content = array_map("trim", file($order_path));
                    $new_content = array();
                    foreach($file_content as $item) {
                        if($item != $delete_item) { $new_content[] = $item; };
                    };
                };
                if(count($new_content) < count($file_content) && safeSave($order_path, join("\n", $new_content))) {
                    
                    echo "<p class='done'>Item <a href='$delete_item'>$delete_item</a> removed from order file:<a href='$order_path'>$order_path</a></p>\n";  
                }
                else {
                    echo "<p class='error'>Failed to remove <a href='$delete_item'>$delete_item</a>from order file:<a href='$order_path'>$order_path</a></p>\n";
                    $errors++;
                };
            
                // ======================================
                //            Delete the page
                // ======================================
            
                if($errors > 0) {
                    echo "<p class='error'>Page not removed due to previous errors ($errors)</p>\n";
                }
                else {
                    echo "<h2>DELETE THE PAGE</h2>\n";
                    rename($delete_path, $delete_path.".bak");
                    if(!file_exists($delete_path)) {
                        echo "<p class='done'>Page removed: <a href='$delete_path'>$delete_path</a></p>\n";
                    }
                    else {
                        echo "<p class='error'>Failed to remove: <a href='$delete_path'>$delete_path</a></p>\n";
                        $errors++;
                    };
                };


                
				if(file_exists($delete_path)) {
					$get = "?path=$delete_path&popup=".urlencode("Nie udało się usunąć strony|error");
                    echo "<input type='hidden' id='back_path' value='$save_path'>\n";
				}
				else {
					$get = "?popup=".urlencode("Strona została usunięta|done");
                    echo "<input type='hidden' id='back_path' value='$root/settings.xml'>\n";
				};
				echo "<a href='index.php$get'><button>Back to editor</button></a>\n";
                // Errors count output for js action
                echo "<input type='hidden' id='errors' value='$errors'>\n";

            ?>
        </article>
        <script src='../script/jquery-1.11.2.min.js'></script>
        <script>
            $(document).ready(function() {
                errors = parseInt( $("#errors").val() );
                if(errors == 0) {
                    path = $("#back_path").val();
                    setTimeout(function() {
                        //location.href = "index.php?path=" + encodeURIComponent(path) + "&popup=" + encodeURIComponent("Strona została usunięta|done");
                    }, 1000);
                    $("article").show();
                    $("#loader").fadeOut(200);
                }
                else {
                    $("article").show();
                    $("#loader").fadeOut(200);
                };
            });
        </script>
    </body>
</html>