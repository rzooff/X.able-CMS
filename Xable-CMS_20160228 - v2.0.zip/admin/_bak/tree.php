<style>
	* { padding: 0; margin: 0; font-family: 'Arial'; }
	
			#tree details, p { padding-left: 20px; }				/* Level indent */
			#tree .enabled { cursor: pointer; }						/* Enabled folders */
			#tree .disabled { display: none; }	/* Disabled folders */
			#tree summary { font-weight: bold; }					/* All folders */
			#tree .file { cursor: default; }						/* Valid files */
			#tree .filtered { opacity: 0.33; cursor: no-drop; }		/* Filtered out files */
			#tree summary:focus { outline: none; }					/* Focus frame off */
</style>


<?php
    $ini_file = "xable.ini";
    require "script/functions.php";
    require "script/xml.php";
    
    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $settings = loadXml($ini_pathes['settings']);
    //$nav_documents = loadIni($ini_file, "navigation");
	//arrayList($settings);


	//echo path("index.php", "size");
	
	

        
	echo "<div id='tree'>\n";
    htmlTree($root, "kind", "php", array("$root/admin", "$root/.ps"));
	echo "</div>\n";

?>

    

