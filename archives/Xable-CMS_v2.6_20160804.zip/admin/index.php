<?php
    // ======================================
    //              ><.able CMS
    //        (C)2016 maciejnowak.com
    //          v.2.6 build.20160806
    // ======================================
	// compatibile: php5.4+ or higher
    
    session_start();
    if(!is_string($_SESSION['logged_user'])) {
        header("Location: login.php");
        break;
    };

    require "script/functions.php";
    require "script/cms.php";
    require "script/xml.php";

    $ini_file = $_SESSION['ini_file'];
    $ini_pathes = loadIni($ini_file, "pathes");
    $ini_enable = loadIni($ini_file, "enable");
    $root = $ini_pathes['root'];
    $settings = loadXml($ini_pathes['settings']);
    $nav_documents = loadIni($ini_file, "navigation");
    //arrayList($nav_documents);

    $site_options = loadIni("xable.ini", "options");

?>

<!doctype html>
<html>
	<head>
        <!-- Loader Style -->
        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }
        </style>
        <!-- Loader Style / end -->
		<meta charset="UTF-8">
		<title>X.able CMS / Editor</title>
		
		<link rel="stylesheet" type="text/css" href="style/index.css" />
		<link rel="stylesheet" type="text/css" href="style/nav.css" />
		<link rel="stylesheet" type="text/css" href="style/cms.css" />
        <!-- <link rel="stylesheet" type="text/css" href="style/csv.css" /> -->
        <link rel="stylesheet" type="text/css" href="style/colors.css" />
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		
        <script src='script/jquery-1.11.2.min.js'></script>
        <script src='script/functions.js'></script>
        <script src='script/footer.js'></script>

	</head>
	<body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        
        <?php
        
            // ====== LANGUAGE ======
            $languages = array();
            foreach($settings['multi_language'] as $lang_data) {
                //if(readXml($lang_data, "active") != "") {
                    $id = readXml($lang_data, "id");
                    $languages[] = $id;
                //};
            };
            $admin_lang = "pl";
            $lang = $_GET['lang'];
            if(!is_string($admin_lang)) {
                $languages = array( "pl" );
                $admin_lang = "pl";
            };
            if(!is_string($lang) || $lang == "") { $lang = $admin_lang; };
            // Read auto translate dictionary
            $translate_dictionary = file_get_contents("dictionary.csv");
            $translate_dictionary = str_replace("\n", "|", $translate_dictionary);

            // ====== EDIT PATH ======
            $path = $_GET['path'];
            if(!is_string($path) || $path == "" || !file_exists($path)) {
                $path = getFirstPath($nav_documents, $root);
            };

            // ====== SAVE PATH ======
            if(is_string($_GET['saveas']) && $_GET['saveas'] != "") {
                $saveas = path($path, "dirname")."/".$_GET['saveas'];
            }
            else {
                $saveas = $path;
            };
        
            // ====== POPUP ======
            if(is_string($_GET['popup']) && $_GET['popup'] != "") {
                echo "\t\t<input type='hidden' id='popup' value='".$_GET['popup']."'>\n";
            };
        
            echo "\n";
        
            // ======================================
            //            Send variables
            // ======================================
            
            echo "\t\t<input type='hidden' id='root' value='".$root."'>\n";
            echo "\t\t<input type='hidden' id='path' value='".$path."'>\n";
            echo "\t\t<input type='hidden' id='saveas' value='".$saveas."'>\n";
            echo "\t\t<input type='hidden' id='languages' value='".join(",", $languages)."'>\n";
            echo "\t\t<input type='hidden' id='lang' value='".$lang."'>\n";
            echo "\t\t<input type='hidden' id='admin_lang' value='".$admin_lang."'>\n";
            echo "\t\t<input type='hidden' id='translate_dictionary' value='".str_replace("\n", "\|", $translate_dictionary)."'>\n";
        
            foreach(array_keys($ini_enable) as $key) {
                echo "\t\t<input type='hidden' id='enable_$key' value='".$ini_enable[$key]."'>\n";
            };
            //arrayList($site_options);
            foreach(array_keys($site_options) as $key) {
                echo "\t\t<input type='hidden' id='site_$key' value='".$site_options[$key]."'>\n";
            };

            include("_nav.php");
            
            if(path($path, "extension") == "xml" || path($path, "extension") == "template") { include("_xml.php"); }
            elseif(path($path, "extension") == "order") { include("_order.php"); }
            elseif(path($path, "extension") == "csv") { include("_csv.php"); }
            else { include("_text.php"); };
        
            // ======================================
            //            Template script
            // ====================================== 
            if(path($path, "extension") == "template") {
                echo "\t\t<script src='script/template.js'></script>\n";
            };

        ?>
        
		<script src='script/cms.js'></script>
        <div id='libraries_data'>
<?php

    // ===============================
    //           Libraries
    // ===============================
	
    function sendLibrary($lib, $lib_path, $root) {
        echo "\t\t\t<div class='$lib' path='$path'>\n";
		// ====== xml data based content ======
		if(path($lib_path, "extension") == "xml") {
			$xml = loadXml("$root/$lib_path");
			foreach($xml['multi_folder'] as $folder) {
				$name = readXml($folder, "name");
				$files = readXml($folder, "files");
				if($name != "" && $files != "" && !is_dir("$root/$files")) {
					echo "\t\t\t\t<div class='folder'>\n";
					echo "\t\t\t\t\t<p class='name help' help='Pokaż / ukryj zawartość folderu'><span class='fi-folder'></span>$name</p>\n";
					echo "\t\t\t\t\t<ul>\n";
					foreach(split(";", $files) as $file) {
						if($file != "" && file_exists("$root/$file") && !is_dir("$root/$file")) {
							if(strstr(strtolower($lib), "images")) {
								echo "\t\t\t\t\t\t<li class='image' value='$file'><figure class='' style='background-image:url(\"$root/$file\")'></figure><p clas='filename'>".path($file, "basename")."</p><p class='details'>".path("$root/$file", "size")." kB</p></li>\n";
							}
							else {
								echo "\t\t\t\t\t\t<li class='file' value='$file'><p class=''>".path($file, "basename")." <span class='details'>(".path("$root/$file", "size")." kB)</span></p></li>\n";
							};
						};
					};
					echo "\t\t\t\t\t</ul>\n";
					echo "\t\t\t\t</div>\n";
				};
			};
		}
		// ====== folder files based content ======
		else {
			echo "\t\t\t\t<div class='folder'>\n";
			echo "\t\t\t\t\t<p class='name help' help='Pokaż / ukryj zawartość folderu'><span class='fi-folder'></span>$name</p>\n";
			echo "\t\t\t\t\t<ul>\n";
			foreach(listDir("$root/$lib_path", "xml") as $file) {
				$xml = loadXml("$root/$lib_path/$file");
				$title = readXml($xml, "header title");
				if($title == "") { $title = path("$root/$lib_path/$file", "filename"); };
				$mod_time = path("$root/$lib_path/$file", "modified");
				$relative = split("/", $lib_path);
				array_shift($relative); // cut off "pages/" from url
				$link = "index.php?page=".join("/", $relative)."/".path($file, "filename");
				echo "\t\t\t\t\t\t<li class='file' value='$link'><p class=''>$title <span class='details'>(mod: $mod_time)</span></p></li>\n";
			};
			echo "\t\t\t\t\t</ul>\n";
			echo "\t\t\t\t<div>\n";
		};
		echo "\t\t\t</div>\n";
    };

    $libraries = array();
    $libraries["images_lib"] = "pages/_repository/images.xml";
    $libraries["files_lib"] = "pages/_repository/files.xml";
    $libraries["temp_lib"] = "pages/_temp";
            
    foreach(array_keys($libraries) as $lib) {
        $lib_path = $libraries[$lib];
        if(file_exists("$root/$lib_path")) {
            sendLibrary($lib, $lib_path, $root);
        };
    };
        
?>
        
        </div>
	</body>
</html>

