$(document).ready(function() {
	
	// Add names to all inputs
	$("form select, form input").each(function() { $(this).attr("name", $(this).attr("class")); });
	
    // ==========================================
    //                 Menu bar
    // ==========================================

	// Show menu dropdown
    $("nav label.menu").mouseenter(function() {
        $(this).find("ul").stop().show(200);
        $(this).find("p").css({ "opacity": "0.25" });
    });

	// Hide menu dropdown
    $("nav label.menu").mouseleave(function() {
        $(this).find("ul").stop().hide(100);
        $(this).find("p").css({ "opacity": "1" });
    });
    
	// Menu actions
	$("nav li").click(function() {
		// Hide dropdown
        $(this).closest("label").find("ul").stop().hide(100);
        $(this).closest("label").find("p").css({ "opacity": "1" });
        // Actions
		action = $(this).html().replace(/&nbsp;/g, "_").toLowerCase();
		if(action == "quit") {
            if(confirm("Are you sure?")) {
                location.href = "index.php";
            };
        }
		else if(action == "users" || action == "creator") {
            location.href = action + ".php";
        }
    });
    
    // ==========================================
    //                   Edit
    // ==========================================
    
    $("article, section").fadeIn(200);
    
    $("details").click(function() { $(this).focusout(); });
    
    $("article button").click(function() {
        location.href = "installer.php?action=installer"; 
    });
    
    
    
});