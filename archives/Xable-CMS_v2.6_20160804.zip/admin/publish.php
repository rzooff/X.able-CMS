<?php
    session_start();

    $_SESSION['nav_array'] = false;

    if(!is_string($_SESSION['logged_user'])) {
        header("Location: login.php");
        break;
    };

    require "script/functions.php";
    require "script/cms.php";
    require "script/xml.php";
    require "script/upload_images.php";
	
	$ini_file = $_SESSION['ini_file'];
    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $settings = loadXml($ini_pathes['settings']);
    $errors = 0; // Errors number - if any, saving changes will be blocked
    $debug_mode = false; // true will not redirect back to index & show console log
	
    //echo "<hr><h3>GET</h3><hr>";
    //arrayList($_GET);
    //echo "<hr><h3>POST</h3><hr>";
    //arrayList($_POST);
    //echo "<hr><h3>FILES</h3><hr>";
	//arrayList($_FILES);
	//echo "<hr><h3>XML</h3><hr>";
	//echo "\n<textarea cols=100 rows=50>".$_POST['xml']."</textarea>\n";
    //echo "<hr>\n";

?>

<html>
    <head>
		<meta charset='utf-8'>
        <title>X.able CMS / Publish</title>
        <link href='http://fonts.googleapis.com/css?family=Inconsolata:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>

        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }

            /* ================================== */
            /*              Console               */
            /* ================================== */
            
            body {
                width: 100%;
                height: 100%;
                padding: 0 20px;
                font-family: 'Inconsolata';
                font-size: 14px;
                font-weight: normal;
            }

            article{ display: none; }
            * { margin: 0; padding: 0; }
            h2 { padding-top: 20px; font-size: 18px; font-weight: bold; }
            p { padding-top: 1px; }
            p span { margin-right: 10px; }
            .info { font-size: 11px; }
            .done { color: #22aa22; }
            .log { color: #999999; }
            .error { color: #ff0000; font-weight: bold; }
            .error:before { content: "ERROR! "; }
            textarea { width: 700px; height: 500px; }
            button { margin-top: 20px; padding: 10px; }
            
        </style>
    </head>
    <body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        <article>
            <?php

                // ======================================
                //            Main variables
                // ======================================

                // File path
                $edit_path = $_POST['edit_path'];
                $save_path = $_POST['save_path'];
                $lang = $_POST['language_set'];
                if(!is_string($save_path) || $save_path == "") { $save_path = $edit_path; };
                // Get edited file content
                $file_type = path($save_path,"extension");
                $file_content = $_POST["output|$file_type"];
                // Media size
                $media_size = $settings['media'][0]['multimedia_size'][0]['string'][0];
            
                // ======================================
                //         DELETE FILES & FOLDERS
                // ======================================

                echo "<h2>DELETE FILES & FOLDERS</h2>\n";
                // Files
                if($_POST['delete_files'] != "") {
                    foreach(split(";", $_POST['delete_files']) as $file) {
                        $file = urldecode($file);
                        if(file_exists("$root/$file")) {
                            unlink("$root/$file");
                            if(!file_exists("$root/$file")) {
                                echo "<p class='done'>File deleted: <a href='$root/$file'>$root/$file</a></p>\n";
                            }
                            else {
                                echo "<p class='error'>Failed to delete file: <a href='$root/$file'>$root/$file</a></p>\n";
                                $errors++;
                            };
                        }
                        else {
                            echo "<p class='log'>File not found: <a href='$root/$file'>$root/$file</a></p>\n";
                        };
                    };
                }
                else {
                    echo "<p class='log'>No files to delete found</p>\n";
                };
                // Folders
                if($_POST['delete_folders'] != "") {
                    foreach(split(";", $_POST['delete_folders']) as $folder) {
                        if(removeDir("$root/$folder")) {
                            echo "<p class='done'>Folder deleted: <a href='$root/$file'>$root/$file</a></p>\n";
                        }
                        else {
                            echo "<p class='error'>Failed to delete folder: <a href='$root/$file'>$root/$file</a></p>\n";
                            $errors++;
                        };
                    };
                }
                else {
                    echo "<p class='log'>No folders to delete found</p>\n";
                };

                // ======================================
                //             UPLOAD FILES
                // ======================================

                echo "<h2>UPLOAD FILES</h2>\n";
                echo "<p class='info'>Max media size: $media_size px</p>\n";
                foreach(array_keys($_POST) as $key) {
                    // Find upload input names
                    $prefix = "upload|";
                    if(substr($key, 0, strlen($prefix)) == $prefix) {
                        $id = substr($key, strlen($prefix));
                        $val = $_POST[$key];
                        if($val != "") {
                            echo "> id: $id, val: $val<br>";
                            // Extract value data, eg: "mode:name_1.ext;name_2.ext"
                            //echo "val: $val<br>\n";
                            $val = split(":", $val);
                            $mode = array_shift($val);
                            $names = join(":", $val);
                            //echo "names: $names<br>\n";
                            // Set mode variable for uploadRenameImages()
                            //if($mode == "force") { $mode = "force:".path($names, "filename"); };
                            $mode = array();
                            foreach(split(";", $names) as $rename) {
                                $mode[] = path($rename, "filename");
                            };
                            $mode = "force:".join(";", $mode);
                            // Find uploaded files
                            if(is_array($_FILES) && is_array($file_data = $_FILES[$id])) {
                                // Destination folder (create if needed)
                                $folder = $root."/".path( array_shift( split(";", $names) ), "dirname" );
                                //echo "folder -> $folder<br>\n";
                                //echo "mode -> $mode<br>\n";
                                
                                if(makeDir($folder)) {
                                    if(uploadRenameImages($id, $folder, "max:$media_size", $mode)) {
                                        echo "<p class='done'>[$id] File(s) uploaded to: <a href='$folder'>$folder</a></p>\n";
                                    }
                                    else {
                                        echo "<p class='error'>[$id] Failed to upload to: <a href='$folder'>$folder</a></p>\n";
                                        //$errors++;
                                    };
                                }
                                else {
                                    echo "<p class='error'>[$id] Failed to access to: <a href='$folder'>$folder</a></p>\n";
                                    $errors++;
                                };
                                
                            };
                        }
                        else {
                            echo "<p class='log'>[$id] Nothing to upload</p>\n";
                        };
                    };
                };

                // ======================================
                //             SAVE CMS FILE
                // ======================================

                echo "<h2>SAVE CMS FILE</h2>\n";
                if($errors > 0) {
                    echo "<p class='error'>File not saved due to previous errors ($errors)</p>\n";
                }
                elseif(is_string($file_content) && $file_content != "") {
                    // Add XML declaration to .xml file
                    if($file_type == "xml") { $file_content = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".$file_content; };
                    // Save file content
					echo "<h2>FILE CONTENT PREVIEW</h2>\n<textarea>".$file_content."</textarea><br>\n";
                    if($debug_mode != true) {
                        // Save begin
                        if(safeSave($save_path, $file_content)) {
                            echo "<p class='done'>File saved successfully: <a href='$save_path'>$save_path</a></p>\n";
                        }
                        else {
                            echo "<p class='done'>File to save file: <a href='$save_path'>$save_path</a></p>\n";
                            $errors++;
                        };
                        // Save end
                    }
                    else {
                         echo "<p class='log'>DEBUG MODE -> file not saved: <a href='$save_path'>$save_path</a></p>\n";
                        $errors = -1;
                    };
                }
                else {
                    echo "<p class='error'>Lack of file content to save!</p>\n";
                    $errors++;
                };
            
                // ======================================
                //         ADD NEW PAGE TO .ORDER
                // ======================================
                
                if($errors == 0 && $save_path != $edit_path) {
                    $path = path($save_path, "dirname");
                    $folder = array_pop(split("/", $path));
                    $order_path = "$path/$folder.order";
                    if(file_exists($order_path)) {
                        echo "<h2>ORDER</h2>\n";
                        $new_page = path($save_path, "filename");
                        $file_content = array_map("trim", file($order_path));
                        
                        //array_unshift($file_content, $new_page); // add on the top
                        $file_content[] = $new_page; // add on the bottom
                        
                        if(safeSave($order_path, join("\n", $file_content))) {
                            echo "<p class='done'>New page: <a href='$path/$new_page'>$new_page</a> added to order file: <a href='$order_path'>$order_path</a></p>\n";
                        }
                        else {
                            echo "<p class='error'>Faild to add page: <a href='$path/$new_page'>$new_page</a> to order file: <a href='$order_path'>$order_path</a></p>\n";
                            $errors++;
                        };
                    };
                };
                    
                // ======================================
                // Errors count output for js action
                echo "<input type='hidden' id='errors' value='$errors'>\n";
                echo "<input type='hidden' id='save_path' value='$save_path'>\n";
                echo "<input type='hidden' id='lang' value='$lang'>\n";
            
                echo "<a href='index.php?path=$save_path&popup=".urlencode("Zmiany nie zostały zapisane|error")."'><button>Back to editor</button></a>\n";

            ?>
        </article>
        <script src='script/jquery-1.11.2.min.js'></script>
        <script>
            $(document).ready(function() {
                errors = parseInt( $("#errors").val() );
                if(errors == 0) {
                    path = $("#save_path").val();
                    setTimeout(function() {
                        location.href = "index.php?path=" + encodeURIComponent(path) + "&lang=" + $("#lang").val() + "&popup=" + encodeURIComponent("Zmiany zostały zapisane|done");
                    }, 1000);
                    //$("article").show();
                    //$("#loader").fadeOut(200);
                }
                else {
                    $("article").show();
                    $("#loader").fadeOut(200);
                };
            });
        </script>
    </body>
</html>