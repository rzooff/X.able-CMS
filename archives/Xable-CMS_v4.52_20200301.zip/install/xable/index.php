<?php
    error_reporting(0);

	session_start();
	require "script/functions.php";
	require "script/xml.php";

    //$updated = "20190701-1400";
    $updated = uniqid();

    $date_format = "dd-mm-yyyy";
    $keys_translator = [
        "date" => "Data: ",
        "localization" => "Miejsce: ",
        "investor" => "Inwestor: ",
        "text" => "",
    ];

    // ====================================
    //           Global Variables
    // ====================================

    // Master documents
	$settings = loadXml("settings.xml", "draft");
	$navigation = loadXml("navigation.xml", "draft");

    // Patches
	$pages = "pages";
    $error_404 = "404";
    $plugins_folder = "_plugins";
    $link_pattern = readXml($settings, "page link_pattern");

    // Get all active languages
    $languages = [];
    foreach($settings["multi_language"] as $language) {
        if(readXml($language, "active") != "") { $languages[] = readXml($language, "id"); };
    };
    // Set default (first) language in none
    if(!isset($_SESSION["lang"]) || !in_array($_SESSION["lang"], $languages)) { $_SESSION["lang"] = $languages[0]; };

    // RewriteEngine & ROOT
    if(!isset($_GET["page"])) { $_GET["page"] = ""; };
    if($_GET['page'] != "") { $root = str_repeat("../", count(explode("/", $_GET['page']))); }
    else { $root = ""; };
    
    // ====================================
    //         Draft preview support
    // ====================================

    $start_preview = "xable-preview";
    $stop_preview = "xable-nopreview";

    $path = explode("/", $_GET["page"]);
    if(in_array( $path[0] , [ $start_preview, $stop_preview ])) {
        if($path[0] == $start_preview) { $_SESSION['preview_mode'] = "draft"; }
        else { $_SESSION['preview_mode'] = false; };
        array_shift($path);
        $_GET["page"] = join("/", $path);
        if($_GET["page"] == "") { $redirect = $root; }
        else { $redirect = $root.$_GET["page"]."/"; }
        //echo "<!-- Preview status changed\n\tRedirect: \"".$redirect."\"\n-->\n";
        header("Location: ".$redirect); exit();
    }
    //echo "<!-- [Xable data]\n\tPAGE: \"".$_GET["page"]."\"\n\troot: \"".$root."\"\n\tlink_pattern: \"$link_pattern\"\n\tpreview_mode: \"".$_SESSION['preview_mode']."\"\n\tlang: \"".$_SESSION["lang"]."\"\n-->\n";

    // ====================================
    //         URL language & path
    // ====================================

    $path_key = "@path";
    $lang_key = "@language";

    $link_data = getLinkData($_GET["page"], $link_pattern, $path_key);
    // Check path and language input
    foreach(array_filter(explode("/", $link_pattern)) as $key) {
        $val = $link_data[$key];
        if($key == $path_key && $val == "") {
            $link_data[$key] = ReadXml($navigation["multi_page"][0], "href");
        }
        elseif($key == $lang_key) {
            if(in_array($val, $languages)) {
                $_SESSION["lang"] = $val;
            }
            else {
                $link_data[$key] = $_SESSION["lang"];
            }
        };
    };

    // ====================================
    //               Sitemap
    // ====================================

    $sitemap_tree = getSitemap($navigation, $pages, "xml", "draft");
    $offsite_tree = getOutmap($navigation, $pages, "xml", "draft");
    //echo "<!-- [Sitemap]\n"; arrayList($sitemap_tree); echo "-->\n";
    //echo "<!-- [Outside]\n"; arrayList($offsite_tree); echo "-->\n";
    $pages_index = getPagesIndex(array_merge($sitemap_tree, $offsite_tree));
    $off_index = getPagesIndex($offsite_tree);
    //echo "<!-- [Index]\n"; arrayList($pages_index); echo "-->\n";
    //echo "<!-- [Off Index]\n"; arrayList($off_index); echo "-->\n";

    // ====================================
    //            Verify patch
    // ====================================

    // Test if the path is an existsing document (option 1)
    //if(is_array($xml = loadXml($pages."/".$link_data[$path_key].".xml", "draft"))) {
    // Test if the patch is on the pages index (option 2)
    if(isset($pages_index[$link_data[$path_key]])) {
        $link_get = join("/", array_filter(explode("/", $_GET["page"])));
        $link_test = join("/", $link_data);
        if($link_get != $link_test) {
            $redirect = $root.$link_test."/";
            //echo "<!-- [Fixed link]\n\tRedirect: \"".$redirect."\"\n-->\n";
            header("Location: ".$redirect); exit();
        }
    }
    else {
        foreach(array_keys($link_data) as $key) {
            if(!in_array($key, [ $path_key, $lang_key ])) { $link_data[$key] = ""; };
        }
        $link_data[$path_key] = $error_404;
        $redirect = $root.join("/", $link_data)."/";
        //echo "<!-- [ERROR 404 - Page not found]\n\tRedirect: \"".$redirect."\"\n-->\n";
        header("Location: ".$redirect); exit();
    };

    // ====================================
    //             PAGE DATA
    // ====================================

    /*
    $pages_list = [];
    if(strstr($link_data[$path_key], "/")) {
        echo "<!-- SUBPAGE: ".$link_data[$path_key]." -->\n";
        $pages_list[] = $link_data[$path_key];
    }
    else {
        echo "<!-- MAIN PAGE: ".$link_data[$path_key]." -->\n";
        foreach($navigation['multi_page'] as $page) {
            $active = readXml($page, "active");
            $href = readXml($page, "href");
            $title = readXml($page, "title");
            $page_path = "$pages/$href.xml";
            if($active != "" && $title != "" && file_exists($page_path)) {
                $pages_list[] = $href;
            }
        }
    };
    */
    if(strstr($link_data[$path_key], "/")) {
        $_SESSION["show_project"] = $link_data[$path_key];
        $redirect = $root.array_shift(explode("/", $link_data[$path_key]))."/";
        //echo "> $redirect\n";
        header("Location: ".$redirect); exit();
    }
    echo "<!-- ONE PAGE SITE: ".$link_data[$path_key]." -->\n";
    foreach($navigation['multi_page'] as $page) {
        $active = readXml($page, "active");
        $href = readXml($page, "href");
        $title = readXml($page, "title");
        $page_path = "$pages/$href.xml";
        if($active != "" && $title != "" && file_exists($page_path)) {
            $pages_list[] = $href;
        }
    }

    // ====================================
    //           Load statistics
    // ====================================

    $statistics_xml = loadXml("statistics.xml", "draft");
    $statistics = [];
    foreach($statistics_xml["multi_statistics"] as $stats) {
        $val = getVal($stats);
        if($val["active"] != "") {
            if(trim($val["code"]) != "" && $val['location'] != "") {
                if(!isset($statistics[$val['location']])) { $statistics[$val['location']] = []; };
                $statistics[$val['location']][] = "<!-- Statistics: ".$val['name']." -->\n".getCode($val['code']);
            }
        }
    };

    // ====================================
    // ====================================
    // ====================================
    //              Functions
    // ====================================
    // ====================================
    // ====================================

    function testFile($val) {
        $file = array_shift(explode(";", $val));
        if(count(explode("://", $val)) == 2 || ($file != "" && !is_dir($file) && file_exists($file))) {
            return $val;
        }
        else {
            return false;
        }
    };

?>

<!doctype html>

<html>
	<head>

        <!--
            This website is powered by X.able CMS
            Copyright by maciej@maciejnowak.com

            Design & development: maciejnowak.com
        -->
        <?php foreach($statistics['head'] as $code) { echo "\n".$code."\n"; }; ?>
        
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta charset="UTF-8">
		<meta http-equiv="Content-Language" content="<?php echo $_SESSION['lang']; ?>">
		<title><?php echo readXml($settings, "page title"); ?></title>
        <meta name="description" content="<?php echo readXml($settings, "page description"); ?>"/>
        <meta name="keywords" content="<?php echo readXml($settings, "page keywords"); ?>"/>
        <link rel='canonical' href='https://<?php echo readXml($settings, "page domain"); ?>' />
        
        <!-- ====== Favicon: https://realfavicongenerator.net ====== -->
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $root; ?>_favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $root; ?>_favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $root; ?>_favicon/favicon-16x16.png">
        <link rel="manifest" href="<?php echo $root; ?>_favicon/site.webmanifest">
        <link rel="mask-icon" href="<?php echo $root; ?>_favicon/safari-pinned-tab.svg" color="#5bbad5">
        <link rel="shortcut icon" href="<?php echo $root; ?>_favicon/favicon.ico">
        <meta name="msapplication-TileColor" content="#da532c">
        <meta name="msapplication-config" content="<?php echo $root; ?>_favicon/browserconfig.xml">
        <meta name="theme-color" content="#ffffff">
        
        <!-- ====== FACEBOOK ====== -->

		<meta property='fb:admins' content='maciej.nowak.5832'/> <!-- Maciek -->
		<meta class='share-url' property='og:url' content='https://<?php echo readXml($settings, "page domain"); ?>' />
		<meta class='share-type' property='og:type' content='website' />
		<meta class='share-title' property='og:title' content='<?php echo readXml($settings, "page title"); ?>' />
		<meta class='share-description' property='og:description' content='<?php echo readXml($settings, "page description"); ?>' />
		<meta class='share-image' property='og:image' content='https://<?php echo readXml($settings, "page domain")."/".readXml($settings, "media thumb"); ?>' />

        <!-- ====== CSS / might be moved to HEAD via js ====== -->
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>style/layout.css<?php echo "?v=$updated"; ?>">
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>style/layout-mobile.css<?php echo "?v=$updated"; ?>">
        
        <!-- ====== ICONS ====== -->
        <!-- <script src="https://unpkg.com/ionicons@4.5.10-0/dist/ionicons.js"></script> -->
        <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
        
        <!-- ====== FONTS ====== -->
        <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700|Audiowide&amp;subset=latin-ext" rel="stylesheet">
        
        <style>
            #loader {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: #fff;
                z-index: 9999;
            }
        </style>

	</head>

	<body>
        
        <div id='loader'></div>
        
        <?php foreach($statistics['body'] as $code) { echo "\n".$code."\n"; }; ?>
        
        <main>
            <?php
            
                if(isset($_SESSION["show_project"]) && $_SESSION["show_project"] != "") {
                    echo "\n\t\t\t<input type='hidden' id='show_project' value='".$_SESSION["show_project"]."'>\n";
                    unset($_SESSION["show_project"]);
                }

                echo "\n";

                // ===============================
                //          MAIN CONTENT
                // ===============================
            
                $site_map = [];

                foreach($pages_list as $href) {
                    $page_path = "$pages/$href.xml";
                    if($xml = loadXml($page_path, "draft")) {
                        
                        $id = makeId($href);
                        $site_map[$id] = readXml($xml, "header title");
                        echo "<!-- $href -->\n";
                        // ===============================
                        //        PROJECT SUBPAGES
                        // ===============================
                        if(file_exists("$pages/$href/.order1")) {
                            
                            $title = readXml($xml, "header title");
                            echo "\t\t\t<div class='projects_box'>\n";
                            echo "\t\t\t\t<section class='projects_group' id='".$id."'>\n";
                            echo "\t\t\t\t\t<h2 class='slide_up'>".$title."</h2>\n";

                            $categories = [];
                            foreach(readXml($xml, "categories _categories_list") as $cat) {
                                $cat = explode(";", $cat);
                                $categories["key_".$cat[0]] = $cat[1];
                            };
                            echo "\t\t\t\t\t<ul class='categories_filter slide_up'>\n";
                            echo "\t\t\t\t\t\t<li class='current' data-value='key_all'>Wszystkie</li>\n";
                            foreach(array_keys($categories) as $key) {
                                echo "\t\t\t\t\t\t<li class='active' data-value='".$key."'>".$categories[$key]."</li>\n";
                            }
                            echo "\t\t\t\t\t</ul>\n";

                            $order = loadXml("$pages/$href/.order");

                            foreach($order["multi_item"] as $item) {
                                $sub_path = readXml($item, "path");
                                $sub_xml = loadXml("$pages/$href/$sub_path");
                                $sub_href = "$href/".path($sub_path, "filename");
                                
                                if(testFile($images = readXml($sub_xml, "gallery images"))) {
                                    $images = explode(";", $images);
                                    echo "\t\t\t\t\t<article class='slide_up project ".readXml($sub_xml, "header _category")."' data-path='$sub_href'>\n";

                                    echo "\t\t\t\t\t\t<figure class='image' style='background-image:url(\"".$root.$images[0]."\")'></figure>\n";

                                    echo "\t\t\t\t\t\t<div class='text_box'>\n";
                                    echo "\t\t\t\t\t\t\t<p class='date'>".substr(readXml($sub_xml, "header date"), 0, 4)."</p>\n";
                                    echo "\t\t\t\t\t\t\t<h3>".BBCode(readXml($sub_xml, "header title"))."</h3>\n";
                                    echo "\t\t\t\t\t\t\t<p class='text'>".BBCode(readXml($sub_xml, "header text"), true)."</p>\n";
                                    foreach($images as $image) {
                                        echo "\t\t\t\t\t\t\t<input type='hidden' class='image' value='".$root.$image."'>\n";
                                    };
                                    echo "\t\t\t\t\t\t</div>\n";
                                    echo "\t\t\t\t\t</article>\n";
                                }

                            };
                            echo "\t\t\t\t</section>\n";
                            echo "\t\t\t</div>\n";
                            
                        }
                        
                        
                        else {
                            echo "\t\t\t<div class='section_box'>\n";
                            echo "\t\t\t\t<section class='standard' id='".$id."'>\n";
                            
                            foreach(array_keys($xml) as $article_name) {
                                if(substr($article_name, 0, 1) != "_") {
                                    
                                    echo "\t\t\t\t\t<div class='article_box ".$article_name."_box'>\n";

                                    $article_group = $xml[$article_name];

                                    foreach(array_keys($article_group) as $article_num) {

                                        $article = $article_group[$article_num];
                                        $val = getVal($article);

                                        if($id == "start") {
                                            //arrayList($val);
                                            echo "\t\t\t\t\t\t<div class='bg bg_image' style='background-image:url(\"".$root.$val["background"]."\")'></div>\n";
                                            echo "\t\t\t\t\t\t<div class='bg bg_fade'></div>\n";
                                            
                                            echo "\t\t\t\t\t\t<article class='".$article_name."'>\n";
                                            
                                            $logo = "<span class='big'>&gt;&lt;</span>.able<span class='small'>CMS</span>";
                                            echo "\t\t\t\t\t\t\t<h1>$logo</h1>\n";
                                            
                                            echo "\t\t\t\t\t\t\t<div class='text_box vertical_center'>\n";
                                            echo "\t\t\t\t\t\t\t\t<h3 class='headline'>".BBCode($val["headline"], true)."</h3>\n";
                                            echo "\t\t\t\t\t\t\t\t<p class='text'>".BBCode($val["text"], true)."</p>\n";
                                            echo "\t\t\t\t\t\t\t\t<div class='button_box'><button class='scrolldown'>".$val["scrolldown"]."</button></div>\n";
                                            echo "\t\t\t\t\t\t\t</div>\n";
                                            echo "\t\t\t\t\t\t\t<div class='image_box'><img src='".$root.$val["image"]."'></div>\n";
                                            
                                            echo "\t\t\t\t\t\t</article>\n";

                                        }
                                        elseif($article_name == "header") {

                                            echo "\t\t\t\t\t\t<article class='slide_up ".$article_name."'>\n";
                                            echo "\t\t\t\t\t\t\t<div class='text_box'>\n";
                                            echo "\t\t\t\t\t\t\t\t<h2 class='title'>".$val["title"]."</h2>\n";
                                            echo "\t\t\t\t\t\t\t\t<p class='text'>".BBCode($val["text"], true)."</p>\n";
                                            echo "\t\t\t\t\t\t\t</div>\n";
                                            echo "\t\t\t\t\t\t</article>\n";

                                        }
                                        elseif($article_name == "multi_post") {
                                            //arrayList($val);
                                            if(testFile($val["image"])) {
                                                $class = "image_post";
                                                $image = $val["image"];
                                            }
                                            else {
                                                $class = "text_post";
                                                $image = false;
                                            };
                                            echo "\t\t\t\t\t\t<article class='slide_up $class $article_name'>\n";
                                            echo "\t\t\t\t\t\t\t<div class='text_box vertical_center'>\n";
                                            if(isset($val["icon_font"]) && $val["icon_font"] != "") {
                                                echo "\t\t\t\t\t\t\t\t<div class='icon_box'><ion-icon name='".$val["icon_font"]."'></ion-icon></div>\n";
                                            }
                                            echo "\t\t\t\t\t\t\t\t<h4 class='title'>".$val["title"]."</h4>\n";
                                            echo "\t\t\t\t\t\t\t\t<p class='text'>".BBCode($val["text"], true)."</p>\n";
                                            
                                            if(isset($val["folder_path"]) && $val["folder_path"] != "" && ($files_list = listDir($val["folder_path"], ".,?"))) {
                                                //arrayList($files_list);
                                                $max_date = 0;
                                                $downloads = [ "other" => [], "installer" => [] ];
                                                $key_names = [ "other" => "Dodatkowe pliki", "installer" => "Wersje archiwalne" ];

                                                foreach($files_list as $file) {
                                                    $ext = path($file, "extension");
                                                    if($ext == "zip") {
                                                        $date = intval(array_pop(explode("_", path($file, "filename"))));
                                                        $downloads["installer"][$date] = $file;
                                                    }
                                                    elseif($ext != "php") {
                                                        $downloads["other"][] = $file;
                                                    }
                                                }
                                                if(count($downloads["installer"]) > 0) {
                                                    krsort($downloads["installer"]);
                                                    foreach(array_keys($downloads) as $key) {
                                                        $files_group = $downloads[$key];
                                                        $icon = "<ion-icon name='chevron-down'></ion-icon>";
                                                        echo "<dl class='text key_$key'>\n";
                                                        echo "\t<dt>$icon ".$key_names[$key]."</dt>\n";

                                                        foreach($files_group as $file) {
                                                            $basename = path($file, "basename");
                                                            $filesize = round(filesize($file) / 1024, 2);

                                                            $icon = "<ion-icon name='document-sharp'></ion-icon>";
                                                            echo "\t\t<dd>$icon <a href='".$root.$file."'>$basename <span class='small'>($filesize kB)</span></a></dd>\n";
                                                        }

                                                        echo "</dl>\n";
                                                    }
                                                    
                                                    echo "<div class='button_box'><button class='current_version' data-href=''>Pobierz aktualną wersję</button><p class='version'>wersja</p></div>\n";
                                                }
                                            };
                                            
                                            echo "\t\t\t\t\t\t</div>\n";
                                            // media?
                                            if($image) {
                                                echo "\t\t\t\t\t\t\t<figure class='photo' style='background-image:url(\"".$root.$photo."\")'></figure>\n";
                                            }
                                            
                                            
                                            echo "\t\t\t\t\t\t</article>\n";
                                        }

                                        else {
                                            //echo "----------------\n";
                                            echo "<!-- Undefinded article type: \"".$article_name."\" -->\n";
                                            //echo "----------------\n";
                                            //arrayList($article);
                                        };
                                    }; // foreach
                                    
                                    echo "\t\t\t\t\t</div>\n";

                                } ; // if

                            } // foreach

                            echo "\t\t\t\t</section>\n";
                            echo "\t\t\t</div>\n";
                        
                        } // if

                    } // if xml
                } // foreach

            ?>

        </main>

        
        <aside id='project_zoom'>
            <div class='slide_box master' data-num="0">
                <div class='zoom_box'></div>
            </div>
            <div class='toggle_buttons'>
                <!-- Buttons -->
            </div>
        </aside>
        
        <nav>
            <div class='fake_cover'></div>
            <div class='bg_bar'></div>
            <?php
                echo "\n";
            
                // ===============================
                //           NAVIGATION
                // ===============================

                echo "\t\t\t<div class='nav_box'>\n";

                echo "\t\t\t\t<ul class='menu'>\n";
                foreach(array_keys($site_map) as $href) {
                    $title = $site_map[$href];
                    echo "\t\t\t\t\t<li><a href='#".$href."'>$title</a></li>\n";
                }

                echo "\t\t\t\t</ul>\n";

                /*
                // ====== Languages ======
                $lang_list = array();
                foreach($languages as $id) {
                    //if($id == $_SESSION['lang']) { array_unshift($lang_list, $id); } // Current on top
                    //else { $lang_list[] = $id; };
                    $lang_list[] = $id;
                };
                if(count($lang_list) > 1) {
                    echo "\t\t\t\t<ul class='languages'>\n";
                    foreach($lang_list as $id) {
                        if($id == $_SESSION['lang']) { $current = "class='current'"; } else { $current = "class='change'"; };
                        echo "\t\t\t\t\t<li $current value='$id'><button>".strtoupper($id)."</button></li>\n";
                    };
                    echo "\t\t\t\t</ul>\n";
                };
                echo join("", $menu['languages']);
                */

                // ============
                echo "\t\t\t</div>\n";

                echo "\t\t\t<div class='button_box vertical_center'>\n";
                echo "\t\t\t\t<button class='show'><ion-icon name='menu-sharp'></ion-icon></button>\n";
                echo "\t\t\t\t<button class='hide'><ion-icon name='chevron-back-sharp'></ion-icon></button>\n";
                echo "\t\t\t\t<button class='close'><ion-icon name='close-sharp'></ion-icon></button>\n";
                echo "\t\t\t</div>\n";
            
            ?>
        </nav>
        
        <!-- Javascript -->
        <script>
            <?php
                echo "\n";
                echo "\t\t\tvar ROOT = '$root';\n";
                echo "\t\t\tvar CURRENT_PAGE = '$current_page';\n";
                if(is_string($_SESSION['popup']) && $_SESSION['popup'] != "") {
                    echo "\t\t\tvar SHOW_POPUP = '".$_SESSION['popup']."';\n";
                }
                else {
                    echo "\t\t\tvar SHOW_POPUP = false;\n";
                }
            
            ?>
        </script>
        <script src='<?php echo $root; ?>script/jquery-3.4.1.min.js'></script>
        <script src='<?php echo $root; ?>script/functions.js'></script>
        <script src='<?php echo $root; ?>script/layout.js<?php echo "?v=$updated"; ?>'></script>
        
        
        <!-- ====== PREVIEW MODE ====== -->
        <?php
            if(is_string($_SESSION['preview_mode']) &&  $_SESSION['preview_mode'] != "") {
                echo "<input type='hidden' id='preview_mode' value='".$_SESSION['preview_mode']."'>\n";
            };
        ?>
        
        <!-- ====== PLUGINS ====== -->
        <?php
            foreach(listDir($plugins_folder, "/") as $plugin) {
                echo "\n\t\t<div class='plugin_container plugin-".$plugin."'>\n";
                $files_groups = [];
                foreach(listDir("$plugins_folder/$plugin", ".,?") as $file) {
                    $ext = path($file, "extension");
                    $files_groups[$ext][] = $file;
                };
                foreach($files_groups["php"] as $file) {
                    include $file;
                };
                foreach($files_groups["css"] as $file) {
                    echo "\t\t\t<link class='plugin_style' rel='stylesheet' href='".$root.$file."'>\n";
                };
                foreach($files_groups["js"] as $file) {
                    echo "\t\t\t<script src='".$root.$file."'></script>\n";
                };
                echo "\t\t</div>\n";
            };
        ?>

        <div id='help'>-</div>
        
        <footer><span>WebSite by </span><a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</a></footer>
	</body>

</html>
