$(document).ready(function() {
    
    var ANIMATION_TIME = 400;
    var MEMO_FACTOR = 0;
    var SCROLL_BUSY = true;

    $("#help").click(function() {
        alert($(window).width());
    })
    
    // ==========================================
    //               Dynamic URL
    // ==========================================

    var SECTIONS = {};
    
    $("section").each(function() {
        id = $(this).attr("id");
        if(jQuery.type(id) == "string" && id != "") {
            if (navigator.userAgent.match(/(iPod|iPhone|iPad|Android)/)) {           
                section_top = $(window).scrollTop() + $(this).offset().top;
            }
            else {
                section_top = $(this).offset().top;
            };
            section_hei = $(this).height() + parseInt($(this).css("padding-top")) + parseInt($(this).css("padding-bottom"));
            section_bottom = section_top + section_hei;
            i = section_top + ";" + section_bottom;
            SECTIONS[i] = id;
        }
    })
    
    var URL_UPDATE = true;
    
    $(window).scroll(function() {
        scroll_mid = $(window).scrollTop() + ($(window).height() * 0.5);
        if(URL_UPDATE) {
            for(i in SECTIONS) {
                id = SECTIONS[i];
                section = i.split(";");
                if(scroll_mid >= section[0] && scroll_mid <= section[1]) {
                    URL_UPDATE = false;
                    $("#help").html(id);
                    window.history.pushState(null, null, ROOT + id + "/");
                    setTimeout(function() { URL_UPDATE = true; }, ANIMATION_TIME);
                }
            };
        };
    });
    
    function getRelativeUrl(base_root) {
        href = location.href.split("/");
        current_url = [];
        root_count = base_root.split("/").length;
        for(i = 0; i < root_count; i++) {
            current_url[current_url.length] = href.pop();
        }
        return current_url.reverse().join("/");
    };

    function scrollToUrl() {
        url_data = getRelativeUrl(ROOT).split("/");
        if(url_data[0] != $("section").first().attr("id") && $("#" + url_data[0]).length) {
            URL_UPDATE = false;
            hideStart();
            setTimeout(function() {
                if($("#show_project").length) {
                    show_project = $("#show_project").val();
                    $project = $();
                    $("article.project").each(function() {
                        if(show_project == $(this).attr("data-path")) {
                            $(this).attr("id", "_show_project");
                        };
                    })
                };
                
                // Scroll to article
                if($("#_show_project").length) {
                    path = show_project.split("/");
                    section = path[0];
                    article = path[1];
                    scrollTo("#_show_project", -100);
                    //alert($("#_show_project").html())
                    setTimeout(function() { $("#_show_project").click(); }, ANIMATION_TIME + 100);
                }
                // Scroll to section
                else {
                    scrollTo("#" + url_data[0], -30);
                    
                }
                setTimeout(function() { URL_UPDATE = true; }, ANIMATION_TIME);
                
            }, ANIMATION_TIME * 3)
        };
       
    };
    
    // ==========================================
    //              Scroll & swipe
    // ==========================================

	function swipeDetect() {
        $("#help").html( "?" );
		// globals
		var x_start = 0;
		var y_start = 0;
		// record initial touch position
		$(window).on("touchstart", function(e) {
			var xy = e.originalEvent.touches[0];
			x_start = xy.pageX;
			y_start = xy.pageY;
		});
		// check final touch position
		$("body").on("touchmove", function(e) {
            swipeDetectOff();
            
            e.preventDefault();
            
            var xy = e.originalEvent.touches[0];
            var x_end = xy.pageX;
            var y_end = xy.pageY;
            var x = x_end - x_start;
            var y = y_end - y_start;
            // Output
            if(Math.abs(x) > Math.abs(y)) { // horizontal
                if(Math.abs(x) < 5) { $("#help").html( "H<5:" + Math.abs(x) ); } // ignore too small distance
                else if(x > 0) { // right
                    $("#help").html( "swipe LEFT" );
                    changeSlide(-1);

                }
                else if(x < 0) { // left
                    $("#help").html( "swipe RIGHT" );
                    changeSlide(1);
                };
            }
            else { // vertical
                if(Math.abs(y) < 5) { $("#help").html( "V<5:" + Math.abs(y) ); } // ignore too small distance
                else if(y > 0) { // right
                    $("#help").html( "swipe UP" );
                }
                else if(y < 0) { // left
                    $("#help").html( "swipe DOWN" );
                };
            };

            setTimeout(function() {
                swipeDetect();
            }, ANIMATION_TIME / 2);

            return false;
		});
	};
    
    function swipeDetectOff() {
        $("body").unbind("touchstart touchmove");
        $("#help").html( "-" );
    };
    
    function keypressDetect() {
        // Close & navigate by key
        $("body").keyup(function(e) {
            code = e.keyCode;
            if(code == 27) { // ESC
                $(".button_box .close").click();
            }
            else if(code == 37) { // <-
                changeSlide(-1);
            }
            else if(code == 39) { // ->
                changeSlide(1);
            }
        });
    };
    
    function keypressDetectOff() {
        $("body").unbind("keyup");
    };
    
    // ==========================================
    //                  Layout
    // ==========================================
    
    $("main").find("section").first().removeClass("standard");

    $(window).scroll(function() {
        
        win_hei = $(window).height();
        scroll = $(window).scrollTop();
        factor = Math.round((scroll / win_hei) * 100);
        //$("#help").html( factor + "%" );
        
        if(!SCROLL_BUSY) {
            if(factor > 15 && MEMO_FACTOR < factor && $(".maximized").length) {
                hideStart();
                $("html, body").css({ "overflow-y": "auto" }).animate({
                    scrollTop: ($(window).height() - ($("nav .button_box").height() * 1.0))
                }, ANIMATION_TIME);
                SCROLL_BUSY = true;
                setTimeout(function() { SCROLL_BUSY = false; }, ANIMATION_TIME + 100);

            }

            if(factor < 50 && MEMO_FACTOR > factor && $(".minimized").length) {
                showStart();
                $("html, body").css({ "overflow-y": "auto" }).animate({
                    scrollTop: 0
                }, ANIMATION_TIME);
                SCROLL_BUSY = true;
                setTimeout(function() { SCROLL_BUSY = false; }, ANIMATION_TIME + 100);
            }
        }
        
        MEMO_FACTOR = factor;
        
    });
    
    function hideStart() {
        $(".bg_box figure.bg_paper").css({ "top": 0, "margin-top": 0 });
        $(".bg_box figure.bg_image").css({ "top": "100vh" });
        $(".slide_up").css({ "top": "0" });
        $(".logo_box").removeClass("maximized").addClass("minimized");
    }
    
    function showStart() {
        $(".bg_box figure.bg_paper").attr("style", "");
        $(".bg_box figure.bg_image").css({ "top": "0" });
        $(".slide_up").css({ "top": "100vh" });
        $(".logo_box").removeClass("minimized").addClass("maximized ");
    }

    // Scroll to top on initialize
    $("html, body").css({ "overflow-y": "auto" }).animate({
        scrollTop: 0
    }, 100, function() { SCROLL_BUSY = false; });

    
    // ==========================================
    //               Smooth Scroll
    // ==========================================
    
	function scrollTo(id, margin) {
        
        SCROLL_BUSY = true;
        
        if (navigator.userAgent.match(/(iPod|iPhone|iPad|Android)/)) {           
            scroll = $(window).scrollTop() + $(id).offset().top;
        }
        else {
            scroll = $(id).offset().top;
        };

        $("html, body").css({ "overflow-y": "auto" }).animate({
            scrollTop: (scroll + margin)
        }, ANIMATION_TIME);

        setTimeout(function() { SCROLL_BUSY = false; }, ANIMATION_TIME + 100);
        
    };

    // ==========================================
    //                Navigation
    // ==========================================
    
    $(".button_box button.show").click(function() { showMenu(); });
    $(".button_box button.hide, nav .fake_cover, .logo_box").click(function() { hideMenu(); });

    function showMenu() {
        $("html, body").css({ "overflow-y": "hidden" });
        nav_wid = $(".nav_box").width() + parseInt($(".nav_box").css("padding-left")) + parseInt($(".nav_box").css("padding-right"));
        
        $(".button_box button.show").hide(ANIMATION_TIME / 2, function() {
            $(".button_box button.hide").show(ANIMATION_TIME / 2);
        })
        $(".nav_box").show().animate({ "margin-right": (nav_wid * -1) }, ANIMATION_TIME);
        $("nav .fake_cover").show();
        //$("main, .bg_box").animate({ "left": nav_wid }, ANIMATION_TIME);
    };
    
    function hideMenu() {
        $("html, body").css({ "overflow-y": "auto" });
        $(".button_box button.hide").hide(ANIMATION_TIME / 2, function() {
            $(".button_box button.show").show(ANIMATION_TIME / 2);
        })
        $(".nav_box").show().animate({ "margin-right": 0 }, ANIMATION_TIME);
        $("nav .fake_cover").hide();
        //$("main, .bg_box").animate({ "left": 0 }, ANIMATION_TIME);
    };
    
    $("#show_menu").click(function() { showMenu(); });
    $("#hide_menu").click(function() { hideMenu(); });
    
    $("nav .menu a").click(function() {
        
        href = $(this).attr("href");
        hideMenu();
        
        if(href == "#start") {
            showStart();
            $("html, body").stop().css({ "overflow-y": "auto" }).animate({
                scrollTop: 0
            }, ANIMATION_TIME);
            SCROLL_BUSY = true;
            setTimeout(function() { SCROLL_BUSY = false; }, ANIMATION_TIME + 100);
        }
        else {
            //alert(href);
            hideStart();
            scrollTo(href, -30);
        }

        return false;
    });
    
    // ==========================================
    //                 Projects
    // ==========================================
    
    // Hide unused categories filters
    $(".categories_filter").each(function() {
        $filter = $(this);
        $section = $(this).closest("section");
        
        $filter.find("li").each(function() {
            key = $(this).attr("data-value");
            if(key != "key_all") {
                if(!$section.find("article." + key).length) {
                    $(this).remove();
                }
            }
        })
        if($filter.find("li").length < 3) {
            $filter.hide();
        }
    })
    
    $(".categories_filter li").click(function() {
        if($(this).attr("class") == "active") {
            $section = $(this).closest("section");
            $section.find(".categories_filter li.current").attr("class", "active");
            $(this).attr("class", "current");

            key = $(this).attr("data-value");
            $section.find("article").each(function() {
                if(key == "key_all" || $(this).attr("class").split(" ").indexOf(key) > -1) {
                    $(this).show(ANIMATION_TIME);
                }
                else {
                    $(this).hide(ANIMATION_TIME);
                }
            })
        };
    })

    // ====== Disable iOS scroll
    function preventDefault(e) {
        e.preventDefault();
    }

    function disableScroll() {
        document.body.addEventListener('touchmove', preventDefault, { passive: false });
        $("html, body").css({ "overflow-y": "hidden" });
    }
    
    function enableScroll() {
        document.body.removeEventListener('touchmove', preventDefault);
        $("html, body").css({ "overflow-y": "auto" });
    }
    
    
    $("article.project").click(function() {
        URL_UPDATE = false;
        disableScroll();
        project_path = $(this).attr("data-path");
        
        $(".button_box .show, .bg_bar").hide();
        $(".button_box .close").show();
        
        // ====== Copy article content ======
        $("#project_zoom .zoom_box").html( $(this).html() );
        $("#project_zoom .text_box").addClass("vertical_center");
        
        // ====== Generate gallery slides ======
        //$("#project_zoom figure").remove(); // Remove preview
        num = 0;
        $("#project_zoom input.image").each(function() {
            val = $(this).val();
            $("#project_zoom .slide_box").last().after("<div class='slide_box frame' data-num='" + ++num + "'><figure class='slide' style='background-image:url(\"" + val + "\")'></figure></div>\n")
        })
        
        // ====== Add toggle uttons & circles ======

        buttons_html = "<div class='arrows'>\n" +
                            "<button class='prev'><ion-icon name='chevron-back-sharp'></ion-icon></button>\n" +
                            "<button class='next'><ion-icon name='chevron-forward-sharp'></ion-icon></button>\n" +
                        "</div>\n" +
                        "<div class='circles'>\n" +
                                //<ion-icon name="radio-button-on-sharp"></ion-icon>
                                //<ion-icon name="radio-button-off-sharp"></ion-icon>
                        "</div>\n";
        $("#project_zoom .toggle_buttons").append(buttons_html);

        for(i = 0; i <= num; i++) {
            $("#project_zoom .toggle_buttons .circles").append("<ion-icon name='radio-button-off-sharp'></ion-icon>");
        };
        $("#project_zoom .circles ion-icon").first().attr("name", "radio-button-on-sharp");

        $("#project_zoom .slide_box").first().addClass("current");
        
        // ====== Show Project ======
        setTimeout(function() {
            $("#project_zoom").fadeIn(ANIMATION_TIME);
            initializeProjectButtons();
            swipeDetect();
            keypressDetect();
            
            window.history.pushState(null, null, ROOT + project_path + "/");
            ROOT = ROOT + "../";
            updateBBCodeLinks();
        }, 500)

    });
    
    function initializeProjectButtons() {
        $("#project_zoom .toggle_buttons .arrows button").click(function() {
            //SCROLL_BUSY = true;
            if($(this).attr("class") == "next") {
                changeSlide(1);
            }
            else {
                changeSlide(-1);
            };
        });
    };
    
    function changeSlide(dir) {
        $current = $("#project_zoom").find(".current");
        if(dir > 0) {
            $next = $current.next(".slide_box");
            if(!$next.length) { $next = $("#project_zoom").find(".slide_box").first(); };
        }
        else {
            $next = $current.prev(".slide_box");
            if(!$next.length) { $next = $("#project_zoom").find(".slide_box").last(); };
        };
        
        $next.addClass("current").css({"left": (dir * 100) + "vw"}).show().animate({"left":0}, ANIMATION_TIME);
        $current.removeClass("current").animate({"left": (dir * -100) + "vw"}, ANIMATION_TIME, function() { $(this).hide() });
        current_num = parseInt( $current.attr("data-num") );
        next_num = parseInt( $next.attr("data-num") );

        // Show/hide arrows
        if(next_num == 0) {
            $("#project_zoom .toggle_buttons .arrows .prev").fadeOut(ANIMATION_TIME);
            $("#project_zoom .toggle_buttons .arrows .next").fadeIn(ANIMATION_TIME);
        }
        else if(next_num == ($("#project_zoom").find(".slide_box").length - 1)) {
            $("#project_zoom .toggle_buttons .arrows .next").fadeOut(ANIMATION_TIME);
            $("#project_zoom .toggle_buttons .arrows .prev").fadeIn(ANIMATION_TIME);
        }
        else {
            $("#project_zoom .toggle_buttons .arrows button").fadeIn(ANIMATION_TIME);
        };

        // Update circles
        setTimeout(function() {
            $("#project_zoom .circles ion-icon").eq(current_num).attr("name", "radio-button-off-sharp");
            $("#project_zoom .circles ion-icon").eq(next_num).attr("name", "radio-button-on-sharp");
        }, ANIMATION_TIME);
    };
    
    $(".button_box .close").click(function() {
        $(".button_box .show, .bg_bar").show();
        $(".button_box .close").hide();
        swipeDetectOff();
        keypressDetectOff();
        enableScroll();

        window.history.pushState(null, null, "../");
        ROOT = ROOT.split("../");
        ROOT.pop();
        ROOT = ROOT.join("../");
        updateBBCodeLinks();
        
        $("#project_zoom").fadeOut(ANIMATION_TIME, function() {
            $("#project_zoom .slide_box").removeClass("current").attr("style", "");
            $("#project_zoom .zoom_box, #project_zoom .toggle_buttons").html( "" );
            $("#project_zoom > .frame, .circles").remove();
            URL_UPDATE = true;
        })
    })

    // ==========================================
    //                URL Update
    // ==========================================

    function updateBBCodeLinks() {
        $("a.bbcode").each(function() {
            href = $(this).attr("data-href");
            
            if(href.split(":").length > 1) {
                $(this).attr("href", href);
            }
            else {
                $(this).attr("href", ROOT + href);
            }
        })
    }
    updateBBCodeLinks();
    
    // ==========================================
    //                Launch Page
    // ==========================================
    
    setTimeout(function() {
        scrollToUrl();
        $("#loader").delay(ANIMATION_TIME).fadeOut(ANIMATION_TIME);
    }, ANIMATION_TIME * 3);
    
    // ==========================================
    //                  Footer
    // ==========================================
    /*
    footer = "<footer>WebSite by <a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</s></footer>";
    $("body").append(footer);
    */
})