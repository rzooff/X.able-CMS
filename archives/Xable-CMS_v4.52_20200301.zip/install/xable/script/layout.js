$(document).ready(function() {
    
    var ANIMATION_TIME = 400;
    var MEMO_FACTOR = 0;
    var SCROLL_BUSY = true;

    $("#help").click(function() {
        alert($(window).width());
    })
 
    // ==========================================
    //                  Layout
    // ==========================================
    
    $(window).scroll(function() { moveImage(); })
    $(window).resize(function() { moveImage(); })
    
    function moveImage() {
        scroll = $(window).scrollTop();
        
        img_hei = $("section#start .image_box").height();
        img_move = (img_hei * -0.5) + (scroll * 0.7);
        win_hei = window.innerHeight ? window.innerHeight : $(window).height()
        //txt_hei = $(window).height() - parseInt( $("section#start .image_box").css("margin-bottom") ) - (img_hei * 0.5);
        txt_hei = win_hei - (img_hei * 0.5);
        
        $("section#start .image_box").css({ "bottom": img_move });
        $("section#start .text_box").css({ "height": txt_hei });
    }
    moveImage();
    
    // ==========================================
    //               Smooth Scroll
    // ==========================================
    
	function scrollTo(id, margin) {
        if (navigator.userAgent.match(/(iPod|iPhone|iPad|Android)/)) {           
            scroll = $(window).scrollTop() + $(id).offset().top;
        }
        else {
            scroll = $(id).offset().top;
        };

        $("html, body").css({ "overflow-y": "auto" }).animate({
            scrollTop: (scroll + margin)
        }, ANIMATION_TIME);
    };

    // ==========================================
    //                 Download
    // ==========================================
    
    $current = $("#download dl.key_installer dd").first();
    $("#download button.current_version").attr("data-href", $current.find("a").attr("href"));
    $("#download .button_box p").html( $current.find("a").html() );
    $current.remove();

    $("#download dl dt").click(function() {
        $dl = $(this).closest("dl");
        if($dl.find("dd").css("display") == "block") {
            hideDownloads($dl);
        }
        else {
            showDownloads($dl);
        }
    })
    
    function showDownloads($dl) {
        $dl.find("dd").slideDown(ANIMATION_TIME);
        $dl.find("dt ion-icon").attr("name", "chevron-down");
    }
    
    function hideDownloads($dl) {
        $dl.find("dd").slideUp(ANIMATION_TIME);
        $dl.find("dt ion-icon").attr("name", "chevron-forward");
    }
    
    hideDownloads($("#download dl").last());

    // ==========================================
    //                Navigation
    // ==========================================

    // ==========================================
    //                URL Update
    // ==========================================

    function updateBBCodeLinks() {
        $("a.bbcode").each(function() {
            href = $(this).attr("data-href");
            
            if(href.split(":").length > 1) {
                $(this).attr("href", href);
            }
            else {
                $(this).attr("href", ROOT + href);
            }
        })
    }
    updateBBCodeLinks();
    
    // ==========================================
    //                Launch Page
    // ==========================================
    
    setTimeout(function() {
        $("#loader").delay(ANIMATION_TIME).fadeOut(ANIMATION_TIME);
    }, ANIMATION_TIME * 1);
    
    // ==========================================
    //                  Footer
    // ==========================================
    /*
    footer = "<footer>WebSite by <a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</s></footer>";
    $("body").append(footer);
    */
})