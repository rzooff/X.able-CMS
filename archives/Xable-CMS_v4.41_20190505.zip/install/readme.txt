--------------------------------------------------
--------------------------------------------------
><.able CMS (C)2015-2019 by maciej@maciejnowak.com
--------------------------------------------------
--------------------------------------------------

[EN]
X.able is a website content management system based on XML standards.
Designed to be used comfortably without IT knowledge or reading documentation.

Installation:
1. Upload Xable packag (zip)e & unzip.php.txt files to your FTP server.
2. Rename file "unzip.php.txt" to "unzip.php".
3. Open your browser and open unzip.php www location (eg. "http://your_server.com/unzip.php").
4. Follow onscreen instructions...

--------------------------------------------------

[PL]
X.able to system zarządzania treściami strony WWW oparty na standardach XML.
Stworzony by można go było wygodnie używać bez wiedzy informatycznej i czytania dokumentacji.

Instalacja:
1. Załaduj na swój serwer FTP paczkę instalatora Xable (zip) oraz plik unzip.php.txt.
2. Zmień nazwię pliku "unzip.php".txt na "unzip.php".
3. Otwórz przeglądarkę i otwórz lokalizację pod, którą widoczny jest plik unzip.php (np. http://twoja_domena.pl/unzip.php).
4. Postępuj wg instrukcji widocznych na ekranie...

--------------------------------------------------
http://xable.maciej.nowak.com