$(document).ready(function() {
    
    var ANIMATION_TIME = 500;
    
    var SCROLL_POSITION = $(window).scrollTop();
    var SCROLL_BUSY = false;
    
    function pushUrl(url) {
        title = document.title;
        window.history.pushState(url, title, url);
    }
    
    function showMenuButton() {
        $("nav .show_menu").css({ "top": -100, "position": "fixed" }).animate({ "top": 0 }, ANIMATION_TIME);
    }

    function hideMenuButton() {
        $("nav .show_menu").animate({ "top": -100 }, ANIMATION_TIME, function() {
            $(this).css({ "top": 0, "position": "absolute" });
        });
    }
    
    // ==========================================
    //                  Layout
    // ==========================================    
    
    $("div.image_box").each(function() {
        if($(this).closest("article").find("p").length == 0) {
            $(this).addClass("image_only");
        }
    })
    
    // ==========================================
    //               Smooth Scroll
    // ==========================================
    
	function scrollTo(id) {
        scroll = $("#" + id).offset().top; 
        $("html, body").css({ "overflow-y": "auto" }).animate({
            scrollTop: (scroll)
        }, ANIMATION_TIME);
    };

    // ==========================================
    //                Navigation
    // ==========================================
    
    $("nav ul.menu a").click(function() {
        $item = $(this);
        href = $item.attr("href");
        id = href.substr(ROOT.length, href.length - ROOT.length - 1);
        
        if($("#" + id).length) {
            hideMenu();
            setTimeout(function() {
                scrollTo(id);
                setTimeout(function() {
                    if($(window).scrollTop() > 10) {
                        showMenuButton();
                    }
                }, ANIMATION_TIME * 1.5);
            }, ANIMATION_TIME);
            
            $("nav ul.menu li").attr("class", "active");
            $item.closest("li").attr("class", "current");
        }
        return false;
    });
    
    // ==========================================
    //          Show / Hide Menu Button
    // ==========================================
    
    $(window).scroll(function() {
        if(!SCROLL_BUSY) {
            SCROLL_BUSY = true;
            scroll = $(window).scrollTop();
            win_hei = $(window).height();
            
            $button = $("nav .show_menu");
            
            if(scroll < SCROLL_POSITION && $button.css("position") != "fixed") {
                showMenuButton()
            }
            else if(scroll > SCROLL_POSITION && $button.css("position") != "absolute") {
                hideMenuButton()
            }
            
            setTimeout(function() {
                SCROLL_BUSY = false;
                SCROLL_POSITION = $(window).scrollTop();
                showButtons();
            }, ANIMATION_TIME + 100);
        }
        
    });
    
    function showButtons() {
        scroll = $(window).scrollTop();
        win_hei = $(window).height();
        $(".show_buttons").each(function() {
            box_top = $(this).offset().top;
            if((scroll + win_hei) > box_top) {
                $(this).find("a").css({ "top": 0 });
                //alert("show button");
                $(this).removeClass("show_buttons");
            }
        })
        
    }
    
    // ==========================================
    //              Show / Hide Menu
    // ==========================================
                             
    var show_icon = "ion-navicon-round";
    var hide_icon = "ion-close";
    
    var lang_color = $("nav ul.languages li button").css("color");

    function showMenu() {
        $("body").css({ "overflow-y": "hidden" });

        $("nav ul.languages li button").css({
            "top": "20px",
            "left": "20px",
            "color": "#000"
        });
        $("nav .container").slideDown(ANIMATION_TIME, function() {
            $("nav .show_menu span").attr("class", hide_icon);
        });
    };
    
    function hideMenu() {
        $("nav ul.languages li button").css({
            "top": "-5px",
            "left": "0px",
            "color": lang_color
        });
        $("nav .container").slideUp(ANIMATION_TIME, function() {
            $("nav .show_menu span").attr("class", show_icon);
            $("body").css({ "overflow-y": "auto" });
        });
    };
    
    $("nav .show_menu").click(function() {
        $icon = $(this).find("span");
        $menu = $("nav .container");
        
        if($("nav .container").css("display") == "none") {
            showMenu();
        }
        else {
            hideMenu();
        }
    });
    
    // ==========================================
    //               Fold / Expand
    // ==========================================
    
    $(".fold-expand h3").click(function () {
        $container = $(this).closest(".container");
        $text = $container.find(".text");
        $icon = $(this).find(".toggle span");
        if($text.css("display") == "none") {
            // fold other
            $container.closest("section").find(".expanded").each(function() {
                $(this).slideUp(ANIMATION_TIME).removeClass("expanded");
                $(this).closest("article").find(".toggle span").attr("class", "ion-chevron-down");
            })
            // expand selected
            $text.slideDown(ANIMATION_TIME).addClass("expanded");
            $icon.attr("class", "ion-chevron-up");
        }
        else {
            $text.slideUp(ANIMATION_TIME).removeClass("expanded");
            $icon.attr("class", "ion-chevron-down");
        }
        $(this).blur();
    })
    
    // ==========================================
    //                 Language
    // ==========================================
    
    // Move languages to HOME
    $languages = $("nav ul.languages");
    $("#home .header .frame").append($languages.clone());
    
    function getUrlHref() {
        href = location.pathname.split("/");
        if(ROOT.split("/").length <= href.length) {
            href = href.slice( href.length - ROOT.split("/").length );
        };
        return href;
    }
    
    // Add language to URL (reload)
    href = getUrlHref();
    if(href.length == 0 || LANG_LIST.indexOf(href[0]) < 0) {
        href.unshift(LANG);
        location.href = ROOT + href.join("/") ;
    }
    
    // Language change by user
    $(".languages .active button").click(function() {
        lang = $(this).attr("value");
        href = getUrlHref();
        if(LANG_LIST.indexOf(href[0]) > -1) { href.shift(); }; // Delete old language from URL
        $("#loader").fadeIn(ANIMATION_TIME, function() {
            location.href =  ROOT + lang + "/" + href.join("/");
        });
    });
    
    // ==========================================
    //               Socialmedia
    // ==========================================
    
    $(".plugins button").click(function() {
        href = $(this).attr("href");
        if(jQuery.type(href) == "string" && href != "") {
            window.open(href, '_blank'); 
        }
    })
    
    // ==========================================
    //                   Zoom
    // ==========================================
    
    $("figure.zoom").click(function() {
        // Build html
        val = $(this).attr("value");
        html = "<div id='zoom_popup'>" +
            "<figure style='background-image:url(\"" + ROOT + val + "\")'></figure>" +
            "<button class='close'><span class='ion-close-round'></span></button>" +
            "</div>";
        $("body").append(html);
        // Show popup
        $("#zoom_popup").fadeIn(ANIMATION_TIME);
        $("#zoom_popup button.close").click(function() {
            $("#zoom_popup").fadeOut(ANIMATION_TIME, function() {
                $(this).remove();
            })
        })
    })
    
    // ==========================================
    //                URL Update
    // ==========================================
    //alert("1");
    
    //alert( "http://")
    function updateBBCodeLinks() {
        $("article .text a.bbcode, .button_box a").each(function() {
            href = $(this).attr("href");
            if(href.split("://").length == 1) {
                $(this).attr("href", ROOT + href);
            };
        })
    }
    updateBBCodeLinks();
    
    function updateRoot(new_root) {
        
        $("a").each(function() {
            href = $(this).attr("href");
            if(href.substr(0, ROOT.length) == ROOT) {
                $(this).attr("href", new_root + href.substr(ROOT.length));
            }
        });
        
        $("form").each(function() {
            action = $(this).attr("action");
            if(action.substr(0, ROOT.length) == ROOT) {
                $(this).attr("action", new_root + action.substr(ROOT.length));
            }
        });
        
        ROOT = new_root;
    };
    
    function updateUrl() {

        var scroll = $(window).scrollTop();
        var win_hei = $(window).height();
        var current = false;
        
        if(scroll + win_hei < $(document).height()) {
            $("section").each(function() {
                id = $(this).attr("id");
                if(jQuery.type(id) == "string" && id != "") {
                    section_top = $(this).offset().top;
                    if((scroll + win_hei * 0.25) > section_top) {
                        current = id;
                    }
                }
            })
        }
        else { // scrolled to page end
            current = $("section").last().attr("id");
        }
        
        if(current != false) {
            href = location.pathname.split("/" + LANG + "/").pop().split("/");
            
            // Add section to URL
            if(href.length == 1) {
                href.unshift(current);
                href = ROOT + LANG + "/" + href.join("/");
                
                pushUrl(href);
                updateRoot(ROOT + "../");
            }
            else if(href.length == 2 && href[0] != current) {
                href = ROOT + LANG + "/" + current + "/";
                pushUrl(href);
            };
        }
    }
    
    // ==========================================
    //               Contact Form
    // ==========================================
    
    $("#contact form button.send").click(function() {
        $form = $("#contact form");
        
        if(!validateEmail($form.find("input.email").val())) {
            alert($form.find("input.no_email_warning").val());
        }        
        else if($form.find("textarea.message").val().trim() == "") {
            alert($form.find("input.no_message_warning").val());
        }
        else {
            $form.find("input.back_href").val(getUrlHref().join("/"));
            $("#loader").fadeIn(ANIMATION_TIME, function() {
                $form.submit();
            })
        }
        
        return false;
    })
    
    // ==========================================
    //                Launch Page
    // ==========================================
    
    function audioAutoplay($audio) {
        if($audio.attr("class").indexOf("autoplay") > -1) {
            $audio[0].play();
        }
    }
    
    function showPopup($popup, text) {
        $popup.find("p").html(text);
        $popup.fadeIn(ANIMATION_TIME, function() {
            setTimeout(function() {
                $popup.fadeOut(ANIMATION_TIME * 2);
            }, 1500)
        })
    };
    
    setTimeout(function() {
        $("#loader").fadeOut(ANIMATION_TIME * 2);

        goto = location.pathname.split("/" + LANG + "/").pop().split("/").shift();

        if(goto != "" && $("#" + goto).length) {
            scrollTo(goto);
        }
        else {
            scrollTo("home");
        };

        setTimeout(function() {
            updateUrl();
            
            $(window).scroll(function() { updateUrl(); });
            
            audioAutoplay( $("section audio") );
            if(SHOW_POPUP) { showPopup($("#popup"), SHOW_POPUP) }
        }, ANIMATION_TIME * 2);
        
    }, ANIMATION_TIME * 2);

    
    // ==========================================
    //                  Footer
    // ==========================================
    
    footer = "<footer>WebSite by <a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</s></footer>";
    $("body").append(footer);
    
})