<?php
    session_start();

    require "script/functions.php";
    require "script/xml.php";

    //arrayList($_POST);
    
    $settings = loadXml("settings.xml");
    $domain = readXml($settings, "page domain");

    $navigation = loadXml("navigation.xml");
    $contact_href = readXml(array_pop($navigation['multi_page']), "href");
    $contacts = loadXml("pages/$contact_href.xml");
    $form_email = readXml($contacts, "form email");
    $form_subject = readXml($contacts, "form subject");
    $form_text = BBCode( readXml($contacts, "form message") );

    $send_done_info = readXml($contacts, "form send_done_info");
    $send_failed_info = readXml($contacts, "form send_failed_info");

    $back_href = $_POST['back_href'];
    $email = $_POST['email'];
    $subject = readXml($contacts, "form form_subject");
    $message = str_replace("\n", "<br>", $_POST['message']);

    $header = "";
    $header .= "Content-type: text/html; charset=utf-8\r\n";
    $header .= "Content-Transfer-Encodin: 8bit\r\n";


//arrayList($_POST);

?>

<!doctype html>
<html>
    <head>
        <style>
            body { color: #fff; background-color: #bacce4; }
        </style>
        <meta charset="UTF-8">
        <?php
        
            //Debugging TEST outputs
            //echo "TEST<hr>\n[Subject]: \"$subject\"\n<br>[User email]: \"$email\"\n<br>[User message]: \"$message\"<hr>\n[Form subject]: $form_subject<br>\n[Form email]: \"$form_email\"<br>\n[Form message]: \"$form_text\"<hr>\nBack href: \"$back_href\"<hr>\n";
            
            if(
                // ====== send message from user ======
                mail($form_email, $subject, $email." napisał(a):<br>-<br>".$message, $header."Reply-to: ".$email, " -f ".$form_email) // send message to website email
                &&
                mail($email, $form_subject, $form_text, $header."Reply-to: ".$form_email, "-f ".$form_email) // send confirm to sender
            ) {
                $_SESSION['popup'] = $send_done_info;
            } else {
                $_SESSION['popup'] = $send_failed_info;
            };
            
            echo "<meta http-equiv='Refresh' content='0; url=$back_href' />";
        ?>
    </head>
    <body>
    </body>
</html>