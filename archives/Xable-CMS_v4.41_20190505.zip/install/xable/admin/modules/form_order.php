<?php
    echo "\n";

    // ======================================
    //               Build HTML
    // ======================================

    $edit_buttons = "basic";

    echo "\n\t\t<form id='cms' class='order' method='post' action='_publish.php' enctype='multipart/form-data'>\n";
    require("modules/header.php"); // User & Notifications panel

    echo "\t\t\t<main>\n";
    
    // ====== Languages ======
    if(count($languages) > 0) {
        echo "\t\t\t\t<div id='lang'><span class='fi-web manual' help='".localize("language-change")."'></span><p>".localize("language-label").":</p><ul>\n";
        foreach($languages as $language) { echo "\t\t\t\t\t<li value='$language'>".strtoupper($language)."</li>\n"; };
        echo "\t\t\t\t</ul></div>\n";
    }
    else {
        echo "\t\t\t\t<div id='lang' ><span class='fi-web'></span><p>".localize("language-label").":&nbsp;&nbsp;&nbsp;-</p></div>\n";
    }

    // ====== Path info ======
    echo "<p id='path_info'>path_info</p>\n";

    // ====== List items ======

    $orders_xml = loadXml($path);
        
    $list = array_map("trim", file($path));
    echo "\t\t\t\t<h2>".$path."</h2>\n";

    echo "\t\t\t\t<input type='hidden' class='_order-title' value='".readXml($orders_xml, "_order title")."'>\n";

    foreach($orders_xml["multi_item"] as $item) {
        
        $item_path = readXml($item, "path");
        $item_label = readXml($item, "title", $_SESSION["edit_lang"]);
        
        
        $item_label = xmlLanguageTitles($item);
        
        //list($item_path, $item_label) = explode("|", $item);
        $item_xml = "\n".arrayToXml($item, 1);
        $item_xml = str_replace("<", "&lt;", $item_xml);
        $item_xml = str_replace(">", "&gt;", $item_xml);
        
        echo "\t\t\t\t<article class='_order'>\n";
        echo "\t\t\t\t\t<h3 path='$item_path'><span class='fi-list'></span>&nbsp;$item_label<textarea class='value' style='display:none;'>".$item_xml."</textarea></h3>\n";
        echo
            "\t\t\t\t\t<div class='buttons'>\n".
            //"\t\t\t\t\t<button class='delete' help='Usuń wpis'><span class='fi-x'></span></button>\n".
            "\t\t\t\t\t\t<button class='down' help='".localize("move-down")."'><span class='fi-arrow-down'></span></button>\n".
            "\t\t\t\t\t\t<button class='up' help='".localize("move-up")."'><span class='fi-arrow-up'></span></button>\n".
            //"\t\t\t\t\t<button class='new' help='Nowy wpis'><span class='fi-plus'></span></button>\n".
            "\t\t\t\t\t</div>\n";
        echo "\t\t\t\t</article>\n";
    };

    // Outupt data fields
    echo "\t\t\t\t<div id='outputs'>\n";
    echo "\t\t\t\t\t<input type='text' name='edit_path' id='edit_path' value='$path'>\n";
    echo "\t\t\t\t\t<textarea name='output|order' id='output'></textarea>\n";
    echo "\t\t\t\t</div'>\n";
    echo "\t\t\t</main>\n";
    echo "\t\t</form>\n"; // #cms
?>