<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>X.able CMS / Admin cleaner</title>
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <style></style>
    </head>
    <body>
        
<?php
        
    // Delete .bak and .prev versions
        
    $admin_root = "..";
    $site_root = "../..";
    $admin_pathes = [ $admin_root, "$site_root/_plugins" ];

    // ====== Load Functions Libraries ======

    require "$admin_root/script/functions.php";
    require "$admin_root/script/cms.php";
    require "$admin_root/script/xml.php";

    function AdminCleaner($pathes) {
    // ----------------------------------------
    // $path = <string> full directory PATH
    // ----------------------------------------
    // Delete folder with it's content
    // ----------------------------------------
        $flag = false;
        foreach($pathes as $path) {
            foreach(filesTree($path, "bak") as $file) {
                echo "[deleted]: $file<br>\n";
                unlink($file);
                $flag = true;
            }
        };
        if(!$flag) { echo "Nothing to delete.<br>\n"; };
    };
        
    echo "<h1>Admin Cleaner script</h1><hr>\n";
    AdminCleaner($admin_pathes);
?>
        
    </body>
</html>