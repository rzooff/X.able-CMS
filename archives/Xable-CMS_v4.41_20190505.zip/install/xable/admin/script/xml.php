<?php

// ===================================================
//               X.able PHP XML module
//           (C)2017 maciej@maciejnowak.com
// ===================================================
// compatibility: php4+
// build: 20180425
// ===================================================

    // ====== array to XML FILE CONTENT / begin ======
    function XmlFileContent($xml) {
    // -------------------------------------------
    // $xml = <array> Xable XML array
    // -------------------------------------------
    // RETURNS: <string> Ready to save xml file content
    // -------------------------------------------
        if(is_array($xml) && count($xml) > 0) {
            $xml = arrayToXml($xml, 1);
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<xable>\n".$xml."</xable>";
        };
    }
    // ====== array to XML FILE CONTENT / end ======

    // ====== GET FILENAME / begin ======
    function getFilename($file_path) {
    // -------------------------------------------
    // $path = <string> Xable document path
    // -------------------------------------------
    // RETURNS: <string> Filename, also for multiple extensions cases
    // -------------------------------------------
        $file_path = path($file_path, "filename");
        while(path($file_path, "extension") != "") {
            $file_path = path($file_path, "filename");
        }
        return $file_path;
    };
    // ====== GET FILENAME / end ======

    // ====== XML document EXISTS test / begin ======
    function xmlExists($path) {
    // -------------------------------------------
    // $path = <string> Xable document path
    // -------------------------------------------
    // RETURNS: <array> Document path & active mode ("published", "draft", "unpublished"),
    // eg: [ ../pages/file.xml, "published" ],
    // or <false> if file not exist
    // -------------------------------------------
        $filename = path($path, "filename");
        if(path($filename, "extension") == "xml") { $filename = path($path, "filename"); }
        
        $folder = path($path, "dirname");

        
        $ext_list = [ "xml", "xml.draft" ];
        $exists = [];
        
        foreach($ext_list as $ext) {
            if(file_exists("$folder/$filename.$ext")) { $exists[] = $ext; }
        };
        
        if(in_array("xml.draft", $exists) && in_array("xml", $exists)) {
            return [ "$folder/$filename.xml.draft", "draft" ];
        }
        elseif(!in_array("xml.draft", $exists) && in_array("xml", $exists)) {
            return [ "$folder/$filename.xml", "published" ];
        }
        elseif(in_array("xml.draft", $exists) && !in_array("xml", $exists)) {
            return [ "$folder/$filename.xml.draft", "unpublished" ];
        }
        else {
            return false;
        }
    };
    // ====== XML document EXISTS test / end ======

    // ====== get XML all LANGUAGES TITLES / begin ======
    function xmlLanguageTitles($xml_item) {
    // -------------------------------------------
    // $xml_item = <array> Item xable array
    // -------------------------------------------
    // RETURNS: <string> Titles in all languages
    // -------------------------------------------
        $item_title = "";
        foreach(array_keys($xml_item["title"][0]["text"][0]) as $language) {
            $title = $xml_item["title"][0]["text"][0][$language][0];
            $item_title = $item_title."<span class='lang_title $language'>$title</span>";
        }
        return $item_title;
    };
    // ====== get XML all LANGUAGES TITLES / end ======

    // ====== get XML document TITLE / begin ======
    function xmlTitle($path, $language = false, $draft = false) {
    // -------------------------------------------
    // $path = <string> Xable document path
    // $all_langs = <string> for specified language Title, "*": for all languages, or <false> for Admin Language
    // -------------------------------------------
    // RETURNS: <string> Document title based on header-title or filename
    // -------------------------------------------
        if(!is_string($language)) { $language = $_SESSION["admin_lang"]; };
        // Load draft support
        if($draft && file_exists("$path.$draft")) {
            $path = "$path.$draft";
        };
        // Variables
        $xml = loadXml($path, "draft");
        $headers = [ "header", "user", "person" ];
        $title = false;
        // Find title section
        foreach($headers as $section_name) {
            if(!$title && is_array($xml[$section_name])) {
                if($xml[$section_name][0]["title"]) {
                    // All languages
                    if($language == "*") {
                        $title = xmlLanguageTitles($xml[$section_name][0]);
                    }
                    // Single language
                    else {
                        $title = readXml($xml, "header title", $language);
                    };
                }
                else {
                    // User name
                    $key = array_shift(array_keys($xml["user"][0]));
                    $title = readXml($xml, "user $key", $language);
                }
            }
        };
        // No title -> Filename
        if(!is_string($title) || trim($title) == "") {
            $title = $path;
            while(path($title, "extension") != "") {
                $title = ucwords(path($title, "filename"));
            }
        }
        return $title;
    };
    // ====== get XML document TITLE / end ======

    // ====== LIST files based on ORDER file / begin ======
    function listOrder($folder_path, $extension, $draft_extension = false) {
    // -------------------------------------------
    // $folder_path = <string>
    // $extension = <string>
    // $draft_extension = <string> draft file extension (optional)
    // -------------------------------------------
    // RETURNS: <array> List of files based on .order file & specified extension
    // -------------------------------------------
        $list = array();
        $name = array_pop(explode("/", $folder_path));
        $file = "$folder_path/$name.order";
        if(file_exists($file)) {
            foreach(array_map("trim", file($file)) as $item) {
                if(
                    file_exists("$folder_path/$item.$extension") ||
                    ($_SESSION['preview_mode'] && file_exists("$folder_path/$item.$extension.$draft_extension"))
                  ) {
                    $list[] = "$item.$extension";
                };
            };
        };
        return $list;
    };
    // ====== LIST files based on ORDER file / end ======

// ===================================================
//                 Array <-> XML file
// ===================================================

    // ====== load XML data to array / begin ======
    function loadXml($file, $preview = false) {
    // ----------------------------------------
    // $file = <string> File path
    // $preview = <string> Preview file extension or <false/undefined> for no preview
    // ----------------------------------------
    // RETURNS: <array> XML data transformed into an array ([key] => ([0] => "val_1", [1] => "val_2)...)
    // ----------------------------------------
        if(is_string($preview) && $preview != "" && $_SESSION['preview_mode'] == $preview && file_exists("$file.$preview")) {
            $file = "$file.$preview";
            $_SESSION['preview_loaded'] = true;
        };
        $xml = join(" ", array_map("trim", file($file)));
        $xml = xmlToArray($xml);
        if(array_shift(array_keys($xml)) == "xable") { $xml = $xml['xable'][0]; };
        return $xml;
    }; // ====== load XML data to array / end ======

    // ====== save array to XML file / begin ======
    function saveXml($file, $array) {
    // ----------------------------------------
    // $file = <string> File path
    // $array = <array> Data array, xml compatibile: ([key] => ([0] => "val_1", [1] => "val_2)...)
    // ----------------------------------------
    // Saves input data in XML format file
    // ----------------------------------------
        if(file_exists($file)) { rename($file, "$file.bak"); };
        $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        $xml .= arrayToXml($array, 0);
        file_put_contents($file, $xml);
        return $xml;
    }; // ====== save array to XML file / end ======

    // ====== XML to Array / begin ======
    function xmlToArray($xml) {
    // ----------------------------------------
    // $xml = <string> XML contents
    // ----------------------------------------
    // RETURNS: <array> XML data transformed into an array ([key] => ([0] => "val_1", [1] => "val_2)...)
    // ----------------------------------------
        $cmt_tags = array("<!--", "-->");
        unset($array);
        $n = 0;
        $text = "";         // text content
        $cmt = false;       // comments flag
        $tag = false;       // part of tag name
        $key = false;       // tag name = array key
        $sub = array();     // sub tags (will be ignored)
        while($n < strlen($xml)) {
            //echo "INPUT: $xml<br>";
            $ch = substr($xml, $n, 1);
            if($n < (strlen($xml) - 1)) { $next = substr($xml, ($n +1), 1); } else { $next = ""; };
            // ====== Ignore comments ======
            if($cmt != false) {
                if(substr($xml, $n, strlen($cmt_tags[1])) == $cmt_tags[1]) {
                    $cmt = false;
                    $n = $n + strlen($cmt_tags[1]) - 1;
                };
            }
            elseif(substr($xml, $n, strlen($cmt_tags[0])) == $cmt_tags[0]) { $cmt = true; }
            // ====== XML analyse ======
            elseif($ch == "<" && !is_numeric($next) && !in_array($next, array("", " ", "!", "?", ".", ",", ";")))  { // tag begin
                if(is_string($tag)) { $text .= "<".$tag; }; // previous "<" character was non-tag
                $tag = "";
            }
            elseif(is_string($tag) && $ch == ">") { // tag end
                if($key == false) { // new begin tag -> key
                    $key = $tag;
                    list($tag, $text) = array(false, "");
                }
                elseif($tag == "/".end($sub)) { // closing the last of sub tags
                    array_pop($sub);
                    $text .= "<".$tag.">";
                    $tag = false;
                }                    
                elseif($tag == "/".$key) { // matched key/tag begin & end                    
                    $text = trim($text);
                    $dat = $array[$key];
                    if(($sub = xmlToArray($text)) != false) { // recurence -> sub tags arrays
                        $dat[] = $sub;
                    }
                    else { // no sub tags -> string value
                        $dat[] = $text;
                    };
                    $array[$key] = $dat;
                    list($key, $tag, $text, $sub) = array(false, false, "", array()); // reset variables after adding complete tag data
                }
                else {
                    if(substr($tag, 0, 1) != "/") { $sub[] = $tag; }; // opening of the sub tag
                    $text .= "<".$tag.">";
                    $tag = false;
                };
            }
            elseif(is_string($tag)) { $tag .= $ch; }
            else {$text .= $ch; };
            $n++;
        };
        return $array;
    }; // ====== XML to Array / end ======

    // ====== Array to XML / begin ======
    function arrayToXml($array, $depth = 0) {
    // ----------------------------------------
    // $array = <array> Data array, xml compatibile: ([key] => ([0] => "val_1", [1] => "val_2)...)
    // $depth = <integer> array/xml level depth (optional)
    // ----------------------------------------
    // RETURNS: <string> data in XML string
    // ----------------------------------------
        if(!is_numeric($depth)) { $depth = 0; };
        $xml = "";
        foreach(array_keys($array) as $key) {
            $n = 0;
            $marg = "";
            while($n++ < $depth) { $marg .= "\t"; };
            $sub = $array[$key];
            foreach($sub as $val) {
                $xml .= "$marg<$key>";
                if(is_array($val)) {
                    $xml .= "\n";
                    $xml .= arrayToXml($val, ($depth + 1));
                    $xml .= "$marg</$key>\n";
                }
                else { $xml .= "$val</$key>\n"; };
            };
        };
        return $xml;
    }; // ====== Array to XML / end ======

// ===================================================
//                    Read XML data
// ===================================================

    // ====== getCode text / begin ======
    function getCode($code) {
    // ----------------------------------------
    // $code = <string> code from XML
    // ----------------------------------------
    // RETURNS = <string> code restored to original source code
    // ----------------------------------------
        $code = str_replace("&lt;", "<", $code);
        $code = str_replace("&gt;", ">", $code);
        $code = str_replace("[br]", "\n", $code);
        return $code;
    }
    // ====== getCode text / begin / end ======

    // ====== convert string to ID / begin ======
    function getId($string) {
    // ----------------------------------------
    // $string = <string>
    // ----------------------------------------
    // RETURNS = <string> Lowercase without spaces & special characters
    // ----------------------------------------
        $string = strtolower(killPl($string));
        $string = preg_replace("/ |\n|\t/", "_", $string);
        $string = preg_replace("/\||=|\^|\/|\\\|\*|'|\"|%|\\$|@|#|&|\\.|,|:|;|\?|!/", "", $string);
        $string = preg_replace("/<|>|\[|\]|\(|\)|{|}/", "", $string);
        $string = preg_replace("/___|__/", "_", $string);
        return $string;
    };
    // ====== convert string to ID / begin / end ======

    // ====== easy GET values from zable article / begin ======
    function getVal($article) {
    // ----------------------------------------
    // $article = <array> xable article array
    // ----------------------------------------
    // RETURNS = <array> All article sections values
    // ----------------------------------------
      $val = array();
      foreach(array_keys($article) as $key) {
          $val[$key] = readXml($article, $key);
      };
      return $val;
    };
    // ====== easy GET values from zable article / end ======

    // ====== easy READ XML data / begin ======
    function readXml($xml, $tags, $language = false) {
    // ----------------------------------------
    // $xml = <array> XML data loaded into an array with loadXml()
    // $tags = <string> TAGS list, divided with spaces, eg: "article section"
    // $language = <string> force language code, optional
    // ----------------------------------------
    // RETURNS: <string> data specified by tags or <array> if multiple data found
    // ----------------------------------------
        // Language
        if(!is_string($language)) { $language = $_SESSION['lang']; }; // By user session
        if(!is_string($language)) { $language = "pl"; } // Default
        // XML Array read
        $tags = explode(" ", $tags);
        foreach(array_keys($tags) as $n) {
            // ====== LOOP ======
            $tag = $tags[$n];
            if(($n + 1) < count($tags)) {
                $xml = $xml[$tag][0];
            }
            // ====== OUTPUT ======
            elseif(count($xml[$tag]) > 1) {
                // Multiple -> Array output
                return $xml[$tag];
            }
            else {
                // Unknown -> Guess output
                if(!is_array($xml[$tag][0]) && !is_string($xml[$tag][0])) {
                    if(is_string($xml['media'][0][$tag][0])) {
                        return $xml['media'][0][$tag][0];
                    }
                    elseif(is_array($xml['radio'][0][$tag])) {
                        return $xml['radio'][0][$tag];
                    }
                    elseif(is_array($xml['checkbox'][0][$tag])) {
                        return $xml['radio'][0][$tag];
                    };
                }
                // Single -> String output
                else {
                    $xml = $xml[$tag][0];
                    // Section data
                    if(is_array($xml['type']) && is_string($type = $xml['type'][0])) {
                        if($type == "text" || $type == "textarea") {
                            $text = $xml['text'][0][$language][0];
                            //if($xml['format'] == "") { return $text; } else { return BBCode($text); };
                            return $text;
                        }
                        elseif($type == "option") {
                            return $xml['selected'][0];
                        }
                        elseif($type == "media") {
                            return $xml[$type][0][ $xml['set'][0] ][0];
                        }
                        elseif($type == "button") {
                            return $xml['action'][0];
                        }
                        elseif($type == "table") {
                            return $xml[$type][0][$language];
                        }
                        else {
                            return $xml[$type][0];
                        };
                    }
                    // Specified options array
                    elseif(is_array($xml['option']) && ($tag == "radio" || $tag == "checkbox")) {
                        return ($xml['option']);
                    }
                    // Other data
                    else {
                        return $xml;
                    };
                };
            };
        };
    };
    // ====== easy READ XML data / begin ======

// ===================================================
//                 String tools
// ===================================================

    // ====== No upload time filename / begin ======
    function noUploadTime($filename) {
    // ----------------------------------------
    // $filename = <string> Filename or filepath
    // ----------------------------------------
    // Returns: <string> Filename without upload time
    // ----------------------------------------
        $filename = path($filename, "filename"); // path to filename
        $filename_fixed = explode("_", $filename);
        if(count($filename_fixed) > 1) {
            $filedate = explode("-", array_pop($filename_fixed));
            if(count($filedate) == 2 && is_numeric($filedate[0]) && is_numeric($filedate[1])) {
                $filename = join(" ", $filename_fixed);
            }
        };
        return $filename;
    }; // ====== No upload time filename / end ======

// ===================================================
//                Debuggging Tools
// ===================================================

    // ====== Array Listing / begin ======
    function arrayList($array, $depth = 0) {
    // ----------------------------------------
    // $array = <array>
    // $depth = <integer> display array level depth (optional)
    // ----------------------------------------
    // Display all array contents (with echo) for debugging
    // ----------------------------------------
        if(!is_numeric($depth)) { $depth = 0; };
        foreach(array_keys($array) as $k) {
            $n = 0;
            while($n++ < $depth) { echo "> "; };
            $val = $array[$k];
            if(is_array($val)) {
                echo "[$k] ...<br>\n";
                arrayList($val, ($depth + 1));
            }
            else {
                echo "[$k] : '$val'<br>\n";
            };
        };
    }; // ====== Array Listing / end ======

    // ====== xml list in html / begin ======
    function xmlList($xml) {
    // ----------------------------------------
    // $xml = <string> XML contents
    // ----------------------------------------
    // Shows XML contents
    // ----------------------------------------
        $xml = str_replace("<", "&#60;", $xml);
        $xml = str_replace(">", "&#62;", $xml);
        $xml = str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;", $xml);
        foreach(explode("\n", $xml) as $txt) { echo "$txt<br>"; };
    }; // ====== xml list in html / end ======

?>