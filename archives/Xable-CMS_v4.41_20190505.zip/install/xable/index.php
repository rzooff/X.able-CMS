<?php

	session_start();
	require "script/functions.php";
	require "script/xml.php";

    $updated = "20170522-2359";

    // ====================================
    //           Global Variables
    // ====================================

	$settings = loadXml("settings.xml", "draft");
	$navigation = loadXml("navigation.xml", "draft");
	$pages = "pages";
    $domain = readXml($settings, "page domain");
    if(substr($domain, strlen($domain) - 1) == "/") { $domain = substr($domain, 0, strlen($domain) - 1); }

    $current_page = $_GET['page'];

    // ====== RewriteEngine support ======
    $root = "";
    $link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $current_href = substr($link, strlen($link) - strlen($_GET['page']) -1);
    if($_GET['page'] != "" && $current_href == $_GET['page']."/") {
        $root = str_repeat("../", count(split("/", $_GET['page'])));
    }
    else {
        $root = "";
    }

    // ====================================
    //              Languages
    // ====================================

    // Get valid languages list
    $lang_list = array();
    foreach($settings['multi_language'] as $language) {
        $val = getVal($language);
        if($val['active'] != "") {
            $lang_list[] = $val['id'];
        }
    };
    // Check for language id in url
    $url = split("/", $_SERVER[REQUEST_URI]);
    if(count($url) > count(split("/", $root))) {
        $url = array_slice($url, count($url) - count(split("/", $root)));
        array_pop($url); // Delete last empty element
        if(in_array($url[0], $lang_list)) {
            $_SESSION['lang'] = $url[0];
        }
        else {
            header("Location: ".$root.$lang_list[0]."/");
        }
    };
    // First as default
    if(!$_SESSION['lang'] || !in_array($_SESSION['lang'], $lang_list)) { $_SESSION['lang'] = $lang_list[0]; };
        
    // ====================================
    //          Force page reload
    // ====================================

    if(is_string($_GET['reload']) && $_GET['reload'] != "") {
        list($url, $hash) = split("\^", $_GET['reload']);
        if(is_string($hash) && $hash != "") { $url = $url."#".$hash; };
        echo "<script> location.href = \"".$root.$url."\"; </script>\n";
    };

    // ====================================
    //         Draft preview support
    // ====================================

    // ====== Check DRAFT PREVIEW mode ======
    if($_GET['preview'] == "none" || $_GET['preview'] == "false") { $_SESSION['preview_mode'] = false; }
    elseif(is_string($_GET['preview']) && $_GET['preview'] != "") { $_SESSION['preview_mode'] = $_GET['preview']; };
    // ====== Send preview status ======
    if(is_string($_SESSION['preview_mode']) &&  $_SESSION['preview_mode'] != "") {
        echo "<input type='hidden' id='preview_mode' value='".$_SESSION['preview_mode']."'>\n";
    };

    // ====================================
    //              Functions
    // ====================================

    function testFile($file) {
        $file = array_shift(split(";", $file)); // get first file
        if($file != "" && file_exists($file) && !is_dir($file)) { return $file; }
        else { return false; };
    };

    function makeId($string) {
        $string = strtolower(killPl($string));
        $string = preg_replace("/ |\n|\t/", "_", $string);
        $string = preg_replace("/\||=|\^|\/|\\\|\*|'|\"|%|\\$|@|#|&|\\.|,|:|;|\?|!/", "", $string);
        $string = preg_replace("/<|>|\[|\]|\(|\)|{|}/", "", $string);
        $string = preg_replace("/___|__/", "_", $string);
        return $string;
    };

?>

<!doctype html>

<html>
	<head>

        <!--
            This website is powered by X.able CMS v3+
            Copyright ©2017 by maciej@maciejnowak.com

            Design & development by maciejnowak.com
        -->

		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta charset="UTF-8">
		<meta http-equiv="Content-Language" content="<?php echo $_SESSION['lang']; ?>">
		<title><?php echo readXml($settings, "page title"); ?></title>
        <meta name="description" content="<?php echo readXml($settings, "page description"); ?>"/>
        <meta name="keywords" content="<?php echo readXml($settings, "page keywords"); ?>"/>
        
        <!-- ====== Favicon ====== -->
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo $root; ?>_favicon/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo $root; ?>_favicon/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $root; ?>_favicon/favicon-16x16.png">
        <link rel="manifest" href="<?php echo $root; ?>_favicon/manifest.json">
        <meta name="theme-color" content="#ffffff">
        
        <!-- ====== CSS / might be moved to HEAD via js ====== -->
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>style/preview_mode.css">
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>style/layout.css?v=<?php echo uniqid(); ?>">
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>style/layout-mobile.css?v=<?php echo uniqid(); ?>">
        <link class='async' rel="stylesheet" href="<?php echo $root; ?>iconfont/ionicons-2.0.1/css/ionicons.css">
        
        <link href="https://fonts.googleapis.com/css?family=Caveat:400,700|Josefin+Sans:300,400,600,700&amp;subset=latin-ext" rel="stylesheet">
        
        <!-- ====== Facebook ====== -->
        <meta class='share-url' property="og:url" content="http://<?php echo $domain ?>" />
        <meta class='share-type' property="og:type" content="website" />
        <meta class='share-title' property="og:title" content="<?php echo readXml($settings, "page title"); ?>" />
        <meta class='share-description' property="og:description" content="<?php echo readXml($settings, "page description"); ?>" />
        <meta class='share-image' property="og:image" content="http://<?php echo $domain."/".readXml($settings, "media thumb"); ?>" />
        
        <!-- Loader -->
        <style>
            #loader {
                position: fixed;
                top: 0;
                left: 0;
                z-index: 999;
                width: 100%;
                height: 100%;
                padding-top: 50vh;
                background-color: #bacce4;
            }
            

            .cssload-container * {
                position: relative;
                top: -31px;
                box-sizing: border-box;
                    -o-box-sizing: border-box;
                    -ms-box-sizing: border-box;
                    -webkit-box-sizing: border-box;
                    -moz-box-sizing: border-box;
            }

            .cssload-container ul li{
                list-style: none;
            }

            .cssload-container {
                margin: 19px auto 0 auto;
            }

            .cssload-flex-container {
                display: flex;
                    display: -o-flex;
                    display: -ms-flex;
                    display: -webkit-flex;
                    display: -moz-flex;
                flex-direction: row;
                    -o-flex-direction: row;
                    -ms-flex-direction: row;
                    -webkit-flex-direction: row;
                    -moz-flex-direction: row;
                flex-wrap: wrap;
                    -o-flex-wrap: wrap;
                    -ms-flex-wrap: wrap;
                    -webkit-flex-wrap: wrap;
                    -moz-flex-wrap: wrap;
                justify-content: space-around;
            }
            .cssload-flex-container li {
                padding: 10px;
                height: 97px;
                width: 97px;
                margin: 29px 19px;
                position: relative;
                text-align: center;
            }

            .cssload-loading {
                display: inline-block;
                width: 73px;
                height: 5px;
                background: #fff;
                border-radius: 97px;
                transform-origin: center center;
                    -o-transform-origin: center center;
                    -ms-transform-origin: center center;
                    -webkit-transform-origin: center center;
                    -moz-transform-origin: center center;
                animation: cssload-loading 4.6s ease infinite;
                    -o-animation: cssload-loading 4.6s ease infinite;
                    -ms-animation: cssload-loading 4.6s ease infinite;
                    -webkit-animation: cssload-loading 4.6s ease infinite;
                    -moz-animation: cssload-loading 4.6s ease infinite;
                margin-top: 34px;
            }

            @keyframes cssload-loading {
                0% {
                    transform: rotate(-20deg);
                    height: 5px;
                    width: 73px;
                }
                5% {
                    height: 5px;
                    width: 73px;
                }
                30% {
                    transform: rotate(380deg);
                    height: 5px;
                    width: 73px;
                }
                40% {
                    transform: rotate(360deg);
                    height: 5px;
                    width: 73px;
                }
                55% {
                    transform: rotate(0deg);
                    height: 5px;
                    width: 5px;
                }
                65% {
                    transform: rotate(0deg);
                    height: 5px;
                    width: 83px;
                }
                68% {
                    transform: rotate(0deg);
                    height: 5px;
                }
                75% {
                    transform: rotate(0deg);
                    height: 5px;
                    width: 1px;
                }
                78% {
                    height: 5px;
                    width: 5px;
                }
                90% {
                    height: 5px;
                    width: 73px;
                    transform: rotate(0deg);
                }
                99%, 100% {
                    height: 5px;
                    width: 73px;
                    transform: rotate(-20deg);
                }
            }

            @-o-keyframes cssload-loading {
                0% {
                    -o-transform: rotate(-20deg);
                    height: 5px;
                    width: 73px;
                }
                5% {
                    height: 5px;
                    width: 73px;
                }
                30% {
                    -o-transform: rotate(380deg);
                    height: 5px;
                    width: 73px;
                }
                40% {
                    -o-transform: rotate(360deg);
                    height: 5px;
                    width: 73px;
                }
                55% {
                    -o-transform: rotate(0deg);
                    height: 5px;
                    width: 5px;
                }
                65% {
                    -o-transform: rotate(0deg);
                    height: 5px;
                    width: 83px;
                }
                68% {
                    -o-transform: rotate(0deg);
                    height: 5px;
                }
                75% {
                    -o-transform: rotate(0deg);
                    height: 5px;
                    width: 1px;
                }
                78% {
                    height: 5px;
                    width: 5px;
                }
                90% {
                    height: 5px;
                    width: 73px;
                    -o-transform: rotate(0deg);
                }
                99%, 100% {
                    height: 5px;
                    width: 73px;
                    -o-transform: rotate(-20deg);
                }
            }

            @-ms-keyframes cssload-loading {
                0% {
                    -ms-transform: rotate(-20deg);
                    height: 5px;
                    width: 73px;
                }
                5% {
                    height: 5px;
                    width: 73px;
                }
                30% {
                    -ms-transform: rotate(380deg);
                    height: 5px;
                    width: 73px;
                }
                40% {
                    -ms-transform: rotate(360deg);
                    height: 5px;
                    width: 73px;
                }
                55% {
                    -ms-transform: rotate(0deg);
                    height: 5px;
                    width: 5px;
                }
                65% {
                    -ms-transform: rotate(0deg);
                    height: 5px;
                    width: 83px;
                }
                68% {
                    -ms-transform: rotate(0deg);
                    height: 5px;
                }
                75% {
                    -ms-transform: rotate(0deg);
                    height: 5px;
                    width: 1px;
                }
                78% {
                    height: 5px;
                    width: 5px;
                }
                90% {
                    height: 5px;
                    width: 73px;
                    -ms-transform: rotate(0deg);
                }
                99%, 100% {
                    height: 5px;
                    width: 73px;
                    -ms-transform: rotate(-20deg);
                }
            }

            @-webkit-keyframes cssload-loading {
                0% {
                    -webkit-transform: rotate(-20deg);
                    height: 5px;
                    width: 73px;
                }
                5% {
                    height: 5px;
                    width: 73px;
                }
                30% {
                    -webkit-transform: rotate(380deg);
                    height: 5px;
                    width: 73px;
                }
                40% {
                    -webkit-transform: rotate(360deg);
                    height: 5px;
                    width: 73px;
                }
                55% {
                    -webkit-transform: rotate(0deg);
                    height: 5px;
                    width: 5px;
                }
                65% {
                    -webkit-transform: rotate(0deg);
                    height: 5px;
                    width: 83px;
                }
                68% {
                    -webkit-transform: rotate(0deg);
                    height: 5px;
                }
                75% {
                    -webkit-transform: rotate(0deg);
                    height: 5px;
                    width: 1px;
                }
                78% {
                    height: 5px;
                    width: 5px;
                }
                90% {
                    height: 5px;
                    width: 73px;
                    -webkit-transform: rotate(0deg);
                }
                99%, 100% {
                    height: 5px;
                    width: 73px;
                    -webkit-transform: rotate(-20deg);
                }
            }

            @-moz-keyframes cssload-loading {
                0% {
                    -moz-transform: rotate(-20deg);
                    height: 5px;
                    width: 73px;
                }
                5% {
                    height: 5px;
                    width: 73px;
                }
                30% {
                    -moz-transform: rotate(380deg);
                    height: 5px;
                    width: 73px;
                }
                40% {
                    -moz-transform: rotate(360deg);
                    height: 5px;
                    width: 73px;
                }
                55% {
                    -moz-transform: rotate(0deg);
                    height: 5px;
                    width: 5px;
                }
                65% {
                    -moz-transform: rotate(0deg);
                    height: 5px;
                    width: 83px;
                }
                68% {
                    -moz-transform: rotate(0deg);
                    height: 5px;
                }
                75% {
                    -moz-transform: rotate(0deg);
                    height: 5px;
                    width: 1px;
                }
                78% {
                    height: 5px;
                    width: 5px;
                }
                90% {
                    height: 5px;
                    width: 73px;
                    -moz-transform: rotate(0deg);
                }
                99%, 100% {
                    height: 5px;
                    width: 73px;
                    -moz-transform: rotate(-20deg);
                }
            }
        </style>
        
        <!-- Statistics (Head) -->
        <?php
            echo "\n";
            foreach($settings['multi_statistics'] as $stats) {
                $val = getVal($stats);
                if($val['destination'] == "head") {
                    echo getCode($val['code'])."\n";
                }
            }
        ?>

	</head>

	<body>
        
        <!-- Statistics (Body) -->
        <?php
            echo "\n";
            foreach($settings['multi_statistics'] as $stats) {
                $val = getVal($stats);
                if($val['destination'] == "body") {
                    echo getCode($val['code'])."\n";
                }
            }

        ?>
        
        <div id='loader'>
            <div class="cssload-container">
                <ul class="cssload-flex-container">
                    <li>
                        <span class="cssload-loading"></span>
                    </li>
                </ul>
            </div>	
        </div>

        <?php
    
            echo "\n";

            // ===============================
            //          MAIN CONTENT
            // ===============================
        
            foreach($navigation['multi_page'] as $page) {
                

                $href = readXml($page, "href");
                $title = readXml($page, "title");
                

                //if(readXml($page, "active") != "" && is_array($xml = loadXml("$pages/$href.xml", "draft"))) {
                if(is_array($xml = loadXml("$pages/$href.xml", "draft"))) {
                    
                    // ====== Section Type ======
                    if($href == "contact") {
                        $section_type = "footer";
                    }
                    elseif(strtolower(readXml($xml, "header type")) == "cechy") {
                        $section_type = "feature";
                    }
                    else {
                        $section_type = "paragraph";
                    };
                    
                    
                    // ====== HTML ======
                    // Section Background
                    if(testFile(readXml($xml, "background image"))) {
                        echo "\n\t<section id='".$href."' class='type_$section_type background' style='background-image:url(\"".$root.readXml($xml, "background image")."\")'>\n";
                        echo "\t\t<div class='background_fader'></div>\n";
                    }
                    else {
                        echo "\n\t<section id='".$href."' class='type_$section_type'>\n";
                    };

                    echo "\t\t<div class='".$section_type."_box'>\n";
                    
                    foreach(array_keys($xml) as $article_name) {

                        $article_group = $xml[$article_name];
                        foreach(array_keys($article_group) as $article_num) {
                            $article = $article_group[$article_num];
                            $val = getVal($article);
                            
                            // ====== HOME ======
                            if($href == "home" && $article_name == "header") {

                                echo "\t\t\t<article class='$article_name'>\n";
                                echo "\t\t\t\t<figure class='background' style='background-image:url(\"".$root.$val['background']."\")'></figure>\n";
                                echo "\t\t\t\t<figure class='frame' style='background-image:url(\"".$root.$val['frame']."\")'>\n".
                                    "\t\t\t\t\t<h1>\n".
                                    "\t\t\t\t\t\t<figure class='logo' style='background-image:url(\"".$root.$val['logo']."\")'></figure>\n".
                                    "\t\t\t\t\t\t<span class='title'>".readXml($settings, "page title")."<span>\n".
                                    "\t\t\t\t\t</h1>\n".
                                    "\t\t\t\t</figure>\n";
                                echo "\t\t\t</article>\n";
                            }
                            
                            // ====== Header ======
                            elseif($article_name == "header") {
                                
                                echo "\t\t\t<article class='$article_name'>\n";
                                echo "\t\t\t\t<div class='container'>\n";
                                echo "\t\t\t\t\t<h2>".$val['title']."</h2>\n";
                                //if(is_file($val['image'])) {
                                //    echo "\t\t\t\t<figure class='image' style='background-image:url(\"".$root.$val['image']."\")'></figure>\n";
                                //};
                                echo "\t\t\t\t<div class='text'><p>".BBCode($val['text'])."</p></div>\n";
                                echo "\t\t\t\t</div>\n";
                                echo "\t\t\t</article>\n";
                            }
                            
                            // ====== Post ======
                            elseif($article_name == "multi_post") {

                                if($val['type'] == "Rozwijany") {
                                    $post_type = "fold-expand";
                                }
                                else {
                                    $post_type = "no_toggle";
                                }
                                
                                $media_set = readXml($article, "media set");
                                
                                echo "\t\t\t<article class='$article_name $post_type media-$media_set'>\n";
                                echo "\t\t\t\t<div class='container'>\n";
                                
                                if($section_type == "feature") {
                                    if($val['icon_name'] == "") { $val['icon_name'] = "ion-checkmark-circled"; };
                                    
                                    echo "\t\t\t<figure class='icon'><span style='color:".$val['icon_color']."' class='".$val['icon_name']."'></span></figure>\n";
                                }

                                if($media_set == "image" & is_file($val['media'])) {
                                    echo "\t\t\t\t\t<div class='image_box'>\n".
                                        "\t\t\t\t\t\t<figure class='image zoom' value='".$val['media']."' style='background-image:url(\"".$root.$val['media']."\")'></figure>\n".
                                        "\t\t\t\t\t</div>\n";
                                };
                                if($val['title'] != "") { echo "\t\t\t\t\t<h3>".$val['title']."<button class='toggle'><span class='ion-chevron-down'></span></button></h3>\n"; };
                                if($val['text'] != "") { echo "\t\t\t\t\t<div class='text'><p>".BBCode($val['text'])."</p></div>\n"; };
                                echo "\t\t\t\t</div>\n";
                                echo "\t\t\t</article>\n";
                            }
                            
                            // ====== Contact box ======
                            elseif($article_name == "contact") {
                                //arrayList($val);
                                echo "\t\t\t<article class='$article_name footer_item'>\n";
                                echo "\t\t\t\t<div class='contact_box'>\n";
                                // ====== Contact BOX ======
                                if($val['email'] != "") {
                                    echo "\t\t\t\t\t<p class='contact_item'><span class='ion-ios-email'></span><a href='mailto:".$val['email']."'>".$val['email']."</a></p>\n";
                                }
                                if($val['phone'] != "") {
                                    echo "\t\t\t\t\t<p class='contact_item'><span class='ion-ios-telephone'></span><a href='tel:".$val['phone']."'>".$val['phone']."</a></p>\n";
                                }
                                if($val['address'] != "") {
                                    echo "\t\t\t\t\t<p class='contact_item'><span class='ion-ios-home'></span>".BBCode($val['address'])."</p>\n";
                                }
                                echo "\t\t\t\t</div>\n";
                                echo "\t\t\t</article>\n";
                            }
                            
                            // ====== Contact form ======
                            elseif($article_name == "form") {
                                //arrayList($val);
                                echo "\t\t\t<article class='$article_name footer_item'>\n";
                                echo "\t\t\t\t<div class='contact_box'>\n";
                                // ====== Contact FORM ======
                                echo "\t\t\t\t\t<form class='contact_form' method='post' action='".$root."mailer.php'>\n";
                                
                                echo "\t\t\t\t\t\t<input type='hidden' class='back_href' name='back_href' value=''>\n";
                                echo "\t\t\t\t\t\t<input type='hidden' class='no_email_warning' value='".$val['no_email_warning']."'>\n";
                                echo "\t\t\t\t\t\t<input type='hidden' class='no_message_warning' value='".$val['no_message_warning']."'>\n";
                                
                                echo "\t\t\t\t\t\t<ul class='form_box'>\n";
                                echo "\t\t\t\t\t\t\t<li><p>".$val['title']."</p>\n";
                                echo "\t\t\t\t\t\t\t<li><input class='email' name='email' type='email' placeholder='".$val['email_label']."' required></li>\n";
                                echo "\t\t\t\t\t\t\t<li><textarea class='message' name='message' placeholder='".$val['message_label']."' required></textarea></li>\n";
                                echo "\t\t\t\t\t\t\t<li><button type='submit' class='send'>".$val["send_button"]."</button></li>\n";
                                echo "\t\t\t\t\t\t</ul>\n";
                                echo "\t\t\t\t\t</form>\n";
                                echo "\t\t\t\t</div>\n";
                                echo "\t\t\t</article>\n";
                            }
                            
                            // ====== Picture Button ======
                            elseif($article_name == "multi_button") {
                                //arrayList($val);
                                echo "\t\t\t<article class='$article_name footer_item'>\n";
                                echo "\t\t\t\t<div class='button_box show_buttons'>\n";
                                // ====== Image ======
                                if(testFile($val['image'])) {
                                    $image = "<figure style='background-image:url(\"".$root.$val['image']."\")'></figure>";
           
                                    if(trim($val['href']) != "") {
                                        echo "\t\t\t\t\t<a href='".$val['href']."' target='_blank'>".$image."</a>\n";
                                    }
                                    else {
                                        echo "\t\t\t\t\t".$image."\n";
                                    }
                                    
                                    
                                };
                                echo "\t\t\t\t</div>\n";
                                echo "\t\t\t</article>\n";
                            }
                        
                            // ====== Audio player ======
                            elseif($article_name == "music") {
                                $audio = readXml($article, "audio");
                                if(readXml($article, "autoplay") != "") {
                                    $autoplay = "autoplay";
                                }
                                else {
                                    $autoplay = "";
                                }

                                if(readXml($article, "player") != "" && testFile($audio)) {
                                    echo "\t\t\t<div class='audio_box'>\n".
                                        "\t\t\t\t<audio controls class='$autoplay'>\n".
                                        "\t\t\t\t\t<source src='".$root.$audio."' type='audio/mpeg'>\n".
                                        "\t\t\t\t\tYour browser does not support the audio element.\n".
                                        "\t\t\t\t</audio>\n".
                                        //"\t\t\t\t<span>".path($audio, "basename")."</span>\n";
                                        "\t\t\t</div>\n";
                                };
                            }
                            else {
                                //echo "> $article_name<br>\n";
                            }
                        };
                        
                    } // foreach
                    
                    echo "\t\t</div>\n";
                    echo "\t</section>\n";
                } // if xml
            } // foreach
        ?>

        <?php
            echo "\n";

            // ===============================
            //           NAVIGATION
            // ===============================
        
            echo "\t<nav class='popup'>\n";
            //echo "\t\t<div class='nav_bg'></div>\n";
            echo "\t\t<div class='container'>\n".
                "\t\t\t<ul class='menu vertical_center'>\n";
            $item_class = "current";
            foreach($navigation['multi_page'] as $page) {
                if(readXml($page, "active") != "") {
                    $title = readXml($page, "title");
                    $href = readXml($page, "href");
                    echo "\t\t\t\t<li class='$item_class'><a href='$root$href/'>$title</a></li>\n";
                    $item_class = "active";
                }
            }

            echo "\t\t\t</ul>\n".
                "\t\t</div>\n".
                "\t</nav>\n";
        
            // ====== Languages ======

            echo "\t<nav class='languages'>\n";
            
            if(count($lang_list) > 1) {
                echo "\t\t<ul class='languages'>\n";
                foreach($lang_list as $id) {
                    if($id == $_SESSION['lang']) { $current = "class='current'"; } else { $current = "class='active'"; };
                    echo "\t\t\t<li $current><button value='$id'>".strtoupper($id)."</button></li>\n";
                };
                echo "\t\t</ul>\n";
            };
            echo join("", $menu['languages']);
            echo "\t</nav>\n";
        
            // ============
        
            echo "\t<nav class='toggle'>\n";
            echo "\t\t<button class='show_menu'><span class='ion-navicon-round'></span></button>\n";
        
            echo "\t</nav>\n";
        ?>
        
        <div id='popup' class='vertical_center'>
            <div class='container vertical_center'>
                <p>Popup text</p>
            </div>
        </div>

        <!-- Javascript -->
        <script>
            <?php
                echo "\n";
                echo "\t\t\tvar ROOT = '".$root."';\n";
                echo "\t\t\tvar LANG = '".$_SESSION['lang']."';\n";
                echo "\t\t\tvar LANG_LIST = [ '".join("', '", $lang_list)."' ];\n";
                if(is_string($_SESSION['popup']) && $_SESSION['popup'] != "") {
                    echo "\t\t\tvar SHOW_POPUP = '".$_SESSION['popup']."';\n";
                }
                else {
                    echo "\t\t\tvar SHOW_POPUP = false;\n";
                }
                unset($_SESSION['popup']);
            ?>
        </script>

        <script src='<?php echo $root; ?>script/jquery-3.1.0.min.js'></script>
        <script src='<?php echo $root; ?>script/functions.js'></script>
        <script src='<?php echo $root; ?>script/preview_mode.js'></script>
        <!-- <script src='script/layout.js<?php echo "?v=$updated"; ?>'></script> -->
        <script src='<?php echo $root; ?>script/layout.js?v=<?php echo uniqid(); ?>'></script>
        
	</body>

</html>
