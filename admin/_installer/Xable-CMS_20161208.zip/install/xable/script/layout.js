$(document).ready(function() {
    
    $("section").last().find(".main_box").append("<footer><a href='http://aggadesign.pl' target='_blank'>created by aggadesign.pl</a></footer>");
    
    //$(".picto").click(function() { alert( $(window).width() ); });

    // ==========================================
    //                Navigation
    // ==========================================
    
    $(window).scroll(function() {
        scroll = $(window).scrollTop();
        win_hei = $(window).height();
        if(scroll > 100) {
            $(".desktop_box .menu-main, .mobile_box button").css({ "background-color": "#e4e4e4" });
        }
        else {
            $(".desktop_box .menu-main, .mobile_box button").css({ "background-color": "transparent" });
        };
    })
    
    function showSubmenu($item) {
        // Set subitem width mached main item width
        wid = $item.width() + (parseInt( $item.css("padding-right") ) * 2);
        $item.find(".subs a").css({ "min-width": wid });
        // Show subitems group
        $item.find(".subs").stop().slideDown(300, function() { $(this).css({ "top": "40px", "padding-top": "11px" }); });
        $("#fake_cover").show();
    };
    function hideSubmenu() {
        $(".desktop_box .menu-main").find(".subs").stop().css({ "top": "50px", "padding-top": "1px" }).slideUp(300);
        $("#fake_cover").hide();
    };
    
    $(".desktop_box .menu-main .pulldown").mouseenter(function() { showSubmenu( $(this) ); });
    $(".desktop_box .menu-main .pulldown").mouseleave(function() { hideSubmenu(); });
    $("#fake_cover").click(function() { hideSubmenu(); });
    
    
    $(".mobile_box .show_menu").click(function() { showMobileMenu(); });
    $(".mobile_box .hide_menu, .mobile-outside").click(function() { hideMobileMenu(); });
   
    function showMobileMenu() {
        $(".mobile_box .show_menu").hide();
        $(".mobile_box .hide_menu").show();
        $(".mobile_box > ul > li").slideDown(450);
        $(".mobile-outside").show();
        if(navigator.userAgent.indexOf("Firefox") < 0) { $("body").css({ "overflow-y": "hidden" }); }; /* Firefox hide scroll bar */
        $(".menu-mobile").css({ "height": "100%" });
    };    
    function hideMobileMenu() {
        $(".mobile_box .hide_menu").hide();
        $(".mobile_box .show_menu").show();
        $(".mobile_box > ul > li").slideUp(333);
        $(".mobile-outside").hide();
        $("body").css({ "overflow-y": "scroll" });
        $(".menu-mobile").css({ "height": "auto" });
    };
    
    // Turn off pulldown submenus for less then two subitems
    $("nav li .subs").each(function() {
        if($(this).find("a.menu_group").length <= 1) {
            $(this).remove();
        };
    });
    
    // ==========================================
    //                 Language
    // ==========================================    
    
    $(".menu-languages .change").click(function() {
        change = $(this).attr("value");
        location.href = "index.php?lang=" + change;
    });
    
    if(location.href.indexOf("?lang=") > -1) {
        lang = location.href.split("?lang=").pop();
        title = document.title;
        window.history.pushState(window.location.href, title, lang);
    };

    // ==========================================
    //               Smooth Scroll
    // ==========================================
    
	$("nav a, a.scroll").click( function() {
        hideSubmenu();
        hideMobileMenu();
        if($(this).attr("class") == "menu_group") { marg = 75; } else { marg = 20; };
        href = $(this).attr("href");
        if(href.substr(0, 1) == "#") {
            $("html, body").animate({
                scrollTop: ($(href).offset().top - marg)
            }, 750);

            // change url
            url = href.substr(1);
            title = document.title;
            window.history.pushState(window.location.href, title, url);
            
            return false;
        }
        else if(href == false || href == "") {
            return false;
        };
    });
    
	function scrollToId(id, marg) {
        if(jQuery.type(id) == "string" && id != "") {
            id = "#" + id;
            if($(id).length) {
                marg = 20;
                $("html, body").animate({
                    scrollTop: ($(id).offset().top - marg)
                }, 750);
            };

        };
    };
    
    // ==========================================
    //                 Big fonts
    // ==========================================
    
    $("#menu tr td").each(function() {
        col = $(this).attr("class");
        if(col == "col_1") {
            text = $(this).text();
            text = "<span class='big_font'>" + text.substr(0, 1) + "</span>" + text.substr(1);
            text = $(this).html(text);
        }
        else if(col == "col_2") {
            text = $(this).text().split(" ");
            first = text.shift();
            text = "<span class='big_font'>" + first + "</span> " + text.join(" ");
            text = $(this).html(text);
        };
    });
    
    // ==========================================
    //              Start Slideshow
    // ==========================================
    
    // Show first slide on initialize
    $("#start .slideshow figure").first().show().addClass("current_slide");
    
    // Get & set time values (send with php)
    if($("#start .slideshow .duration").length) {
        var SLIDE_DURATION = parseInt( $("#start .slideshow .duration").val() );
        if(SLIDE_DURATION < 1000) { SLIDE_DURATION = 1000; };
    }
    else {
        var SLIDE_DURATION = 1000;
    };
    if($("#start .slideshow .transition").length) {
        var SLIDE_TRANSITION = parseInt( $("#start .slideshow .transition").val() );
        if(SLIDE_TRANSITION < 100) { SLIDE_TRANSITION = 100; };
    }
    else {
        var SLIDE_TRANSITION = 100;
    };
    
    $(".hide-scroll-bar").css({ "width": $("#content").width() });
    
    // ==========================================
    //               Launch page
    // ==========================================
    
    $("#loader").fadeIn(250);
    setTimeout(function() {
        $("#loader").fadeOut(250);
        $("#content").fadeIn(500, function() {
            $(window).on("load resize", function() {
                $(".hide-scroll-bar").css({ "width": $("#content").width() });
            });

            var FIRST_SLIDE = true;
            function slideChange() {
                if(FIRST_SLIDE) {
                    delay = SLIDE_DURATION - SLIDE_TRANSITION; 
                    FIRST_SLIDE = false;
                }
                else {
                    delay = SLIDE_DURATION;
                }
                setTimeout(function() {
                    $current = $("#start .slideshow .current_slide");
                    $next = $current.next("figure");
                    if($next.length) {
                        $next.fadeIn(SLIDE_TRANSITION, function() {
                            $current.hide().removeClass("current_slide");
                            $next.addClass("current_slide");
                        });
                    }
                    else {
                        $("#start .slideshow figure").first().show().addClass("current_slide");
                        $current.fadeOut(SLIDE_TRANSITION, function() {
                            $current.removeClass("current_slide");
                        });
                    };
                    slideChange();
                }, delay);
            };

            if($("#start .slideshow figure").length > 1) {
                slideChange();
            };

            if($("input#scroll_to_sectio").val() != "") {
                scrollToId( $("input#scroll_to_section").val() );
            };
        });
    }, 1500);

    // ==========================================
    //               Popup Gallery
    // ==========================================
    
    var ANIMATION_TIME = 300;
    var SLIDE_NUM = 0;
    
    function showGallery(images) {
        //alert(images);
        $("#popup_box .images_box figure").remove();
        for(i in images) {
            html = "<figure class='image' style='background-image:url(\"" + images[i] + "\")'></figure>\n";
            $("#popup_box .images_box").append(html);
        };
        $("#popup_box .images_box figure").hide();
        $("#popup_box .images_box figure").eq(0).show();
        if($("#popup_box .images_box figure").length > 1) {
            $("#popup_box .prev, #popup_box .next").show();
        }
        else {
            $("#popup_box .prev, #popup_box .next").hide();
        };
        $("#popup_box").fadeIn(ANIMATION_TIME);
        $("body").css({ "overflow": "hidden" });
        SLIDE_NUM = 0;
    };
    
    // Open gallery in popup box
    $("div.gallery button").click(function() {
        // show first
        images = $(this).find("input.subgallery").first().val().split(";");
        if(images.length > 0) { showGallery(images); };
        
        if($(this).find("input.subgallery").length > 1) {
            // ====== Build subgalleries menu ======
            subgalleries = [];
            $(this).find("input.subgallery").each(function() {
                subgalleries[subgalleries.length] = "\t<li class='list_item' value='" + $(this).val() + "'>" + $(this).attr("name").toUpperCase() + "</li>\n";
            });
            html = "<div class='subgalleries_box'><ul class='subgalleries'>\n" +
                subgalleries.join("") +
                //"<li class='show_list'><i class='fa fa-chevron-up'></i></li>" +
                "</ul></div>\n";
            $("#popup_box").append(html);
            
            // ====== Launch first subgallery ======
            $("#popup_box").find(".subgalleries li.list_item").first().removeClass("list_item").addClass("show_list");
        
            initializeSubgalleryChange();
            initializeFoldExpand();
            // Show & hide at start
            setTimeout(function() {
                foldSubgalleriesMenu();
            }, 1000);
        };
    });
    
    function initializeSubgalleryChange() {
        $("#popup_box .subgalleries li.list_item").unbind("click").click(function() {
            $("#popup_box .subgalleries_box .subgalleries").unbind("mouseleave");
            $clicked = $(this);
            images = $(this).attr("value").split(";");
            $("#popup_box .images_box").fadeOut(ANIMATION_TIME, function() {
                $("#popup_box .images_box figure").remove();
                $("#popup_box .prev, #popup_box .next").css({ "opacity": "0.7" });
                showGallery(images);
                $("#popup_box .subgalleries_box .show_list").attr("class", "list_item");
                $clicked.attr("class", "show_list");
                foldSubgalleriesMenu();
                initializeSubgalleryChange();
                
                $("#popup_box .images_box").fadeIn(ANIMATION_TIME);
                $("#popup_box .subgalleries li").blur();
                
                // fix for mouseleave during fold animation
                setTimeout(function() {
                    initializeFoldExpand();
                }, ANIMATION_TIME * 2);
            });
        });
    };
    
    function initializeFoldExpand() {
        $("#popup_box .subgalleries_box .show_list").unbind("click").click(function() {
            if($(this).closest("ul").find(".list_item").css("display") == "none") {
                expandSubgalleriesMenu();
            }
            else {
                foldSubgalleriesMenu();
            };
        });
        $("#popup_box .subgalleries_box .show_list").unbind("mouseenter").mouseenter(function() {
            if($(this).closest("ul").find(".list_item").css("display") == "none") {
                expandSubgalleriesMenu();
            };
        });  
        $("#popup_box .subgalleries_box .subgalleries").unbind("mouseleave").mouseleave(function() {
            if($(this).closest("ul").find(".list_item").css("display") != "none") {
                foldSubgalleriesMenu();
            };
        });  
    };
    
    function foldSubgalleriesMenu() {
        $("#popup_box .subgalleries_box .list_item").slideUp(ANIMATION_TIME, function() {  SUBGALLERY_BUSY = false; });
        //$("#popup_box .subgalleries_box .subgalleries").css({ "opacity": 0.7 });
    };
    
    function expandSubgalleriesMenu() {
        $("#popup_box .subgalleries_box .list_item").slideDown(ANIMATION_TIME, function() {  SUBGALLERY_BUSY = false; });
        //$("#popup_box .subgalleries_box .subgalleries").css({ "opacity": 1 });
    };
    
    // Popup buttons actions
    $("#popup_box .prev").click(function() {
        len = $(window).width() + parseInt( $("#popup_box").css("margin-left") );
        $current = $("#popup_box .images_box figure").eq(SLIDE_NUM--);
        $next = $("#popup_box .images_box figure").eq(SLIDE_NUM);
        if(!$next.length) {
            SLIDE_NUM = $("#popup_box .images_box figure").length - 1;
            $next = $("#popup_box .images_box figure").eq(SLIDE_NUM);
        };
        $current.animate({ "left": len }, ANIMATION_TIME, function() { $(this).hide(); });
        $next.css({ "left": len * -1, "display": "block" }).animate({ "left": 0 }, ANIMATION_TIME);
    });
    $("#popup_box .next").click(function() {
        len = $(window).width() + parseInt( $("#popup_box").css("margin-left") );
        $current = $("#popup_box .images_box figure").eq(SLIDE_NUM++);
        $next = $("#popup_box .images_box figure").eq(SLIDE_NUM);
        if(!$next.length) {
            SLIDE_NUM = 0;
            $next = $("#popup_box .images_box figure").eq(SLIDE_NUM);
        };
        $current.animate({ "left": len * -1 }, ANIMATION_TIME, function() { $(this).hide(); });
        $next.css({ "left": len, "display": "block" }).animate({ "left": 0 }, ANIMATION_TIME);
    });
    
    $("#popup_box .close").click(function() {
        $("#popup_box").fadeOut(ANIMATION_TIME, function() {
            $("#popup_box .images_box figure, #popup_box .images_box iframe").remove();
            $("#popup_box .subgalleries_box").remove();
        });
        $("body").css({ "overflow": "auto" });
    });
    
    // Change a tag into a div for popup link -> block auto new window open on mobile devices
    $("section .button_box button").each(function() {
        if($(this).attr("class").indexOf("popup") > -1) {
            html = $(this).parent().parent().html();
            html = html.replace("<a ", "<div class='href' ");
            html = html.replace("</a>", "</div>");
            $(this).parent().replaceWith(html);
        };
    });

    // Open link in popup box
    $("section .button_box .popup").click(function() {
        href = $(this).parent().attr("href");
        $("#popup_box .images_box figure").remove();
        html = "<iframe src='" + href + "'></iframe>";
        $("#popup_box .images_box").append(html);
        $("#popup_box").fadeIn(ANIMATION_TIME);
        $("body").css({ "overflow": "hidden" });
        $("#popup_box .prev, #popup_box .next").hide();
    });
    

})