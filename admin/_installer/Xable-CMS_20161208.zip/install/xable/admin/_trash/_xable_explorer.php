<?php
    session_start();
	require "script/functions.php";
	require "script/xml.php";
	require "script/cms.php";

    $ini_pathes = loadIni("xable.ini", "pathes");
    $root = $ini_pathes['root'];
    $error = array();

    //echo "<hr>GET<hr>";
    //arrayList($_GET);
    //echo "<hr>POST<hr>";
    //arrayList($_POST);
    //echo "<hr>FILES<hr>";
    //arrayList($_FILES);
?>

<html>
    <head>
		<meta charset='utf-8'>
        <title>X.able CMS / Explorer</title>
        <link href='http://fonts.googleapis.com/css?family=Inconsolata:400,700&subset=latin,latin-ext' rel='stylesheet' type='text/css'>

        <style>

            /* ================================== */
            /*           Console style            */
            /* ================================== */
            
            body {
                width: 100%;
                height: 100%;
                padding: 0 20px;
                font-family: 'Inconsolata';
                font-size: 14px;
                font-weight: normal;
            }

            article { display: none; }
            * { margin: 0; padding: 0; }
            h2 { padding-top: 20px; font-size: 18px; font-weight: bold; }
            p { padding-top: 1px; }
            p span { margin-right: 10px; }
            .info { font-size: 11px; }
            .done { color: #22aa22; }
            .log { color: #999999; }
            .error { color: #ff0000; font-weight: bold; }
            .error:before { content: "ERROR! "; }
            textarea { width: 700px; height: 500px; }
            button { margin-top: 20px; padding: 10px; }
        </style>
    </head>
    <body>

        <article>
            <?php
                $path = $_POST['path'];
                if($path == "") { $dir = $root; } else { $dir = $root."/".$path; };

                // ====== ACTIONS ======

                // New Folder
                if($_GET['action'] == "new_folder") {
                    $folder = $dir."/".$_POST['filename'];
                    mkdir($folder);
                    if(file_exists($folder)) {
                        echo "<p class='log'>New folder created: <a>$folder</a></p>";
                    }
                    else {
                        $error[] = "<p class='error'>New folder NOT created: <a>$folder</a></p>";
                    };
                }
                // Delete
                else if($_GET['action'] == "delete") {
                    foreach($_POST['selected'] as $name) {
                        $folder = $dir."/".$name;

                        if(!file_exists($folder)) {
                            $error[] = "<p class='error'>File/folder not found: <a>$folder</a></p>";
                        }
                        else if(is_dir($folder)) {
                            if($folder != "" && $folder != $root) {
                                removeDir($folder);
                                echo "<p class='log'>Folder deleted: <a>$name</a></p>";
                            }
                            else {
                                $error[] = "<p class='error'>Root & Admin folder cannot be deleted: <a>$folder</a></p>";
                            };
                        }
                        else {
                            unlink($folder);
                            echo "<p class='log'>File deleted: <a>$name</a></p>";
                        };
                    };
                }
                // rename
                else if($_GET['action'] == "rename") {
                    $old = $_POST['selected'][0];
                    $new = $_POST['filename'];
                    rename("$dir/$old", "$dir/$new");
                    if(!file_exists("$dir/$old") && file_exists("$dir/$new")) {
                        echo "<p class='log'>Rename done: $old -> $new</p>";
                    }
                    else {
                        $error[] = "<p class='error'>Unable to rename file/folder: $old -> $new</p>";
                    };
                }
                // duplicate
                else if($_GET['action'] == "duplicate") {
                    $old = $_POST['selected'][0];
                    $new = $_POST['filename'];

                    if(is_dir("$dir/$old")) {
                        echo "$dir/$old";
                        copyDir("$dir/$old", "$dir/$new");
                    }
                    else {
                        copy("$dir/$old", "$dir/$new");

                    };
                    if(file_exists("$dir/$new")) {
                        echo "<p class='log'>Copy done: $old -> $new</p>";
                    }
                    else {
                        $error[] = "<p class='error'>Unable to copy file/folder: $old -> $new</p>";
                    };
                }
                // COPY / CUT
                else if($_GET['action'] == "copy" || $_GET['action'] == "cut") {
                    $_SESSION['clipboard_action'] = $_GET['action'];
                    $_SESSION['clipboard_content'] = array();
                    foreach($_POST['selected'] as $name) {
                        $_SESSION['clipboard_content'][] = "$dir/$name";
                        echo "<p class='log'>File(s) added to clipboard: $name</p>";
                    };
                }
                // PASTE -> no paste in the same location!!!! overwrite block?
                else if($_GET['action'] == "paste") {
                    foreach($_SESSION['clipboard_content'] as $old) {
                        if(file_exists($old)) {
                            $new = "$dir/".path($old, "basename");
                            echo "paste> $old -> $new<br>\n";
                            if($_SESSION['clipboard_action'] == "copy") {
                                if(is_dir($old)) {
                                    copyDir($old, $new);
                                }
                                else {
                                    copy($old, $new);
                                };
                                echo "<p class='log'>Copy-Paste: <a>$old</a> -> <a>$new</a></p>";
                            }
                            else {
                                rename($old, $new);
                                echo "<p class='log'>Cut-Paste: <a>$old</a> -> <a>$new</a></p>";
                            };
                        }
                        else {
                            $error[] = "<p class='error'>File/folder not found!</p>";
                        };
                    };

                    if($_SESSION['clipboard_action'] == "cut") {
                        $_SESSION['clipboard_content'] = array();
                        echo "<p class='log'>Clipboard cleared!</p>";
                    };
                }
                // UPLOAD
                else if($_GET['action'] == "upload") {
                    $names = $_FILES['upload']['name'];
                    $tmps = $_FILES['upload']['tmp_name'];
                    foreach(array_keys($names) as $i) {
                        $name = $names[$i];
                        $tmp = $tmps[$i];
                        copy($tmp, "$dir/$name");
                        if(file_exists("$dir/$name")) {
                            echo "<p class='log'>Uploaded file: <a>$dir/$name</a></p>";
                        }
                        else {
                            $error[] = "<p class='error'>Upload failed: <a>$dir/$name</a></p>";
                        };
                    }
                }
                else if($_GET['action'] == "save") {
                    $file = "$dir";
                    echo "file: $file<br>\n";
                    file_put_contents($file, $_POST['content']);
                    if(file_exists($file)) {
                        echo "<p class='log'>File saved: <a>$file</a></p>";
                    }
                    else {
                        $error[] = "<p class='error'>Saving failed: <a>$file</a></p>";
                    };
                }
                // unknown
                else {
                    $error[] = "<p class='error'>Undefined action: <a>".$_GET['action']."</a></p>";
                };
            ?>
            
        </article>
    
        <?php 
            // ====== OUTPUT: redirect or error raport ======
            if(count($error) > 0) {

                echo "<script src='script/jquery-3.1.0.min.js'></script>\n";
                echo "<script> $('article').show(); </script>\n";

                echo join("\n", $error)."<hr>\n";
                echo "<hr>GET<hr>";
                arrayList($_GET);
                echo "<hr>POST<hr>";
                arrayList($_POST);
                echo "<hr>FILES<hr>";
                arrayList($_FILES);

                echo "<hr>";
                echo "<a href='xable_explorer.php?path=$path'><button>Back</button></a>\n";
            }
            else {
                echo "<script> location.href = \"xable_explorer.php?path=$path\"; </script>\n";
            };
        ?>
    </body>
</html>