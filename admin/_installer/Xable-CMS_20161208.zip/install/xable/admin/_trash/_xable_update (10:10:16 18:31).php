<?php
    session_start();
	require "script/functions.php";
	require "script/xml.php";
	require "script/cms.php";

    $ini_pathes = loadIni("xable.ini", "pathes");
    $installer_folder = "_installer";
    $error = array();

    // ====== REMOVE ======
    if(is_string($_GET['remove']) && $_GET['remove'] != "") {
        $filepath = $installer_folder."/".$_GET['remove'];
        if(file_exists($filepath)) {
            unlink($filepath);
            header("Location: xable_update.php");
        }
        else {
            $error[] = "<p class='error'>File not found: $filepath</p>";
        };
    }
    // ====== UPLOAD & INSTALL ======
    elseif(is_array($_FILES['zip'])) {
        $zip = $_FILES['zip'];
        if($zip['error'] == 0) {
            $filename = $zip['name'];
            $temp = $zip['tmp_name'];
            copy($temp, "$installer_folder/$filename");
            
            if(file_exists("$installer_folder/$filename") && file_exists("$installer_folder/unzip.php")) {
                $root = $ini_pathes['root'];
                $unzip = "unzip.php";
                // Delete any previous xable package versions
                foreach(listDir($root, "zip") as $file) {
                    if(strstr(strtolower($file), "xable")) { unlink("$root/$file"); };
                };
                // Copy package files
                copy("$installer_folder/$filename", "$root/$filename");
                copy("$installer_folder/$unzip", "$root/$unzip");
                if(file_exists("$root/$filename") && file_exists("$root/$unzip")) {
                    header("Location: $root/$unzip");
                }
                else {
                    $error[] = "<p class='error'>Installer files copy error!</p>";
                };
            }
            else {
                $error[] = "<p class='error'>Installer files not found!</p>";
            };
        }
        else {
            $error[] = "<p class='error'>Package upload ERROR!</p>";
        };
    }
    // ====== UPDATE CHANGELOG ======
    if($_GET['action'] == "changelog") {
        $log_path = "doc/change.log";
        $changes = array();
        $notes = array();
        foreach(file($log_path) as $txt) {
            //echo "$txt<br>";
            if(count($notes) > 0 || substr($txt, 0, 1) == "=") {
                $notes[] = $txt;
            }
            else {
                $changes[] = $txt;
            }
        }
        //arrayList($changes);
        $new_change = array();
        $new_change[] = $_POST['time']."\n";
        foreach(split("\n", $_POST['info']) as $txt) {
            $new_change[] = "\tInfo:\t".$txt."\n";
        };
        $new_change[] = "\tFiles:\t".$_POST['files']."\n";
        $new_change[] = "\n";
        
        
        
        $log_content = array_merge($changes, $new_change, $notes);
        safeSave($log_path, join("", $log_content));
        header("Location: xable_update.php");
    }
    else {
        $error[] = "<p class='error'>DATA ERROR!</p>";
    };

    // ====== ERRORS ======
    if(count($error) > 0) {
        echo join("\n", $error)."<hr>\n";
		arrayList($_POST);
		arrayList($_FILES);
    };
    

?>