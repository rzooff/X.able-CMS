<?php
    // ======================================
    //          ><.able CMS - CREATOR
    //        (C)2016 maciejnowak.com
    //          v.2.0 build.0
    // ======================================
	// compatibile: php4 or higher

    require("modules/_session-start.php");
    $admin_folder = $_SESSION['admin_folder'];
    $ini_pathes = loadIni("xable.ini", "pathes");
    $root = $ini_pathes['root'];
    

    if(is_string($_GET['path']) && $_GET['path'] != "") {
        if(is_dir($root."/".$_GET['path'])) {
            $current_dir = $_GET['path'];
            $current_file = false;
        }
        else {
            $current_file = $_GET['path'];
            $current_dir = path($current_file, "dirname");
        };
    }
    else {
        if(!is_string($_GET['path'])) { unset($_SESSION['clipboard_content']); };
        $current_dir = "";
        $current_file = false;
    };

    //arrayList($_SESSION);

?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>X.able CMS / Explorer</title>
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
        <link rel="stylesheet" type="text/css" href="style/xable_creator.css" />
        <link rel="stylesheet" type="text/css" href="style/xable_explorer.css" />
        
        <script src='script/jquery-3.1.0.min.js'></script>
        <script src='script/functions.js'></script>
	</head>
	<body>
        <main>
            <nav>
                <div id="menu_bar">
                    <label class='logo'>
                        <span>&gt;&lt;</span>
                    </label>
                    <label class='title menu'>
                        <p>Explorer</p>
                        <ul>
                            <li>Creator</li>
                            <li>Users</li>
                            <li>Update</li>
							<li class='separator'><hr></li>
                            <li>Quit</li>
                        </ul>
                    </label>
                </div>
            </nav>
                
            <article id='explorer'>
                <h3><span class="article_icon fi-folder"></span>File browser</h3>
                <section id='current_dir'>
                    <?php
                    
                        if($current_dir == "") {
                            echo "<h2>/</h2>\n";
                            echo "<button class='disabled'><span class='fi-arrow-up'></span></button>\n";
                        }
                        else {
                            echo "<h2>/$current_dir</h2>\n";
                            echo "<button class='path' path='".path($current_dir, "dirname")."'><span class='fi-arrow-up'></span></button>\n";
                        };
                    
                    ?>

                </section>
                <section id='browser'>
                    <form action='_xable_explorer.php?action=@action' method='post'>
                        <input type='hidden' class='path' name='path' value='<?php echo $current_dir; ?>'>
                    <!-- delete, rename, download, cut, copy, duplicate -->

                        <?php
                            echo "\n";
                        
                            echo "<table>\n";
                            echo "\t<tr class='header'>\n".
                                    "\t\t<td class='icon deselect'><span class='fi-check'></span></td>\n".
                                    "\t\t<td class='filename'>Name</td>\n".
                                    "\t\t<td class='size'>Size</td>\n".
                                    "\t\t<td class='time'>Modified</td>\n".
                                "\t</tr>\n";
                            $dir_list = listDir("$root/$current_dir", "*");
                            echo "<input type='hidden' id='dir_list' value='".join(";", $dir_list)."'>\n";
                            foreach($dir_list as $name) {
                                $path = "$root/$current_dir/$name";
                                if(is_dir($path)) {
                                    $type = "folder";
                                    $icon = "fi-folder";
                                    $current = "";
                                    $size = "-";
                                    $time = path($path, "modified");
                                }
                                else {
                                    $type = "file";
                                    $icon = "fi-page";
                                    if($name == path($current_file, "basename")) { $current = "current"; } else { $current = ""; }
                                    $size = path($path, "size");
                                    if($size > 1024) { $size = ($size / 1024) . " MB"; } else { $size = $size." kB"; };
                                    $time = path($path, "modified");
                                };

                                echo "\t<tr class='path $type $current' path='$current_dir/$name'>\n".
                                        "\t\t<td class='icon'><span class='$icon'></span></td>\n".
                                        "\t\t<td class='filename'><input type='checkbox' class='select' name='selected[]' value='$name'><span>$name</span></td>\n".
                                        "\t\t<td class='file_info size'><span>$size</span></td>\n".
                                        "\t\t<td class='file_info time'><span>$time</span></td>\n".
                                    "\t</tr>\n";

                            };
                            echo "</table>\n";
                        ?>
                    </form>
                </section>
                
                <button class='new_folder'>New folder</button>
                <button class='upload'>Upload</button>
                <!-- <button class='deselect'>Deselect All</button> -->

            </article>
            
            <article id='clipboard'>
                <h3><span class="article_icon fi-marker"></span>Clipboard (<?php echo $_SESSION['clipboard_action']; ?>)</h3>
                <form action='_xable_explorer.php?action=paste' method="post" enctype='multipart/form-data'>
                    <input type='hidden' class='path' name='path' value='<?php echo $current_dir; ?>'>
                    <?php
                        
                        if(is_array($_SESSION['clipboard_content']) && count($_SESSION['clipboard_content']) > 0) {
                            foreach($_SESSION['clipboard_content'] as $file_path) {
                                $relative_path = substr($file_path, strlen($root) + 1);
                                echo "<p class='clipboard'>$relative_path<input type='hidden' name='clipboard[]' value='$file_path'></p>";
                            };
                        };
                    ?>
                    <button class='paste'>Paste</button>
                </form>
            </article>
            
        </main>
        <aside>
            <div id='code'>
                <?php
                    $text_files = split(",", "csv,draft,eml,htm,html,ini,js,log,lsp,order,php,prev,rtf,template,txt,xml");
                    if($current_file && file_exists("$root/$current_file") && !is_dir("$root/$current_file")) {
                        $file = "$root/$current_file";
                        echo "<input type='hidden' id='current_file' value='$current_file'>\n";
                        echo "<a href='$file' target='_blank'>".path($current_file, "basename")."</a> <span class='flag edit'>[edit]</span><hr>";
                        
                        
                        if((substr(path($file, "basename"), 0, 1) == "." && path($file, "filename") == "") || in_array(path($file, "extension"), $text_files)) {
                            $content = file($file);

                            
                            foreach($content as $txt) {
                                $txt = str_replace("<", "&lt;", $txt);
                                $txt = str_replace(">", "&gt;", $txt);
                                $txt = str_replace(" ", "&nbsp;", $txt);
                                $txt = str_replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;", $txt);

                                echo "<span class='tag'>$txt</span><br>\n";
                            };
                        }
                        else {
                            echo "<span class='flag'>No preview avaliable.</span>";
                        };
                    }
                    else {
                        echo "<span class='flag'>Nothing selected.</span>";
                    };
                ?>
            </div>
        </aside>
        <textarea id='file_content'><?php echo join("", $content); ?></textarea>

        <script src='script/xable_explorer.js'></script>
        
	</body>
</html>

    

