><.able CMS v.3
---------------
System zarządzania treścią oparty na standardach XML

(C)2017 - maciej@maciejnowak.com

Instalacja:
1. Załaduj na swój serwer FTP paczkę instalatora Xable (zip) oraz plik unzip.php.txt.
2. Zmień nazwię pliku "unzip.php".txt na "unzip.php".
3. Otwórz przeglądarkę i otwórz lokalizację pod, którą widoczny jest plik unzip.php location (np. http://twoja_domena.pl/unzip.php).
4. Postepuj wg instrukcji widocznych na ekranie...
