<?php
    $_SESSION['logged_user'] = false;
    session_start();
    session_destroy();
    unset($_SESSION);
    if(is_string($_GET['info'])) {
        header("Location: login.php?info=".urlencode($_GET['info']));
    }
    else {
        header("Location: login.php");
    };
?>