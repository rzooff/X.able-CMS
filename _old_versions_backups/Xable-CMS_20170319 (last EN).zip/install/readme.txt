><.able CMS v.3
---------------
XML based website Content Management System

(C)2017 by maciej@maciejnowak.com

Installation:
1. Upload Xable packag (zip)e & unzip.php.txt files to your FTP server.
2. Rename unzip.php.txt to unzip.php.
3. Open your browser and open unzip.php location (eg. http://your_server.com/unzip.php).
4. Follow onscreen instructions...
