<?php
	// compatibile: php4 or higher
    session_start();
    if(!is_string($_SESSION['logged_user'])) {
        header("Location: login.php");
        break;
    };

    require "script/functions.php";
    require "script/cms.php";
    require "script/xml.php";

    // ====== Variables ======
	$ini_file = $_SESSION['ini_file'];
    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $ini_enable = loadIni($ini_file, "enable");
    $pass_path = $ini_pathes['passwords'];

    $admin_folder = $_SESSION['admin_folder'];
    $backup_folder = "$root/$admin_folder/_backup";
    $installer_folder = "$root/$admin_folder/_installer";

	$settings = loadXml($ini_pathes['settings']);

    // ====== BACKUP NOW ======
    $domain = readXml($settings, "page domain");
    if(is_string($domain) && $domain != "") {
        if($_GET['action'] == "backup") {
            $bak_name = readXml($settings, "page domain")."_".date("Ymd-Hi").".zip"; // domain.com_yyymmdd-homi.zip
            $bak_filesTree = filesTree($root, ".", array($backup_folder, $installer_folder, "$root/_bak"));
            //arrayList($bak_filesTree);
            archiveFiles("$backup_folder/$bak_name", $bak_filesTree);
        };
    }
    else {
        echo "<script> alert('Niestety wystąpił problem z odczytem ustawień.\nSpróbuj jeszcze raz.'); </script>\n";
    };
?>

<!doctype html>
<html>
	<head>
        <!-- Loader Style -->
        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }
        </style>
        <!-- Loader Style / end -->
		<meta charset="UTF-8">
		<title>X.able CMS / Backup</title>
        
		<link rel="stylesheet" type="text/css" href="style/index.css" />
		<link rel="stylesheet" type="text/css" href="style/cms.css" />
        <link rel="stylesheet" type="text/css" href="style/colors.css" />
        <link rel="stylesheet" type="text/css" href="style/password.css" />
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		
        <script src='script/jquery-1.11.2.min.js'></script>
        <script src='script/functions.js'></script>
	</head>
    
	<body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        
        <form id="backup" method='post' action='backup.php?action=backup'>
            <div id="page_fader"></div>
            <div id="popup_container">
                <div id="popup_box">
                    <h6><span class="fi-save"></span></h6>
                    <h3>Kopia zapasowa</h3>
                    <div class='inputs'>
						<p class='label'>Data ostatniej archiwizacji</p>
						<?php
							// ====== Sort backups by creation date (in filenames) ======
							$backups = array();
							$backup_files = listDir($backup_folder, "zip");
							foreach($backup_files as $file) {
								$date = array_pop(split("_", path($file, "filename")));
								if(is_string($date)) { $backups[$date] = $file; }
							};
							ksort($backups); // sort by creation date
							// ====== DELETE BACKUP EXCEEDS NUMBER OF 10 ======
							while(count($backups) > 10) {
								unlink("$backup_folder/".array_shift($backups));
							};
							// ====== LAST BACKUP ======
							if($_GET['action'] == "backup") {
								echo "<input type='text' class='string' value='Przed chwilą' disabled>\n";
							}
							else {
								$last = end($backups);
								$date = array_pop(split("_", path($last, "filename")));
								$date = substr($date, 0, 4)."-".substr($date, 4, 2)."-".substr($date, 6, 2).
									", ".substr($date, 9, 2).":".substr($date, 11, 2);
								echo "<input type='text' class='string' value='$date' disabled>\n";
							};
						?>
                        
                        
                        <div class='text'>
                            <p class='label'>Pobierz archiwum</p>
                            <p class='description'>Najnowsze na górze</p>
                            <ul>
								<?php

									// ====== ARCHIVES LIST ======
									foreach(array_reverse($backups) as $file) {
										$path = "$backup_folder/$file";
										$size = path($path, "size");
										echo "<li><a href='$path'>$file</a><span class='size'>$size Kb</span></li>";
									};
								?>
                            </ul>
							
                        </div>
                        <div class='text'>
                            <p class='description'>Gdy liczba plików przekracza 10, najstarszy z nich jest kasowany.</p>
                        </div>
                    </div>
                    <div class='buttons'>
                        <button class='confirm'>Archiwizuj teraz</button>
                        <button class='cancel'>Zamknij</button>
                    </div>
                </div>
            </div>
        </form>
        
        <?php 
            if(is_string($popup)) { echo "<input id='popup' value='$popup'>\n"; };
            if(is_string($redirect)) { echo "<input id='redirect' value='$redirect'>\n"; };
        
            foreach(array_keys($ini_enable) as $key) {
                echo "<input type='hidden' id='enable_$key' value='".$ini_enable[$key]."'>\n";
            };
        ?>
        
        <script src='script/footer.js'></script>
        <script src='script/backup.js'></script>
        
	</body>
</html>

