<?php
    echo "\n";

    echo "\t\t<nav>\n";
    echo "\t\t\t<h1><strong>><</strong>.able<span>CMS</span></h1>\n";
    echo "\t\t\t<aside id='search'>\n";
    echo "\t\t\t\t<input type='text' name='search' placeholder='Szukaj...' value=''>\n";
    echo "\t\t\t\t<button type='submit'><span class='fi-magnifying-glass'></span></button>\n";
    echo "\t\t\t</aside>\n";

    // ======================================
    //        Define editable content
    // ======================================

    function getNavLabels($path, $admin_lang) {
    // --------------------------------
    // $path = <string> menu xml file path
    // $admin_lang = <string> lang code
    // --------------------------------
    // RETURNS: <array> Page titles associatet with target links
    // --------------------------------
        $nav_xml = loadXml($path);
        $nav_tag = "multi_page";
        $navigation = array(); // links & titles
        foreach($nav_xml[$nav_tag] as $page) {
            //arrayList($page);
            $href = $page['href'][0]['string'][0];
            $label = $page['title'][0]['text'][0][$admin_lang][0];
            $hash_link = split("#", $href);
			$file_link = split("\.", $href);
            if(count($hash_link) == 2) { // #hash
                $key = $hash_link[1];
            }
			elseif(count($file_link) == 2) { // page.ext
				$key = $file_link[0];
			}
            else { // page
                $key = $href;
            };
			// Add to list
            if(substr($href, 0, 7) != "http://" && substr($href, 0, 8) != "https://" && !$navigation[$key]) { // ignore external links & not already defined
                $navigation[$key] = $label;
            };
        };
        return $navigation;
    };

    // ======================================
    //          generate Navigation
    // ======================================
	$nav_list = array();
    echo "\t\t\t<dl>\n";
    foreach(array_keys($nav_documents) as $title) {
        $data = split("@", $nav_documents[$title]);
        $icon = $data[0];
        if($icon == "") { $icon = "fi-page"; };
		$nav_group = array();
        $nav_group[] = "\t\t\t\t<div class='group'>\n";
        $nav_group[] = "\t\t\t\t\t<dt>$title<span class='expand fi-minus manual' help='Zwiń listę podstron'></span></dt>\n";
        $items = split(";", $data[1]);
        foreach($items as $item) {
            // Content analyze
            $item = split("\|", $item);
            $navigation = false;
            // second value: xml navigation file path
            if(is_string($item[1]) && $item[1] != "" && file_exists($root."/".$item[1])) {
                $navigation = getNavLabels($root."/".$item[1], $admin_lang);
                $label = "*";
            }
            // second value: menu label 
            elseif(is_string($item[1]) && $item[1] != "") {
                $label = $item[1];
            }
            // no second value
            else {
                $label = path($item[0], "filename");
            };
            $document_path = $root."/".$item[0];
            // ====== List all files in folder ======
            if($label == "*") {
                // Template -> Add page button
				if($ini_enable['template'] != "false") {
					if(count($templates = listDir( path($document_path, "dirname"), "template,?" )) >0) {
						$taken_names = array_map("strtolower", listDir( path($document_path, "dirname"), "xml" )); // Already taken xml names
						$nav_group[] = "\t\t\t\t\t<dd class='template' taken='".join(";", $taken_names)."' href='".join(";", $templates)."'><span class='fi-plus'></span>Dodaj stronę</dd>\n";
					};
				};
                // Pages list
                $group_by_nav = array();
                $group_by_name = array();
                foreach(listDir( path($document_path, "dirname"), path($document_path, "extension").",?" ) as $document_path) {
					//echo "> $document_path<br>\n";
                    if(file_exists($document_path)) {
                        $label = path($document_path, "filename");
                        if(is_array($navigation) && is_string($navigation[$label])) {
							$label = $navigation[$label];
							$html = "\t\t\t\t\t<a href='index.php?path=$document_path'><dd><span class='$icon'></span>$label</dd></a>\n";
							$group_by_nav[strtolower($label)] = $html;
						}
						else {
							$label = ucfirst(str_replace("_", " ", $label));
							$html = "\t\t\t\t\t<a href='index.php?path=$document_path'><dd><span class='$icon'></span>$label</dd></a>\n";
							$group_by_name[strtolower($label)] = $html;
						}
                    }
                    else {
                        $label = $document_path;
                        $html = "<dd style='color:#fd585e'><span class='$icon'></span>Not found: '$label'</dd>\n";
						$group_by_name[strtolower($label)] = $html;
                    };
                };
				//arrayList($group_by_name);
                ksort($group_by_name);
				foreach($navigation as $label) {
					if($item = $group_by_nav[strtolower($label)]) { $nav_group[] = $item; };
				};
				foreach($group_by_name as $item) { $nav_group[] = $item; };
            }
            // ====== Single file ======
            elseif(file_exists($document_path)) {
                if(is_array($navigation) && is_string($navigation[$label])) { $label = $navigation[$label]; };
                $label = ucfirst(str_replace("_", " ", $label));
                if(path($document_path, "extension") == "order") { $item_icon = "fi-list"; } else { $item_icon = $icon; }; // Order icon override -> list
                $nav_group[] = "\t\t\t\t\t<a href='index.php?path=$document_path'><dd><span class='$item_icon'></span>$label</dd></a>\n";
            }
            else {
                $nav_group[] = "<dd style='color:#fd585e'><span class='$icon'></span>Not found: '$document_path'</dd>\n";
            };
        };
        $nav_group[] = "\t\t\t\t</div>\n";
		$nav_list[$label] = join("", $nav_group);
    };
	echo join("", $nav_list);
    echo "\t\t\t</dl>\n";

    // ====== Preview page button ======
    $domain = $settings['strona'][0]['domain'][0]['string'][0];
    echo "\t\t\t<div class='buttons'><a href='$root' target='_blank'><button id='page_preview' class='manual' help='Otwórz <a>$domain</a> w nowym oknie'>Podgląd strony</button></a></div>\n";
    // ====== Login info ======
    echo "<p id='login_info'><em>Zalogowany:</em> ".$_SESSION['logged_group'].".".$_SESSION['logged_user'].
        "&nbsp;<a href='logout.php'><span class='fi-x-circle manual' help='Wyloguj'></span></a></p>";

    echo "\t\t</nav>\n";
?>