<?php
    // ======================================
    //              ><.able CMS
    //        (C)2016 maciejnowak.com
    //          v.2.5 build.20160705
    // ======================================
	// compatibile: php5.4+ or higher
    
    session_start();
    if(!is_string($_SESSION['logged_user'])) {
        header("Location: login.php");
        break;
    };

    require "script/functions.php";
    require "script/cms.php";
    require "script/xml.php";

    $ini_file = $_SESSION['ini_file'];
    $ini_pathes = loadIni($ini_file, "pathes");
    $ini_enable = loadIni($ini_file, "enable");
    $root = $ini_pathes['root'];
    $settings = loadXml($ini_pathes['settings']);
    $nav_documents = loadIni($ini_file, "navigation");
    //arrayList($nav_documents);
?>

<!doctype html>
<html>
	<head>
        <!-- Loader Style -->
        <style>
            /* ================================== */
            /*               Loader               */
            /* ================================== */

            #loader {
                position: fixed;
                top: 0px;
                left: 0px;
                width: 100%;
                height: 100%;
                color: #000000;
                background-color: #ffffff;
                text-align: center;
                z-index: 9999;
            }

            #loader .loading {
                position: relative;
                top: 50%;
                margin: auto;
                margin-top: -100px;
                -webkit-animation:spin 2s linear infinite;
                -moz-animation:spin 2s linear infinite;
                animation:spin 2s linear infinite;
                opacity: 0.4;
            }
            @-moz-keyframes spin { 100% { 
                -moz-transform:rotate(360deg); 
                }
            }
            @-webkit-keyframes spin { 100% { 
                -webkit-transform:rotate(360deg); 
                }
            }
            @keyframes spin { 100% {
                -webkit-transform:rotate(360deg);
                transform:rotate(360deg);
                }
            }
        </style>
        <!-- Loader Style / end -->
		<meta charset="UTF-8">
		<title>X.able CMS / Editor</title>
		
		<link rel="stylesheet" type="text/css" href="style/index.css" />
		<link rel="stylesheet" type="text/css" href="style/nav.css" />
		<link rel="stylesheet" type="text/css" href="style/cms.css" />
        <!-- <link rel="stylesheet" type="text/css" href="style/csv.css" /> -->
        <link rel="stylesheet" type="text/css" href="style/colors.css" />
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		
        <script src='script/jquery-1.11.2.min.js'></script>
        <script src='script/functions.js'></script>
        <script src='script/footer.js'></script>

	</head>
	<body>
        <div id='loader'><img class='loading' src='images/loading_1.png'></div>
        
        <?php
        
            // ====== LANGUAGE ======
            $languages = array();
            foreach($settings['multi_language'] as $lang_data) {
                //if(readXml($lang_data, "active") != "") {
                    $id = readXml($lang_data, "id");
                    $languages[] = $id;
                //};
            };
            $admin_lang = "pl";
            $lang = $_GET['lang'];
            if(!is_string($admin_lang)) {
                $languages = array( "pl" );
                $admin_lang = "pl";
            };
            if(!is_string($lang) || $lang == "") { $lang = $admin_lang; };
            // Read auto translate dictionary
            $translate_dictionary = file_get_contents("dictionary.csv");
            $translate_dictionary = str_replace("\n", "|", $translate_dictionary);

            // ====== EDIT PATH ======
            $path = $_GET['path'];
            if(!is_string($path) || $path == "" || !file_exists($path)) {
                $path = getFirstPath($nav_documents, $root);
            };

            // ====== SAVE PATH ======
            if(is_string($_GET['saveas']) && $_GET['saveas'] != "") {
                $saveas = path($path, "dirname")."/".$_GET['saveas'];
            }
            else {
                $saveas = $path;
            };
        
            // ====== POPUP ======
            if(is_string($_GET['popup']) && $_GET['popup'] != "") {
                echo "\t\t<input type='hidden' id='popup' value='".$_GET['popup']."'>\n";
            };
        
            echo "\n";
        
            // ======================================
            //            Send variables
            // ======================================
            
            echo "\t\t<input type='hidden' id='root' value='".$root."'>\n";
            echo "\t\t<input type='hidden' id='path' value='".$path."'>\n";
            echo "\t\t<input type='hidden' id='saveas' value='".$saveas."'>\n";
            echo "\t\t<input type='hidden' id='languages' value='".join(",", $languages)."'>\n";
            echo "\t\t<input type='hidden' id='lang' value='".$lang."'>\n";
            echo "\t\t<input type='hidden' id='admin_lang' value='".$admin_lang."'>\n";
            echo "\t\t<input type='hidden' id='translate_dictionary' value='".str_replace("\n", "\|", $translate_dictionary)."'>\n";
        
            foreach(array_keys($ini_enable) as $key) {
                echo "\t\t<input type='hidden' id='enable_$key' value='".$ini_enable[$key]."'>\n";
            };

            include("_nav.php");
            
            if(path($path, "extension") == "xml" || path($path, "extension") == "template") { include("_xml.php"); }
            elseif(path($path, "extension") == "order") { include("_order.php"); }
            elseif(path($path, "extension") == "csv") { include("_csv.php"); }
            else { include("_text.php"); };
        
            // ======================================
            //            Template script
            // ====================================== 
            if(path($path, "extension") == "template") {
                echo "\t\t<script src='script/template.js'></script>\n";
            };

        ?>

        
        <script src='script/cms.js'></script>
        
	</body>
</html>

