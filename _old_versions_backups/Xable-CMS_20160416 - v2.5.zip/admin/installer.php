<?php
    // ======================================
    //          ><.able CMS - CREATOR
    //        (C)2016 maciejnowak.com
    //          v.1.0 build.0
    // ======================================
	// compatibile: php4 or higher

    session_start();
    if(!is_string($_SESSION['logged_user'])) {
        header("Location: login.php");
        break;
    };

    require "script/functions.php";
    require "script/cms.php";
    require "script/xml.php";

    $installer_folder = "_installer";					// Installer archives repositories folder
    $installer_name = "Xable-CMS_".date("Ymd").".zip";	// New installer archive filename
	
	$archive_main = "install";					// Main folder in installer archive
	$archive_content = "$archive_main/xable";	// Contents folder in installer archive
	
	$ini_file = $_SESSION['ini_file'];
    $ini_pathes = loadIni($ini_file, "pathes");
    $root = $ini_pathes['root'];
    $admin_folder = $_SESSION['admin_folder'];

    // ====== Excluded ======
    $exclude = array();
	// Excluded in root
    foreach(array("_bak", "install", "redirect") as $folder) { $exclude[] = "$root/$folder"; };
	// Excluded in root/admin
    foreach(array("_backup", "_installer", "_bak", "test") as $folder) { $exclude[] = "$root/$admin_folder/$folder"; };

    // ====== CREATE INSTALLER ======
    if($_GET['action'] == "installer") {
		// ====== Update Scripts in site folder ======
		// update sript: functions.php, xml.script
		$update_script = array("functions.js", "functions.php", "xml.php");
		$script_folder = "script";
		foreach($update_script as $file) { copy("$script_folder/$file", "$root/$script_folder/$file"); };
		// ====== Create ZIP Archive ======
		$zip_log = array();
		$zip_path = "$installer_folder/$installer_name";
		$zip_log[] = "$zip_path";
		if(file_exists($zip_path)) { unlink($zip_path); }; // Overwrite existing!
		$zip = new ZipArchive;
		if ($zip->open($zip_path, ZipArchive::CREATE)) {
			// Add installer
			foreach(listDir($installer_folder) as $file) {
                if(!is_dir("$installer_folder/$file") && path($file, "extension") != "zip") {
					$path = "$installer_folder/$file";
					$zip_path = "$archive_main/$file";
					$zip_log[] = "$path -> $zip_path";
					$zip->addFile($path, $zip_path);
				};
			};
			// Add xable content
			foreach(filesTree($root, false, $exclude) as $path) {
				if(														// IGNORE:
					!is_dir($path)  &&									// directories pathes
					substr(path($path, "basename"), 0, 1) != "." &&		// .hidden files
					path($path, "extension") != "bak" &&				// bak files
					(!is_array($exclude) || count($exclude) == 0 || !in_array(path($path, "extension"), $excllude)) // non-excluded
				) {
					$relative_path = substr($path, strlen($root) + 1);
					foreach(split("/", $relative_path) as $folder) { if(substr($folder, 0, 1) == ".") { $path = false; }; }; // IGNORE files in hidden folder
					if(is_string($path)) {
						$zip_path = $archive_content."/".$relative_path; // zip path -> instal/xable/<relative path>
						$zip_log[] = "$path -> $zip_path";
						$zip->addFile($path, $zip_path);
					};
				};
			};
			// Close zip
			$zip->close();
		}; // zip / end
    } // Create installer / end
	else {
		$zip_log = false;
	};


?>

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>X.able CMS / Installer maker</title>
        <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" type="text/css" href="style/foundation-icons.css" />
        <link rel="stylesheet" type="text/css" href="style/creator.css" />
        <link rel="stylesheet" type="text/css" href="style/installer.css" />
        
        <script src='script/jquery-1.11.2.min.js'></script>
        <script src='script/functions.js'></script>
	</head>
	<body>
        <main>
            <nav>
                <div id="menu_bar">
                    <label class='logo'>
                        <span>><</span>
                    </label>
                    <label class='title menu'>
                        <p>Installer maker</p>
                        <ul>
                            <li>Creator</li>
                            <li>Users</li>
							<li class='separator'><hr></li>
                            <li>Quit</li>
                        </ul>
                    </label>
                </div>
            </nav>
                
            <article>
                <h3><span class="article_icon fi-archive"></span>Content preview</h3>
                <section id='content_preview'>
					<details>
						<summary>install</summary>
                            <?php
                                foreach(listDir($installer_folder) as $file) {
                                    if(!is_dir("$installer_folder/$file") && path($file, "extension") != "zip") {
                                        echo "<p class='file type_php'>$file</p>";
                                    };
                                };
                            ?>
							<details>
								<summary>xable</summary>
								<?php htmlTree($root, "name", false, $exclude) ?>
							</details>
					</details>
					<p class='file type_php'>readme.txt</p>
                </section>
                <button class='confirm'>Create installer</button>
            </article>
        </main>
        <aside>
            <div id='code'>
                <?php
                    $installer_files = array();
                    foreach(listDir($installer_folder, "zip") as $file) {
                        $date = split("_", path($file, "filename"));
                        if(count($date) > 1) {
                            $installer_files[array_pop($date)] = $file;
                        };
                    };
                    ksort($installer_files);
                
                    echo "<br><span class='flag'><hr>Download installer files<hr></span><br>\n";
                    foreach(array_reverse($installer_files) as $file) {
                        $size = path("$installer_folder/$file", "size");
                        echo "<span class='tag'>$installer_folder/</span><a href='$installer_folder/$file'>$file</a>&nbsp;<span class='flag'>$size kB</span><br>\n";
                    };
					
					if(is_array($zip_log)) {
						echo "<br><span class='flag'><hr>Installer log<hr></span><br>\n";
						foreach(array_keys($zip_log) as $n) {
							if($n == 0) {
								echo "<span class='flag'>File created:</span> ".$zip_log[$n]."<br><br>\n";
							}
							else {
								echo "<span class='flag'>$n.</span> <span class='tag'>".str_replace(" -> ", "</span> <span class='flag'>-></span> ", $zip_log[$n])."<br>\n";
							};
						};
					};
                ?>
            </div>
        </aside>

        <script src='script/installer.js'></script>
        
	</body>
</html>

    

