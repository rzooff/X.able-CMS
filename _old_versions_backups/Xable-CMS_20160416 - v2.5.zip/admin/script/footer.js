$(document).ready(function() {

    // ==========================================
    //            Footer & copyrights
    // ==========================================
	
	footer = [
		"<b>X.able CMS</b> v.2.5 &copy;2016 <a href='http://maciejnowak.com' target='_blank'>maciejnowak.com</a>&nbsp;<span>|</span>",
		"<a href='mailto:maciej@maciejnowak.com?Subject=X.able CMS / Editor'><span class='fi-mail help' help='Zgłoś problem'></span></a>",
        "<a href='backup.php' class='unsaved'><span class='fi-save help' help='Kopia zapasowa'></span></a>",
		"<a href='password.php' class='unsaved'><span class='fi-torso-business help' help='Zmień hasło administratora'></span></a>",
		"<a href='creator.php?open=" + encodeURIComponent( $("input#path").val() ) + "' class='unsaved'><span class='fi-wrench help' help='Narzędzia zaawansowane'></span></a>",
        "<span id='update_output' class='fi-eye help' help='Podgląd XML'></span>"
	];

	$("form").append("<footer><p>" + footer.join(" ") + "</p></footer>");
    
    function disableModule(icon) {
        // Deactivate
        /*
        $item = $("footer " + icon).closest("a");
        span = $item.html();
        $item.replaceWith(span);
        $("footer " + icon).click(function() {
            $(this).blur();
            alert("Funkcja niedostępna");
        });
        */
        // Hide
        $("footer " + icon).each(function() {
            $a = $(this).parent("a");
            if($a.length) { $a.hide(); }
            else { $(this).hide(); }
        });
    };

    if( $("input#enable_password").val() != "true" ) { disableModule(".fi-torso-business"); };
    if( $("input#enable_creator").val() != "true" ) { disableModule(".fi-wrench"); disableModule(".fi-eye"); };
    if( $("input#enable_backup").val() != "true" ) { disableModule(".fi-save"); };

    if( $("input#enable_remove").val() != "false" ) {
		$("nav a").each(function() {
			$(this).children("dd").append("<span class='remove manual fi-x' help='Usuń stronę'></span>");
		});
	};
	
});