<?php
	
	$echo = [];
	$error = [];
	
// ===================================================
//                    Functions
// ===================================================
 
    require "../script/functions.php";
    require "../script/xml.php";
    require "script/upload_images.php";
    require "script/admin.php";

// ===================================================
//                  Show recived data
// ===================================================
/*
    echo "_GET:<br>";
    arrayList($_GET);
    echo "<hr>";
    echo "_POST:<br>";
    arrayList($_POST);
    echo "<hr>";
    echo "_FILES:<br>";
    arrayList($_FILES);
    echo "<hr>";
*/
// ===================================================
//                Set main variables
// ===================================================

    $save = true;
    $root = $_GET['root'];
    $url = $_GET['url'];
    $action = $_POST['_action'];
    $button = $_POST['_button'];
    $post_id = split("-", $_POST['_id']);
    // Load settings:
    $settings = loadXml("$root/settings.xml");

// ===================================================
//                   Modify actions
// ===================================================

    if(!is_array($xml = loadXml($url))) {
        echo "File load error!";
        $save = false;
    }
    // ====== DELETE POST ======
    elseif($_POST['_button'] == "delete") {
        //echo "delete post<br>";
        if(count($xml[$post_id[0]]) > 1) {
            $post = $xml[$post_id[0]][$post_id[1]];
            // delete related media files
            foreach(array_keys($post) as $name) {
                if($post[$name][0]['type'][0] == "media") {
                    foreach(array_keys($post[$name][0]['media'][0]) as $type) {
                        $val = $post[$name][0]['media'][0][$type][0];
                        //echo "typ: $type, val: $val<br>";
                        if($type == "gallery" && substr($val, 0, 4) != "new:") {
                            mediaDelete("$root/$val");
                        }
                        elseif($type == "image" && path($val, "extension") != "") {
                            mediaDelete("$root/$val");
                        };
                    };
                };
            };
            unset($xml[$post_id[0]][$post_id[1]]); // delete post from xml
        }
        else {
            echo "Last post cannot be deleted!<br>";
            $save = false;
        };
    }
    // ====== MOVE POST UP ======
    elseif($_POST['_button'] == "move_up") {
        //echo "move up<br>";
        if($post_id[1] > 0) {
            $flip = $xml[$post_id[0]][$post_id[1] - 1];
            $xml[$post_id[0]][$post_id[1] - 1] = $xml[$post_id[0]][$post_id[1]];
            $xml[$post_id[0]][$post_id[1]] = $flip;
        }
        else {
            echo "Cant't move up, cause item is on the top already!<br>";
            $save = false;
        };
    }
    // ====== MOVE POST DOWN ======
    elseif($_POST['_button'] == "move_down") {
        //echo "move down<br>";
        if($post_id[1] < (count($xml[$post_id[0]]) - 1)) {
            $flip = $xml[$post_id[0]][$post_id[1] + 1];
            $xml[$post_id[0]][$post_id[1] + 1] = $xml[$post_id[0]][$post_id[1]];
            $xml[$post_id[0]][$post_id[1]] = $flip;
        }
        else {
            echo "Cant't move down, cause item is on the bottom already!<br>";
            $save = false;
        };
    }
    else {
        // ====== NEW POST ======
        if($post_id[1] == "new") {
            //echo "new post<br>";
            $new['new'] = newPost($xml['post'][0], $root);
            $xml['post'] = $new + $xml['post'];
        };
        // ====== POST UPDATE ======
        //echo "> Update XML!<br>";
        foreach(array_keys($_POST) as $key) {
            if(substr($key, 0, 1) != "_") { // ignore "_" data
                $val = $_POST[$key];
                $id = split("-", $key);
                // BBCode line breaks
                $type = $xml[$post_id[0]][$post_id[1]][$id[0]][$id[1]]['type'][0];
                if(in_array($type, [ "textarea" ])) { $val = str_replace("\n", "[br]", $val); };
                if($id[2] == "media" && substr($val, 0, strlen($root) + 1) == "$root/") { $val = substr($val, strlen($root) + 1); }; // delete admin root from path
                if($id[2] == "selected"&& is_array($val)) { $val = join(",", $val); }; // transform selected options array to string
                if(count($id) < 2) { } // ignore!
                elseif(count($id) == 2) { $xml[$post_id[0]][$post_id[1]][$id[0]][$id[1]] = $val; }
                elseif(count($id) == 4) { $xml[$post_id[0]][$post_id[1]][$id[0]][$id[1]][$id[2]][$id[3]] = $val; }
                elseif(count($id) == 6) { $xml[$post_id[0]][$post_id[1]][$id[0]][$id[1]][$id[2]][$id[3]][$id[4]][$id[5]] = $val; }
            };
        };
        // ====== OPTIONS ======
		if(is_array($_POST['_options'])) {
			foreach($_POST['_options'] as $name) {
				if(!is_array($selected = $_POST["$name-selected-0"])) { $selected = []; };
				$id = split("-", $name);
                $selected = join(",", $selected);
				
                
                if($selected != "" && $post_id[0] == "post" && $id[0] == "highlight") {
                    foreach(array_keys($xml['post']) as $n) {
                        $item = $xml['post'][$n];
                        if(is_string($item[$id[0]][0]['selected'][0])) {
                            $xml['post'][$n][$id[0]][$id[1]]['selected'][0] = "";
                        };
                    };
                };
                
                $xml[$post_id[0]][$post_id[1]][$id[0]][$id[1]]['selected'][0] = $selected;
			};
		};
        // ====== DELETE IMAGE(s) / DOCUMENT ======
        if(is_string($delete_id = $_POST['_images_delete']) && $delete_id != "" && is_array($images = $_POST['_images'])) {
            $dat = split("-", $delete_id);
            $name = $dat[0];
            $type = $dat[4];
            $val = $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0]; // old value
            //echo "Delete images / $delete_id: ".join(",", $images)."<br>";
            mediaDelete($images); // Delete file!
            if($type == "gallery") {
                if(listDir("$root/$val") == false) {
                    echo "- delete an empty gallery.<br>";
                    $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0] = "new:".path($val, "dirname");
					//$xml[$post_id[0]][$post_id[1]][$name][0]['media'][0]['set'][0] = "none";
					mediaDelete("$root/$val");
                }
                else {
                    echo "- delete image(s) from a gallery.<br>";
                    // $xml mod not needed
                };
            }
            elseif($type == "image" || $type="document") {
                //echo "- delete image.<br>";
                $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0] = path($val, "dirname");
            };
        };
        // ====== UPLOAD IMAGE(s) ======
        if(is_string($files = uploadFiles()) && $files != "") {
            //echo "<hr>UPLOAD: $files<br>";
            $key = current(array_keys($_FILES));
            $dat = split("-", $key);
            $name = $dat[0];
            $type = $dat[4];
            //$set = $xml[$post_id[0]][$post_id[1]][$name][0]['set'][0]; // old set
            $set = $_POST[$name."-0-set-0"]; // new set
            $val = $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0]; // old value
            if($type == $set) { // matching upload & set types
				// get resize settings (by name)
				if(is_string($resize = $settings['media'][0][$name."_size"][0]['text'][0])) { $resize = "max:$resize"; } else { $resize = false; };
                if($type == "gallery") {
                    // ====== ADD TO GALLERY / NEW GALLERY ======
                    //echo "val: '$val'<br>";
                    if(substr($val, 0, 4) == "new:") {
                        $folder = substr($val, 4);
                        $new = uniquePath("$root/$folder/".path($url, "filename")."-$name", "_"); // find unique image file name
                        //echo "New gallery: $new<br>";
                        mkdir($new);
                        $val = substr($new, strlen($root) + 1);
                        $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0] = $val;
                    };
                    //echo "upload: $key, $val<br>";
                    if(!is_array(uploadRenameImages($key, "$root/$val", $resize, "auto"))) {
                        echo "Images upload error!<br>";
                        $save = false;
                    };
                }
                elseif($type == "image" || $type == "document") {
                    // ====== ADD / REPLACE IMAGE or PDF DOCUMENT ======
                    //echo "val: $val<br>";
                    if(path($val, "extension") != "") { $folder = path($val, "dirname"); } else { $folder = $val; };
                    if(is_array($file = uploadRenameImages($key, "$root/$folder", $resize, "auto"))) {
                        if($folder != $val) {
                            //echo "- image od doc replace!<br>";
                            mediaDelete("$root/$val");
                        }
                        // ------ CUSTOM: zespół filename fix ------
                        if(path($url, "filename") == "zespol" && $name == "foto") {
                            //echo "> CUSTOM: Zespol image filename fix<br>";
                            $member = $xml[$post_id[0]][$post_id[1]]['name'][0]['text'][0]['pl'][0];
                            $member = killPl(str_replace(" ", "_", strtolower($member))).".".path($file[0], "extension");
                            //echo "member: $member<br>";
                            rename("$root/$folder/$file[0]", "$root/$folder/$member");
                            $file[0] = $member;
                        };
                        $xml[$post_id[0]][$post_id[1]][$name][0]['media'][0][$type][0] = "$folder/$file[0]";
                    }
                    else {
                        echo "Image upload error!<br>";
                        $save = false;
                    };
                };
            }
            else {
                echo "Upload data error!<br>";
                $save = false;
            };
        };
    };

// ===================================================
//                      Output
// ===================================================

    //echo "<hr>OUTPUT<hr>";
    if($save == true) {
		echo "<hr>OUTPUT<hr>";
        //arrayList($xml);
        $xml = saveXml($url, $xml);
        //xmlList($xml);
    }
    else { arrayList($xml); };
	
?>

<!doctype html>
<html>
    <head>
        <meta charset="UTF-8">
        <?php
            echo "<meta http-equiv='Refresh' content='0; url=index.php?url=".$_GET['url']."'>";
        ?>
    </head>
    <body>

    </body>
</html>