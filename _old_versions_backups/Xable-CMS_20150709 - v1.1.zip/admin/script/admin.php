<?php

    // ====== media Delete (move to trash) / begin ======
    function mediaDelete($pathes) {
    // ----------------------------------------
    // $pathes = <string> file(s) or folder(s) full path / pathes array
    // ----------------------------------------
    // Moves file or folder into the specified trash folder
    // ----------------------------------------
        $trash = "../media/_bak";
        // ======================
        if(!is_array($pathes)) { $pathes = [ $pathes ]; };
        foreach($pathes as $path) {
            $info = pathinfo($path);
            $dir = $info['dirname'];
            $name = $info['basename'];
            if(file_exists($path)) {
                rename($path, "$trash/$name");
                //echo "- deleteMedia: $path<br>";
            }
            else {
                echo "# deleteMedia: - NO FILE/FOLDER: $path<br>";
            };
        };
    }; // ====== media Delete (move to trash) / end ======

    // ====== find unique file or folder Path / begin ======
    function uniquePath($file, $spacer) {
    // ----------------------------------------
    // $file = <string> full file path
	// $spacer = <string> spaces substitute character or <false> to keep original filename
    // ----------------------------------------
    // RETURNS: <string> unique filename (full path)
    // ----------------------------------------
		$info = pathinfo($file);
		$ext = $info['extension'];
        if($ext != "") { $ext = ".".$ext; };
		$name = $info['filename'];
		$path = $info['dirname'];
		if(is_string($spacer)) { $name = str_replace(" ", $spacer, $name); } else { $spacer = " "; };
		if(file_exists("$path/$name$ext")) {
			$info = pathinfo($file);
			$ext = $info['extension'];
            if($ext != "") { $ext = ".".$ext; };
			$name = $info['filename'];
			$path = $info['dirname'];
			$n = 2;
			while(file_exists("$path/$name$spacer$n$ext")) { $n++; };
			$file = "$path/$name$spacer$n$ext";
		}
		else {
			$file = "$path/$name$ext";
		};
		return $file;
    }; // ====== ind unique file or folder Path / end ======

    // ====== Upload Files Number / begin ======
    function uploadFiles() {
    // ----------------------------------------
    // RETURNS: <string> upload files type ("image" or "gallery") or <false> if no files
    // ----------------------------------------
        if(is_array($_FILES) && is_array($files = current($_FILES))) {
            //arrayList($files);
            if(is_string($files['name'])) { $files = "image"; }
            elseif(is_array($files['name'])) { $files = "gallery"; }
            else { $files = false; };

        }
        else {
            $files = false;
        };
        return $files;
    }; // ====== Upload Files Number / end ======

    // ====== create new Post XML / begin =======
    function newPost($post, $root) {
    // ----------------------------------------
    // $post = <array> imported XML post data
    // $root = <string> path to website root folder
    // ----------------------------------------
    // RETURN: <array> empty XML post data with current date (if any)
    // ----------------------------------------
        $new = [];
        foreach(array_keys($post) as $key) {
            $val = $post[$key];
            if($val[0]['type'][0] == "media") {
                foreach(array_keys($val[0]['media'][0]) as $type) {
                    if($type == "image" || $type == "clipart" || $type == "document") {
                        $path = $val[0]['media'][0][$type][0];
                        //$path = substr($path, (strlen($root) + 1));
                        if(path($path, "extension") != "") {
                            if($type == "clipart") {
                                $clipart = current(listDir("$root/".path($path, "dirname"), "gif,jpg,png,?"));
                                $clipart = (substr($clipart, strlen($root) + 1));
                                $val[0]['media'][0][$type][0] = $clipart;
                            }
                            else {
                                $val[0]['media'][0][$type][0] = path($path, "dirname");
                            };
                        }
                        else {
                            $val[0]['media'][0][$type][0] = $path;
                        };
                    }
                    elseif($type == "gallery") {
                        $folder = $val[0]['media'][0][$type][0];
                        if(substr($folder, 0, 4) != "new:") {
                            $folder = "new:".path($folder, "dirname");
                        };
                        $val[0]['media'][0][$type][0] = $folder;
                    }
                    else {
                        $val[0]['media'][0][$type][0] = "";
                    };
                    $val[0]['set'][0] = current(array_keys($val[0]['media'][0]));
                    $new[$key] = $val;
                };
            }
            elseif($val[0]['type'][0] == "date") { 
                if(($format = $val[0]['format'][0]) == "") { $date = ""; } else { $date = date($format); };
                $val[0]['text'][0] = $date;
                $new[$key] = $val;
            }
            elseif(!is_numeric($key) && in_array($key, ["type", "description", "label", "option", "style"])) { $new[$key] = $val; } // do not change type data
            elseif(is_numeric($key) && is_string($val)) { $new[$key] = ""; } // text data reset
            elseif(is_array($val)) { $new[$key] = newPost($val); } // array -> requrence
            else { $new[$key] = $val; }; // other
        };
        return $new;
    }; // ====== create new Post XML / end =======

?>