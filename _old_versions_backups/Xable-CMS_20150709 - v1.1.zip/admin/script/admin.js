$(document).ready(function () {
    
	// ===============================
	//        Global variables
	// ===============================

    url = $("input#url").val();
    root = $("input#root").val();
    changed = false // test -> if changed might be lost
    
	// ===============================
	//             Zespół
	// =============================== 

    groups = ["grupa_1", "grupa_2", "grupa_3"];
    for(n = 0; n < groups.length; n++) {
        group_id = groups[n];
        group_name = $("input#" + group_id + "-0-text-0-pl-0").val();
        $("span.option").each(function() {
            if($(this).text() == group_id) { $(this).text(group_name); };
        });
    };
    //alert(group_name);

	// ===============================
	//   Loss of the changes protect
	// ===============================
    
    // notify changes
    $("input, textarea").keyup(function() { changed = true; });
    $(".images_delete, .image_delete, button#select, input.media_type, input.checkbox").click(function() { changed = true; });
    
    // check for changes
    $("a, button.button, span.fi-page").click(function() {

        if($(this).attr("class") == undefined || $(this).attr("class").split(" ").indexOf("new_window") == -1) { // ignore new window target links
            $("input.file").each(function() {
                if($(this).val() != "") { changed = true; }; // check for selected but not uploaded file(s)
            });
            if(changed == true && confirm("Dokonane zmiany nie zostały zapisane!") != true) { return false; };
        };
    });
    
	// ===============================
	//        Delete post popup
	// ===============================
    
    $("button.post_delete").click(function() {
        if(confirm("Czy jesteś pewien?") != true) { return false; };
    });
    
	// ===============================
	//         New post button
	// ===============================
    
    $("section.new_post").hide();
    $("button#new_post").click(function() {
        $(this).hide();
        $("section.new_post").slideDown(500);
        return false;
    });
    
	// ===============================
	//          Buttons hover
	// ===============================

    $("div.buttons button").mouseenter(function() { $(this).css({"color": "#cccccc", "border-color": "#aaaaaa"}); });
    $("div.buttons button").mouseleave(function() { $(this).css({"color": "#ffffff","border-color": "#111111"}); });
    
	// ===============================
	//           Baloon Info
	// ===============================

    $("body").append("<div id='baloon'></div>");

    $(".help").mouseenter(function() {
        help = $(this).attr("help"); // get text from xml.help attr
        if(help != false && help != "") {
            $("#baloon").replaceWith("<div id='baloon'>" + help.replace("\\\\", "<br>") + "</div>");
            xy = $(this).offset();
            xy_2 = $(this).offsetTop;
            //alert("jq: " + xy.top + ", js: " + $(document).scrollTop());
            $("#baloon").css({ "left": xy.left + $(this).width() + 15, "top": xy.top + $(this).height() + 15 });
            $("#baloon").stop().fadeIn(200);
            //alert($(this).width());
        };
    });

    $(".help").mouseleave(function() {
        $("#baloon").stop().fadeOut(200);
    });

});