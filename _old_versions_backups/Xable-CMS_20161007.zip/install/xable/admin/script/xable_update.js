$(document).ready(function() {
    
    urlQuery();
	
	// Add names to all inputs
	$("form select, form input").each(function() { $(this).attr("name", $(this).attr("class")); });
	
    // ==========================================
    //                 Menu bar
    // ==========================================

	// Show menu dropdown
    $("nav label.menu").mouseenter(function() {
        $(this).find("ul").stop().show(200);
        $(this).find("p").css({ "opacity": "0.25" });
    });

	// Hide menu dropdown
    $("nav label.menu").mouseleave(function() {
        $(this).find("ul").stop().hide(100);
        $(this).find("p").css({ "opacity": "1" });
    });
    
	// Menu actions
	$("nav li").click(function() {
		// Hide dropdown
        $(this).closest("label").find("ul").stop().hide(100);
        $(this).closest("label").find("p").css({ "opacity": "1" });
        // Actions
		action = $(this).html().replace(/&nbsp;/g, "_").toLowerCase();
		if(action == "quit") {
            if(confirm("Are you sure?")) {
                location.href = "index.php";
            };
        }
		else if(action == "users" || action == "creator") {
            location.href = "xable_" + action + ".php";
        }
        else {
            alert("Unimplemented: " + action)
        };
    });
    
    // ==========================================
    //                   Edit
    // ==========================================
    
    $("article, section").fadeIn(200);
    
    $("details").click(function() { $(this).focusout(); });
    
    $("#create button").click(function() {
        location.href = "xable_update.php?action=installer"; 
    });
    
    $("#code .remove").click(function() {
        if(confirm("Delete archive file.\nAre you sure?")) {
            file = $(this).attr("value");
            location.href = "_update.php?remove=" + encodeURI(file);
        }
        else {
            $(this).blur();
        }
    });
    
    $("#update button").click(function() {
        val = $(this).closest("form").find("input").val();
        if(val == "") {
            alert("Select package to install");
            return false;
        }
        else if(confirm("Upload and install update.\nAre you sure?")) {
            return true;
        }
        else {
            $(this).blur();
            return false;
        }
    });
    
});