<?php
    //include "bufor.php"; <- wszystko co tam było poprawiłem w kodzie poniżej / maciej@maciejnowak.com

	session_start();
	require "script/functions.php";
	require "script/xml.php";

	$settings = loadXml("settings.xml");
	$navigation = loadXml("navigation.xml");
	$pages = "pages";

    // ====== Languages ======

    $languages = array();
    $all_languages = array();

    foreach($settings['multi_language'] as $language) {
        $active = readXml($language, "active");
        $id = readXml($language, "id");
        $all_languages[] = $id;
        if($active != "") { $languages[] = $id; };            
    };
    //arrayList($all_languages);

    if(in_array($_GET['lang'], $all_languages)) {
        $_SESSION['lang'] = $_GET['lang'];
    }
    elseif(!in_array($_SESSION['lang'], $languages)) {
        $_SESSION['lang'] = "pl";
    };

?>

<!doctype html>

<html>
	<head>
	
        <!--
            This website is powered by X.able CMS v3.0
            Copyright ©2016 by maciej@maciejnowak.com

            Graphics design by aggadesign.pl
            Site developement by maciejnowak.com
        -->
	
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta charset="UTF-8">
		<meta http-equiv="Content-Language" content="<?php echo $_SESSION['lang']; ?>">
		<title><?php echo readXml($settings, "page title"); ?></title>
         <meta name="description" content="Restauracja w centrum Warszawy. Dwie sale. VIP room. Spotkania biznesowe/ imprezy firmowe/ bankiety/ konferencje prasowe. Nowoczesna kuchnia śródziemnomorska."/>

        <style>
            body { background-color: #e4e4e4; }
            #content { display: none; }
            #loader {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
            }
            
            /* Loader source: http://projects.lukehaas.me/css-loaders/ */
            .loader {
                position: relative;
                top: 50%;
                margin: -90px auto;
                font-size: 3px;
                position: relative;
                text-indent: -9999em;
                border-top: 1.1em solid rgba(0, 0, 0, 0.2);
                border-right: 1.1em solid rgba(0, 0, 0, 0.2);
                border-bottom: 1.1em solid rgba(0, 0, 0, 0.2);
                border-left: 1.1em solid #000000;
                -webkit-transform: translateZ(0);
                -ms-transform: translateZ(0);
                transform: translateZ(0);
                -webkit-animation: load8 1.1s infinite linear;
                animation: load8 1.1s infinite linear;
            }
            .loader,
            .loader:after {
                border-radius: 50%;
                width: 60em;
                height: 60em;
            }
            @-webkit-keyframes load8 {
              0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
              }
              100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
              }
            }
            @keyframes load8 {
              0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
              }
              100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
              }
            }
            
        </style>
        
        <!-- ====== CSS / will be moved to HEAD via js ====== -->
        <link class='async' rel="stylesheet" href="font-awesome-4.6.3/css/font-awesome.min.css">
        <link class='async' rel="stylesheet" href="style/preview_mode.css">
        <link class='async' rel="stylesheet" href="style/layout.css">
        <link class='async' rel="stylesheet" href="style/nav.css">
        <link class='async' rel="stylesheet" href="style/popup.css">
        
        <link class='async' rel="stylesheet" href="style/layout-mobile.css">

	</head>

	<body>

        <?php
            // RELOAD "page/"
            if(is_string($_GET['reload']) && $_GET['reload'] != "") {
                echo "<script> location.href = \"../".$_GET['reload']."\"; </script>\n";
            };
        
            // ====== Page ======
            //$current_page = $_GET['page'];
            //if(!is_string($current_page) || $current_page == "") { $current_page = "start"; };
        
            // ====== Check DRAFT PREVIEW mode ======
            if($_GET['preview'] == "none" || $_GET['preview'] == "false") { $_SESSION['preview_mode'] = false; }
            elseif(is_string($_GET['preview']) && $_GET['preview'] != "") { $_SESSION['preview_mode'] = $_GET['preview']; };
            // ====== Send preview status ======
            if(is_string($_SESSION['preview_mode']) &&  $_SESSION['preview_mode'] != "") {
                echo "<input type='hidden' id='preview_mode' value='".$_SESSION['preview_mode']."'>\n";
            };
        
            // ====== Scroll to section ======
            echo "<input type='hidden' id='scroll_to_section' value='".$_GET['page']."'>\n";
        
            $background = readXml($settings, "media background");
            echo "<div id='content' style='background-image:url(\"$background\")'>";

        ?>
        
        
            
            <!-- ====== Main content ====== -->
            <?php
        

        
                function makeId($string) {
                    $string = strtolower(killPl($string));
                    $string = str_replace(" ", "_", $string);
                    return $string;
                }
        
                function articleHeader($header_mode, $title, $settings) {
                    $header = array();
                    if($header_mode == 1) {
                        $header[] = "\t\t\t\t\t<h2 class='mode_$header_mode'>\n";
                        $header[] = "\t\t\t\t\t\t<button class='skew-45cw'><span class='skew-45ccw'>".$title."</span></button>\n";
                        $header[] = "\t\t\t\t\t\t<div class='pane skew-45cw'></div>\n";
                        $header[] = "\t\t\t\t\t</h2>\n";
                    }
                    elseif($header_mode == 2) {
                        $header[] = "\t\t\t\t\t<h2 class='mode_$header_mode'>\n";
                        $header[] = "\t\t\t\t\t\t<button class='skew-45cw'><span class='skew-45ccw'>".$title."</span></button>\n";
                        $header[] = "\t\t\t\t\t\t<div class='pane skew-45cw'></div>\n";
                        $header[] = "\t\t\t\t\t\t<br><img class='picto' src='".readXml($settings, "media pictogram")."' alt='piktogram'>\n";
                        $header[] = "\t\t\t\t\t</h2>\n";
                    }
                    elseif($header_mode == 3) {
                        $header[] = "\t\t\t\t\t<h2 class='mode_$header_mode'>\n";
                        $header[] = "\t\t\t\t\t\t<img class='big_picto' src='".readXml($settings, "media pictogram")."' alt='piktogram'>\n";
                        $header[] = "\t\t\t\t\t\t<br><button><span>".$title."</span></button>\n";
                        $header[] = "\t\t\t\t\t</h2>\n";
                    };
                    return $header;
                };
        
                foreach($navigation['multi_page'] as $page) {
                    
                    $href = readXml($page, "href");
                    $title = readXml($page, "title");

                    if(substr($href, 0 , 1) == "#") { $xml_name = substr($href, 1); } else { $xml_name = $href; };
                    $xml = loadXml("$pages/$xml_name.xml", "draft");
                    
                    if(readXml($page, "active") != "" && is_array($xml)) {
                        
                        $content = array();

                        $content['slideshow'] = array();

                        $content['image'] = array();
                        $content['text'] = array();
                        $content['table'] = array();
                        $content['info'] = array();

                        $content['button'] = array();
                        $content['download'] = array();
                        
                        $header_mode = substr(readXml($xml, "header mode"), 0, 1);
                        $content['header'] = articleHeader($header_mode, $title, $settings);

                        foreach(array_keys($xml) as $article_name) {
                            // ====== SLIDESHOW ======
                            if($article_name == "slideshow") {
                                $article = $xml[$article_name][0];
                                $slideshow = split(";", readXml($article, "gallery"));
                                $duration = intval( readXml($article, "duration") );
                                $transition = intval( readXml($article, "transition") );
                                
                                $logo = readXml($settings, "media logo");
                                $content['slideshow'][] = "\t\t\t\t<div class='slideshow fullscreen'>\n";
                                foreach($slideshow as $image) {
                                    $content['slideshow'][] = "\t\t\t\t\t<figure style='background-image:url(\"$image\")'></figure>\n";
                                };
                                $content['slideshow'][] = "\t\t\t\t\t<input type='hidden' class='duration' value='$duration'>\n'";
                                $content['slideshow'][] = "\t\t\t\t\t<input type='hidden' class='transition' value='$transition'>\n'";
                                $content['slideshow'][] = "\t\t\t\t</div>\n";
                                if($xml_name == "start") {
                                    $content['slideshow'][] = "\t\t\t\t<div class='gradient fullscreen'></div>\n";
                                    $content['slideshow'][] = "\t\t\t\t<div class='fullscreen'><div class='main_box'>\n".
                                        "\t\t\t\t\t<figure class='logo'><img src='$logo' alt='logo'></figure>\n".
                                        "\t\t\t\t</div></div>\n";
                                };
                            }
                            
                            // ====== single POST ======
                            elseif($article_name == "post") {
                                $article = $xml[$article_name][0];
                                $image = readXml($article, "image");
                                $text = readXml($article, "text");
                                $list = readXml($article, "list");
                                
                                if($image != "" && file_exists($image) && !is_dir($image)) {

                                    if(strtolower(readXml($article, "place")) == "po prawej") {
                                        $image_side = "image-right";
                                    }
                                    else {
                                        $image_side = "image-left";
                                    };
                                    
                                    $content['image'][] = "\t\t\t\t\t<div class='hexagon_box $image_side'>\n";
                                    $content['image'][] = "\t\t\t\t\t\t<figure class='hexagon hexagon_color'><div class='hexagon-in1'><div class='hexagon-in2 color'></div></div></figure>\n";
                                    $content['image'][] = "\t\t\t\t\t\t<figure class='hexagon hexagon_image'><div class='hexagon-in1'><div class='hexagon-in2 image' style='background-image:url(\"$image\")'></div></div></figure>\n";
                                    $content['image'][] = "\t\t\t\t\t</div>\n";
                                }
                                else {
                                    $image_side = "";
                                };
                                
                                if($list != "") {
                                    $list = str_replace("[br]", "[br][*] ", $list);
                                    $list = "[*] ".$list;
                                    $content['text'][] = "\t\t\t\t\t\t<p class='$image_side'>".BBCode($text)."</p><p class='list $image_side'>".BBCode($list)."</p>\n";
                                }
                                elseif($text != "") {
                                    $content['text'][] = "\t\t\t\t\t\t<p class='$image_side'>".BBCode($text)."</p>\n";
                                };
                            }
                            /*
                            // ====== TABLE ======
                            elseif($article_name == "multi_group") {
                                foreach($xml[$article_name] as $group) {
                                    $group_name = readXml($group, "title");
                                    $group_id = makeId($group_name);
                                    if($group_id != "") {
                                        $table = readXml($group, "table");
                                        $table = $table[ $_SESSION['lang'] ];
                                        $content['table'][] = "\t\t\t\t\t\t<h3 id='$group_id'>$group_name</h3>\n";
                                        $content['table'][] = "\t\t\t\t\t\t<table>\n";
                                        foreach($table as $row) {
                                            $content['table'][] = "\t\t\t\t\t\t\t<tr>\n";
                                            $n = 1;
                                            foreach(split(";", $row) as $cell) {
                                                $content['table'][] = "\t\t\t\t\t\t\t\t<td class='col_$n'>".BBCode($cell)."</td>\n";
                                                $n++;
                                            };
                                            $content['table'][] = "\t\t\t\t\t\t\t</tr>\n";
                                        }
                                        //arrayList($table);
                                        $content['table'][] = "\t\t\t\t\t\t</table>\n";
                                    };
                                };
                            }
                            */
                            
                            // ====== BANNERS (menu) ======
                            elseif($article_name == "multi_banner") {
                                
                                $subtitle = readXml($xml, "header title");
                                if(is_string($subtitle) && $subtitle != "") {
                                    $content['table'][] = "\t\t\t\t\t\t<h3>$subtitle</h3>\n";
                                };
                                
                                
                                
                                foreach($xml[$article_name] as $group) {
                                    $content['table'][] = "\t\t\t\t\t\t<table>\n";
                                    $content['table'][] = "\t\t\t\t\t\t\t<tr>\n";
                                    
                                    $title = readXml($group, "title");
                                    $text = readXml($group, "text");
                                    $image = readXml($group, "image");
                                    if($image != "" && file_exists($image) && !is_dir($image)) {
                                        //$content['table'][] = "\t\t\t\t\t\t\t\t<td class='icon'><img src='$image'></td>\n";
                                        $content['table'][] = "\t\t\t\t\t\t\t\t<td class='icon'><figure style='background-image:url(\"$image\")'></figure></td>\n";
                                    };
                                    if($title != "" || $text != "") {
                                        if($title != "") { $title = "<b class='title'>$title</b><br>"; };
                                        $content['table'][] = "\t\t\t\t\t\t\t\t<td>".
                                            "<p>".$title.BBCode($text)."</p>".
                                            "</td>\n";
                                    };
                                    
                                    $content['table'][] = "\t\t\t\t\t\t\t</tr>\n";
                                    $content['table'][] = "\t\t\t\t\t\t</table>\n";
                                };
                                
                            }
                            
                            // ====== GALLERY ======
                            elseif($article_name == "multi_gallery") {
                                $content['gallery'][] = "\t\t\t\t\t\t<div class='gallery'>\n";
                                foreach($xml[$article_name] as $gallery) {
                                    //arrayList($gallery);
                                    $gallery_title = readXml($gallery, "title");
                                    $images = readXml($gallery, "images");
                                    $image = array_shift(split(";", $images));

                                    if($image != "" && file_exists($image) && !is_dir($image)) {
                                        $content['gallery'][] = "\t\t\t\t\t\t\t<button images='$images'>\n".
                                            "\t\t\t\t\t\t\t\t<div class='big_pane skew-45cw'>\n".
                                            "\t\t\t\t\t\t\t\t\t<div class='bg skew-45ccw' style='background-image:url(\"$image\")'></div>\n".
                                            "\t\t\t\t\t\t\t\t</div>\n".
                                            "\t\t\t\t\t\t\t\t<div class='small_pane small_frame skew-45cw'></div>\n".
                                            "\t\t\t\t\t\t\t\t<div class='big_pane big_frame skew-45cw'></div>\n".
                                            
                                            "\t\t\t\t\t\t\t\t<span class='title'>$gallery_title</span>\n".
                                            "\t\t\t\t\t\t\t</button>\n";
                                    };
                                    
                                };
                                $content['gallery'][] = "\t\t\t\t\t\t</div>\n";
                            }
                            
                            // ====== GALLERIES ======
                            elseif($article_name == "galleries") {
                                $content['gallery'][] = "\t\t\t\t\t\t<div class='gallery'>\n";
                                $folder = readXml($xml[$article_name][0], "folder");
                                
                                //if(file_exists("pages/$folder/$folder.order")) {
                                //    $gallery_list = 
                                //}
                                

                                
                                foreach(listOrder($folder, "xml") as $gallery_file) {
                                    $subgaleries = array();
                                    $thumb = "";
                                    $gallery_xml = loadXml("$folder/$gallery_file", "draft");
                                    $gallery_title = readXml($gallery_xml, "header title");
                                    
                                    foreach($gallery_xml['multi_gallery'] as $subgallery) {
                                        $subgallery_title = readXml($subgallery, "title");
                                        $images = readXml($subgallery, "images");
                                        $image = array_shift(split(";", $images));
                                        if($image != "" && file_exists($image) && !is_dir($image)) {
                                            if($thumb == "") { $thumb = $image; };
                                            $subgaleries[] = "<input type='hidden' class='subgallery' name='$subgallery_title' value='$images'>\n";
                                        };
                                    };
                                    
                                    if(count($subgaleries) > 0 ) {
                                        $content['gallery'][] = "\t\t\t\t\t\t\t<button>\n".
                                            join("", $subgaleries).
                                            "\t\t\t\t\t\t\t\t<div class='big_pane skew-45cw'>\n".
                                            "\t\t\t\t\t\t\t\t\t<div class='bg skew-45ccw' style='background-image:url(\"$thumb\")'></div>\n".
                                            "\t\t\t\t\t\t\t\t</div>\n".
                                            "\t\t\t\t\t\t\t\t<div class='small_pane small_frame skew-45cw'></div>\n".
                                            "\t\t\t\t\t\t\t\t<div class='big_pane big_frame skew-45cw'></div>\n".
                                            
                                            "\t\t\t\t\t\t\t\t<span class='title'>$gallery_title</span>\n".
                                            "\t\t\t\t\t\t\t</button>\n";
                                    };
                                    
                                };
                                $content['gallery'][] = "\t\t\t\t\t\t</div>\n";
                            }
                            
                            // ====== LINK BUTTON ======
                            elseif($article_name == "button") {
                                $article = $xml[$article_name][0];
                                $place = str_replace(" ", "_", strtolower(readXml($article, "place")));
                                $label = readXml($article, "label");
                                $link = readXml($article, "href");
                                $popup = readXml($article, "popup");
                                if(is_string($popup) && $popup != "") { $popup = "popup"; } else { $popup = ""; };
                                if($label != "" && $link != "") {
                                    $label = str_replace(" i ", " i&nbsp;", $label);
                                    $label = str_replace(" I ", " i&nbsp;", $label);
                                    $label = str_replace(" ", "<br>", $label);
                                    if(count(split("@", $link)) == 2) { $link = "mailto:$link"; $target = ""; }
                                    else { $target = "target='_blank'"; };
                                    $content['button'][] = "\t\t\t\t<div class='button_box $place'><div class='main_box'>\n";
                                    $content['button'][] = "\t\t\t\t\t<div class='button_border skew-45cw'><a href='$link' $target><button class='active $popup'><span class='skew-45ccw'>".$label."</span></button></a></div>\n";
                                    $content['button'][] = "\t\t\t\t</div></div>\n";
                                }
                            }
                            // ====== FILE DOWNLOAD ======
                            elseif($article_name == "download") {
                                $article = $xml[$article_name][0];
                                //arrayList($article);
                                $label = readXml($article, "label");
                                $file = readXml($article, "file");
                                if($file != "" && file_exists($file) && !is_dir($file)) {
                                    if($label == "") { $label = strtoupper(path($file, "filename")); }
                                    $label = str_replace(" i ", " i&nbsp;", $label);
                                    $label = str_replace(" I ", " i&nbsp;", $label);
                                    $label = str_replace(" ", "<br>", $label);
                                    $content['download'][] = "\t\t\t\t<div class='download_box'><div class='main_box'>\n";
                                    $content['download'][] = "\t\t\t\t\t<div class='button_border'><a href='$file' target='_blank'><div class='hatch_box'><div class='hatch'></div></div><button class='active'>".$label."</button></a></div>\n";
                                    $content['download'][] = "\t\t\t\t</div></div>\n";
                                };
                            }
                            // ====== FILES DOWNLOAD ======
                            elseif($article_name == "multi_download") {
                                $download = array();
                                $article = $xml[$article_name][0];
                                foreach($xml[$article_name] as $article) {
                                    //arrayList($article);
                                    $label = readXml($article, "label");
                                    $file = readXml($article, "file");
                                    if($file != "" && file_exists($file) && !is_dir($file)) {
                                        if($label == "") { $label = strtoupper(path($file, "filename")); }
                                        $label = str_replace(" i ", " i&nbsp;", $label);
                                        $label = str_replace(" I ", " i&nbsp;", $label);
                                        $label = str_replace(" ", "<br>", $label);
                                        
                                        $download[] = "\t\t\t\t\t<div class='button_border'><a href='$file' target='_blank'><div class='hatch_box'><div class='hatch'></div></div><button class='active'>".$label."</button></a></div>\n";
                                    };
                                };
                                // Add buttons
                                if(count($download) > 0) {
                                    $content['download'][] = "\t\t\t\t<div class='download_box'><div class='main_box'>\n";
                                    $content['download'][] = join("", $download);
                                    $content['download'][] = "\t\t\t\t</div></div>\n";
                                };
                            }
                            // ====== INFO ======
                            elseif($article_name == "info") {
                                $article = $xml[$article_name][0];
                                $text = readXml($article, "text");
                                if($text != "") {
                                    $content['info'][] = "\t\t\t\t<p class='info'>".BBCode($text)."</p>\n";
                                };
                            }
                            else {
                                //echo "article_name: $article_name<br>\n";
                                //arrayList($article);
                            };

                        };
                        
                        // ===============================
                        //             OUTPUT
                        // ===============================
                        
                        echo "\n";
                        echo "\t\t\t<section id='$xml_name' class='header_mode_$header_mode'>\n";
                        

                        
                        
                        if(count($content['slideshow']) > 0) {
                            echo join($content['slideshow']);
                        }
                        else {
                            echo "\t\t\t\t<div class='main_box'>\n";
                            echo join($content['header']);
                            
                            if(count($content['image']) > 0) {
                                echo join($content['image']);
                                echo "\t\t\t\t\t<div class='text_box with_image'>\n";
                            }
                            elseif(count($content['gallery']) > 0) {
                                echo "\t\t\t\t\t<div class='text_box with_gallery'>\n";
                                echo join($content['gallery']);
                            }
                            elseif(count($content['table']) > 0) {
                                echo "\t\t\t\t\t<div class='text_box table'>\n";
                                echo join($content['table']);
                            }
                            else {
                                echo "\t\t\t\t\t<div class='text_box'>\n";
                            };
                            
                            echo join($content['text']);
                            echo join($content['info']);
                            echo "\t\t\t\t\t</div>\n";
                            
                            echo "\t\t\t\t\t<div class='logo_vertical'><a class='scroll' href='#start'><img src='".readXml($settings, "media logo")."' alt='logo'></a></div>\n";
                            echo "\t\t\t\t</div>\n";
                            
                            echo join($content['button']);
                            echo join($content['download']);
                            
                        };

                        echo "\t\t\t</section>\n";  
                    };  
                };
        
                // ===============================
                //           NAVIGATION
                // ===============================
        
                echo "\t\t\t<div id='fake_cover'></div>\n";
        
                $menu['main'] = array();
                $menu['languages'] = array();
                $menu['social'] = array();

                // ====== Desktop Menu ======
                echo "\n";
                echo "\t\t\t<nav>\n";
                //echo "\t\t\t\t<button class='close'>X</button>";
        
                echo "\t\t\t\t<div class='desktop_box main_box'>\n";
        
                $menu['main'][] = "<ul class='menu-main'>\n";
                //$menu['main'][] = "\t<button class='show_menu'><i class='fa fa-bars'></i></button>\n";
                foreach($navigation['multi_page'] as $page) {
                    if(readXml($page, "active") != "") {
                        $title = readXml($page, "title");
                        $href = readXml($page, "href");
                        if($href == "#menu") {
                            $menu['main'][] = "\t<li class='pulldown'>\n".
                                "\t\t<a href='$href'>$title</a>\n".
                                "\t\t<div class='subs pulldown'>\n";
                            $menu_xml = loadXml("$pages/".substr($href, 1).".xml", "draft");
                            foreach($menu_xml['multi_group'] as $group) {
                                $group_title = readXml($group, "title");
                                $group_id = makeId($group_title);
                                if($group_id != "") {
                                    $menu['main'][] = "\t\t\t<a class='menu_group' href='#$group_id'>$group_title</a>\n";
                                };
                            };
                            $menu['main'][] = "\t\t</div>\n".
                                "\t</li>\n";
                        }
                        elseif($href != "#start") {
                            $menu['main'][] = "\t<li><a href='$href'>$title</a></li>\n";
                        }
                    };
                    //if($id == $_SESSION['lang']) { $current = "class='current'"; } else { $current = ""; };
                    //echo "\t\t\t\t\t<li $current value='$id'>".$id."</li>\n";
                };
                $menu['main'][] = "</ul>\n";
        
                echo join("", $menu['main']);
                echo "\t\t\t\t</div>\n";
                
                echo "<div class='desktop_box'>\n";
                // ====== Social ======
                
                echo "\n";
                $menu['social'][] = "<ul class='menu-social'>\n";
                $menu['social'][] = "\t<li><a href='".readXml($navigation, "facebook href")."' rel='nofollow' target='_blank'><i class='fa fa-facebook'></i></a></li>\n";
                $menu['social'][] = "</ul>\n";
                echo join("", $menu['social']);

                // ====== Languages ======
        
                $lang_list = array();
                foreach($languages as $id) {
                    if($id == $_SESSION['lang']) { array_unshift($lang_list, $id); }
                    else { $lang_list[] = $id; };
                };
                if(count($lang_list) > 1) {
                    echo "\n";
                    $menu['languages'][] = "<ul class='menu-languages'>\n";
                    foreach($lang_list as $id) {
                        if($id == $_SESSION['lang']) { $current = "class='current'"; } else { $current = "class='change'"; };
                        $menu['languages'][] = "\t<li $current value='$id'>".strtoupper($id)."</li>\n";
                    };
                    $menu['languages'][] = "</ul>\n";
                };
                echo join("", $menu['languages']);
        
                echo "</div>\n";

                // ====== Mobile Menu ======
        
                echo "<div class='menu-mobile'><div class='hide-scroll-bar'>\n";
                echo "<div class='main_box mobile_box'>\n";
        
                echo "\t\t<button class='show_menu'><i class='fa fa-bars'></i></button>\n";
                echo "\t\t<button class='hide_menu'><i class='fa fa-chevron-up'></i></button>\n";
        
                echo join("", $menu['main']);
                echo "\t\t<ul class='extra'><li>\n";
                echo "\t\t\t".join("", $menu['languages'])."\n";
                echo "\t\t\t".join("", $menu['social'])."\n";
                echo "\t\t</li></ul>\n";
                echo "\t</div>\n";
                echo "<div class='mobile-outside'></div>\n";
                echo "</div></div>\n";
        
                // ===============================
                echo "\t\t</nav>\n";
                echo "</div>\n";
            ?>
        
        <div id='popup_box'>
            <div class='images_box'>
            </div>
            <button class='close'><span>X</span></button>
            <button class='prev'><span>&lt;</span></button>
            <button class='next'><span>&gt;</span></button>
        </div>
        
        <div id='loader'><div class="loader">Loading...</div></div>
        
        <!-- Javascript -->

        <script src='script/jquery-3.1.0.min.js'></script>
        <script src='script/functions.js'></script>
        <script src='script/preview_mode.js'></script>
        <script src='script/layout.js'></script>
        
	</body>
    

</html>
