<!--
---------------------------------------------
><.able CMS (C)2016 by maciej@maciejnowak.com
---------------------------------------------
Installation:
1. Upload Xable packag (zip)e & unzip.php files to the destination location on your FTP server.
2. Open your browser and open unzip.php location (eg. http://your_server.com/unzip.php).
3. Follow onscreen instructions...
-->

<!doctype html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>X.able CMS / Unzip</title>
		<link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900|Inconsolata:400,700|Audiowide&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
		<style>
			* { margin: 0; padding 0; }
			header { text-align: center; color: #ffffff; background-color: #2f393b; padding: 15px 0; }
			header a { color: inherit; text-decoration: none; }
			header a:hover { color: #ffffff; text-decoration: underline; }
			h1, h1 strong { font-family: 'Audiowide', cursive; font-size: 25px; }
			h1, h2 { font-weight: normal; }
			h1 strong { position: relative; top: 3px; font-size: 1.4em; text-shadow: 0 0 10px #ffffff; }
			h1 span { position: relative; top: 1px; font-size: 0.33em; }
			h2 { position: relative; top: -5px; margin-bottom: 10px; font-size: 0.8em; opacity: 0.5; }
			h3 {
				font-size: inherit;
				font-weight: normal;
				text-align: left;
				padding: 0;
				margin-bottom: 10px;
				border-bottom: 1px solid #aaaaaa;
			}
			h3 span {
				position: relative;
				top: -8px;
				left: 10px;
			}
			body {
				width: 100%;
				height: 100%;
				color: #333333;
				background-color: #e4e4e4;
				background-color: #d7dddd;;
				font-family: 'Lato', sans-serif;
				font-size: 14px;
			}
			article {
				width: 300px;
				margin: 100px auto;
				background-color: #ffffff;
				box-shadow: 0 0 10px #aaaaaa;
				border-radius: 5px;
				overflow: hidden;
				padding: 0;
			}
			.button {
				text-align: center;
			}
			button {
				margin-top: 20px;
				padding: 10px 25px;
				min-width: 120px;
				font-size: inherit;
				color: #ffffff;
				border: none;
				background-color: #46d6ce;;
				border-radius: 1px;
				font-weight: bold;
				font-size: 0.8em;
				cursor: pointer;
				transition: 0.5s;
			}
			button:hover {
				opacity: 0.7;
			}
            .center { text-align: center; }
			ul, li { list-style: none; margin: 0; }
			ul { padding: 20px; }
			li { padding: 10px 0; }
			li p { padding: 5px 0; }
			li input.text { width: 100%; }
			li label { float: left; width: 50%; }
			li hr { border: 0; border-top: 1px solid #333333; margin-top: 20px; }
			label span { padding-left: 5px; }
            label.disabled { opacity: 0.5; }
            input { border: 1px solid #dddddd; }
            input:disabled { background-color: #f4f4f4; }
            
            p.done, p.error { font-size: 1.5em; font-weight: bold; }
            p.error { color: #dd0000; }
            p.log { opacity: 0.5; padding: 0; }
            p a { color: #008877; text-decoration: none; }
            p a:hover { text-decoration: underline; }
		</style>
	</head>
	<body>
		<article>
			<header>
                <h3><span>UnZip</span></h3>
				<h1><strong>&gt;&lt;</strong>.able<span>CMS</span></h1>
				<h2>(C)2016 by <a href='mailto:maciej@maciejnowak.com'>maciej@maciejnowak.com</a></h2>
			</header>
			<ul>
				<?php
					$installer_folder = "install";
					
                    // ====== extract zip archive / begin ======
                    function extractArchive($file, $destination) {
                    // -----------------------------------------------
                    // $file = <string> zip FILE path
                    // $destination = <string> destination directory path
                    // -----------------------------------------------
                    // Extract ZIP archive to specified location
                    // RETURN: <boolean> Unzip success
                    // -----------------------------------------------
                        $zip = new ZipArchive;
                        if ($zip->open($file) == true) {
                            $zip->extractTo($destination);
                            $zip->close();
                            return true;
                        } else {
                            return false;
                        };
                    };
                    // ====== extract zip archive / end ======

					// ====== Find ZIP ======
					$zip = array();
					$dir = opendir( getcwd() );
					while(false !== ($file = readdir( $dir ))) {
						$info = pathinfo($file);
                        $name = $info["filename"];
						if(strtolower($info["extension"]) == "zip" && strstr(strtolower($name), "xable")) {
                            $build = array_pop(split("_", $name));
                            $zip[$build] = $file;
                        };
					};
                    ksort($zip);
                    $zip = array_pop($zip);
					
					// ====== UnZip Installer ======
                    // File not found
					if(!is_string($zip) || !file_exists($zip)) {
						echo "<li><p class='error center'>ERROR!</p><p class='center'>Zip file not found</p></li>";
					}
                    // Unzip
					elseif(extractArchive($zip, getcwd()) && file_exists($installer_folder)) { // === UNZIP ===
					//elseif(file_exists("$installer_folder/index.php")) { // test preview
                        echo "<li>";
						echo "<p class='log'>&bull; File: <span class='done'>".$zip."</span></p>";
						echo "<p class='log'>&bull; Show: <a href='$installer_folder/readme.txt' target='_blank'>readme.txt</a></p>";
                        echo "</li>";
                        echo "<li><p class='done center'>Installer files UnZipped successfully!</p></li>";
                        echo "<li class='button'><a href='$installer_folder/install.php'><button>Install now</button></a></li>\n";
					}
                    // Unzip error
					else {
                        echo "<li><p class='error center'>ERROR!</p>".
                            "<p class='center'>Failed to unzip:</p>".
                            "<p class='log center'>$zip</p></li>";
					};
				?>
			</ul>
        </article>
	</body>
</html>