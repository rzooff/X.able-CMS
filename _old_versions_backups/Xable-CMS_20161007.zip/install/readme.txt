><.able CMS v.3
---------------
XML based website Content Management System

(C)2016 by maciej@maciejnowak.com

Installation:
1. Upload Xable packag (zip)e & unzip.php files to the destination location on your FTP server.
2. Open your browser and open unzip.php location (eg. http://your_server.com/unzip.php).
3. Follow onscreen instructions...
